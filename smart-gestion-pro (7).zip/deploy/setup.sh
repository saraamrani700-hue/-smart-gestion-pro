#!/bin/bash
# ============================================================================
# Smart Gestion Pro — Installation sur Hostinger VPS KVM 1 (1 vCPU / 4GB RAM)
# ============================================================================
# A executer en root (ou avec sudo) sur un Ubuntu 22.04/24.04 fraichement
# installe. Idempotent dans la mesure du possible, mais concu pour un
# premier deploiement.
#
# Usage : bash setup.sh
# ============================================================================
set -e

echo "=== 1/8 — Mise a jour du systeme ==="
apt-get update -y
apt-get upgrade -y

echo "=== 2/8 — Fichier swap (essentiel sur 4GB RAM) ==="
# Sur un KVM 1 (4GB RAM, 1 seul coeur), PostgreSQL + Redis + Node.js peuvent
# saturer la memoire lors de pics (ex: generation de rapport, OCR). Un swap
# de 2GB evite que le systeme tue les processus (OOM killer) au lieu de
# simplement ralentir temporairement.
if [ ! -f /swapfile ]; then
  fallocate -l 2G /swapfile
  chmod 600 /swapfile
  mkswap /swapfile
  swapon /swapfile
  echo '/swapfile none swap sw 0 0' >> /etc/fstab
  echo "Swap de 2GB cree et active."
else
  echo "Swap deja present, ignore."
fi

echo "=== 3/8 — Node.js 20 LTS ==="
if ! command -v node &> /dev/null; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
node -v

echo "=== 4/8 — PostgreSQL ==="
apt-get install -y postgresql postgresql-contrib
systemctl enable postgresql
systemctl start postgresql

echo "=== 5/8 — Redis ==="
apt-get install -y redis-server
sed -i 's/^supervised no/supervised systemd/' /etc/redis/redis.conf
systemctl enable redis-server
systemctl restart redis-server

echo "=== 6/8 — Nginx + pare-feu ==="
apt-get install -y nginx ufw
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable
systemctl enable nginx

echo "=== 7/8 — PM2 (gestionnaire de process Node.js) ==="
npm install -g pm2

echo "=== 8/8 — Certbot (SSL Let's Encrypt) ==="
apt-get install -y certbot python3-certbot-nginx

echo ""
echo "============================================================"
echo "Installation des services terminee."
echo "Prochaines etapes MANUELLES :"
echo "  1. Creer la base de donnees :"
echo "       sudo -u postgres createdb smart_gestion_pro"
echo "       sudo -u postgres psql -c \"ALTER USER postgres PASSWORD 'CHANGEZ_MOI';\""
echo "  2. Copier le code de l'application sur ce serveur (git clone ou scp)"
echo "  3. cd backend && npm ci --omit=dev && npm run build"
echo "  4. Copier .env.example vers .env et renseigner les vraies valeurs"
echo "     (JWT_SECRET fort, mot de passe DB, FRONTEND_URL...)"
echo "  5. npm run migration:run"
echo "  6. Configurer Nginx (voir deploy/nginx.conf.example)"
echo "  7. Demarrer avec PM2 : pm2 start dist/main.js --name smart-gestion-pro"
echo "     puis : pm2 save && pm2 startup"
echo "  8. Activer SSL : certbot --nginx -d votredomaine.com"
echo "============================================================"
