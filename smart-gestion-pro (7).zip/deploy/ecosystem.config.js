// Configuration PM2 pour Smart Gestion Pro sur un VPS 1 vCPU / 4GB RAM.
// Usage : pm2 start deploy/ecosystem.config.js
module.exports = {
  apps: [
    {
      name: 'smart-gestion-pro',
      script: 'dist/main.js',
      cwd: '/var/www/smart-gestion-pro/backend',
      // Un seul coeur disponible : inutile (et contre-productif) de lancer
      // plusieurs instances en mode cluster, ca se battrait pour le meme CPU.
      instances: 1,
      exec_mode: 'fork',
      // Redemarre automatiquement si la memoire depasse cette limite —
      // filet de securite contre une fuite memoire sur une machine a 4GB.
      max_memory_restart: '600M',
      env: {
        NODE_ENV: 'production',
      },
      // Redemarrage automatique en cas de crash, avec un delai croissant
      // pour eviter une boucle de redemarrage infernale si l'erreur persiste.
      autorestart: true,
      max_restarts: 10,
      restart_delay: 4000,
      error_file: '/var/log/smart-gestion-pro/error.log',
      out_file: '/var/log/smart-gestion-pro/out.log',
      time: true,
    },
  ],
};
