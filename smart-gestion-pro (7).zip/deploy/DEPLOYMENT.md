# Deploiement sur Hostinger VPS KVM 1 (1 vCPU / 4GB RAM)

Guide complet et realiste pour cette machine specifique. Rien n'est glisse
sous le tapis : les limites du KVM 1 sont mentionnees explicitement la ou
elles comptent.

## 0. Avant de commencer

- VPS KVM 1 cree sur Hostinger, Ubuntu 22.04 ou 24.04, datacenter France
  (le plus proche du Maroc parmi les options Hostinger)
- Un nom de domaine pointant vers l'IP du VPS (enregistrement A) — necessaire
  pour le HTTPS (Let's Encrypt ne fonctionne pas sur une IP nue)
- Acces SSH root au VPS

## 1. Installation des services

```bash
scp -r smart-gestion-pro root@VOTRE_IP:/var/www/
ssh root@VOTRE_IP
cd /var/www/smart-gestion-pro
bash deploy/setup.sh
```

Ce script installe : Node.js 20, PostgreSQL, Redis, Nginx, PM2, Certbot, un
fichier swap de 2GB, et configure le pare-feu (UFW). Voir le detail des
etapes manuelles affichees a la fin du script.

## 2. Base de donnees

```bash
sudo -u postgres createdb smart_gestion_pro
sudo -u postgres psql -c "ALTER USER postgres PASSWORD 'UN_MOT_DE_PASSE_FORT_UNIQUE';"
```

**Important** : PostgreSQL et Redis n'ecoutent par defaut que sur
`localhost` — ne les exposez jamais sur l'IP publique (0.0.0.0). Verifiez
dans `/etc/postgresql/*/main/postgresql.conf` que `listen_addresses` reste
`localhost`.

## 3. Configuration de l'application

```bash
cd backend
cp .env.example .env
nano .env
```

Renseignez au minimum :
- `DB_PASSWORD` : le mot de passe choisi a l'etape 2
- `JWT_SECRET` : une chaine aleatoire longue et unique — generez-en une avec
  `openssl rand -hex 32`, ne gardez jamais la valeur par defaut du fichier
  d'exemple
- `NODE_ENV=production`
- `FRONTEND_URL` : l'URL de votre domaine (ex: `https://votredomaine.com`),
  pour que le CORS n'accepte que votre propre frontend

## 4. Build et migrations

```bash
npm ci --omit=dev
npm run build
npm run migration:run
```

Ceci cree toutes les tables via les migrations versionnees (voir
`src/migrations/`) — **jamais** via `synchronize`, qui est desactive
automatiquement quand `NODE_ENV=production` (voir `src/config/database.config.ts`).

## 5. Donnees initiales (permissions, entreprise de demo)

```bash
node scripts/generate-password-hash.js VotreMotDePasseAdmin
# copier le hash affiche dans docs/seed-initial-data.sql a la place de <HASH_GENERE>
sudo -u postgres psql -d smart_gestion_pro -f ../docs/seed-initial-data.sql
```

**Changez immediatement l'email et le mot de passe de l'entreprise de demo**
une fois connecte, ou supprimez-la et creez la votre via l'API.

## 6. Frontend

```bash
mkdir -p /var/www/smart-gestion-pro/frontend
cp ../frontend/index.html /var/www/smart-gestion-pro/frontend/
```

Sur l'ecran de connexion du frontend, l'adresse de l'API doit etre
`https://votredomaine.com/api` (pas `localhost`) une fois en production.

## 7. Nginx + HTTPS

```bash
cp deploy/nginx.conf.example /etc/nginx/sites-available/smart-gestion-pro
nano /etc/nginx/sites-available/smart-gestion-pro   # remplacer "votredomaine.com"
ln -s /etc/nginx/sites-available/smart-gestion-pro /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
certbot --nginx -d votredomaine.com
```

## 8. Demarrage de l'application (PM2)

```bash
mkdir -p /var/log/smart-gestion-pro
pm2 start deploy/ecosystem.config.js
pm2 save
pm2 startup   # suivre l'instruction affichee pour demarrer PM2 au boot
```

Verifier : `pm2 status`, `pm2 logs smart-gestion-pro`

## Limites reelles du KVM 1 a connaitre

- **1 seul vCPU** : Node.js, PostgreSQL et Redis se partagent le meme coeur.
  Sous charge normale (quelques dizaines d'utilisateurs), c'est suffisant.
  Sous charge forte simultanee (plusieurs OCR ou generations de rapport en
  meme temps), attendez-vous a du ralentissement, pas a un crash — le swap
  et les limites PM2 evitent l'arret brutal.
- **4GB RAM** : confortable pour ce profil d'usage, mais evitez de lancer
  l'OCR (Tesseract.js) sur beaucoup de documents en parallele.
- Si l'usage grandit reellement (plusieurs entreprises actives, usage
  quotidien intensif), passer a un KVM 2 (2 vCPU / 8GB) est simple chez
  Hostinger — augmentation des ressources sans migration de donnees.

## Sauvegardes en production

Le module Sauvegardes (`POST /api/sauvegardes`) declenche un `pg_dump` local.
**Automatisez-le** avec une tache cron, et copiez le resultat hors du VPS
(un simple `scp` vers un autre serveur, ou un stockage externe) — une
sauvegarde qui reste uniquement sur le meme disque que la base ne protege
pas contre une panne disque.

Exemple de cron (tous les jours a 3h du matin) :
```
0 3 * * * curl -s -X POST https://votredomaine.com/api/sauvegardes -H "Authorization: Bearer VOTRE_TOKEN_SERVICE"
```

## Checklist de securite avant mise en production reelle

- [ ] `JWT_SECRET` change (valeur unique, jamais celle de l'exemple)
- [ ] Mot de passe PostgreSQL fort et unique
- [ ] Compte admin de demo (`admin@demo.ma`) supprime ou mot de passe change
- [ ] `FRONTEND_URL` configure (CORS restreint, pas `*`)
- [ ] HTTPS actif (certbot) — ne jamais transmettre de mot de passe en HTTP
- [ ] UFW actif, seuls les ports 22/80/443 ouverts
- [ ] Sauvegardes automatisees ET copiees hors du VPS
- [ ] `NODE_ENV=production` (desactive `synchronize`, active les migrations)
