/**
 * EMPLOYES-BRIDGE — collaborateurs internes (PIN) de l'appli Bibliotheque.
 * L'authentification reelle au site reste exclusivement via Smart Gestion
 * Pro (email/mot de passe, JWT) ; ce module ne fait que persister les
 * codes PIN et permissions internes utilises pour le changement rapide de
 * caissier UNE FOIS deja connecte — ce n'est pas une barriere de securite
 * supplementaire, seulement une commodite d'identification interne.
 */
(function () {
  function api(path, options = {}) {
    const token = localStorage.getItem('sgp_token') || sessionStorage.getItem('sgp_token');
    const base = window.SGP_API_BASE || (window.location.origin + '/api');
    return fetch(base + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: 'Bearer ' + token } : {}),
        ...(options.headers || {}),
      },
    }).then(async (res) => {
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error((body && body.message) || `Erreur HTTP ${res.status}`);
      return body;
    });
  }

  function versFormeBibliotheque(e) {
    return {
      id: e.id, name: e.nom, email: e.email || "", role: e.role || "",
      pin: e.pin, active: e.actif, permissions: e.permissions || [],
    };
  }

  async function chargerEmployesReels() {
    const employes = await api('/employes-internes');
    return employes.map(versFormeBibliotheque);
  }

  async function creerEmployeReel(champs) {
    const cree = await api('/employes-internes', {
      method: 'POST',
      body: JSON.stringify({
        nom: champs.name, email: champs.email || undefined, role: champs.role || undefined,
        pin: champs.pin, actif: champs.active !== false, permissions: champs.permissions || [],
      }),
    });
    return versFormeBibliotheque(cree);
  }

  async function modifierEmployeReel(id, champs) {
    const modifie = await api(`/employes-internes/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({
        nom: champs.name, email: champs.email || undefined, role: champs.role || undefined,
        pin: champs.pin, actif: champs.active !== false, permissions: champs.permissions || [],
      }),
    });
    return versFormeBibliotheque(modifie);
  }

  async function supprimerEmployeReel(id) {
    await api(`/employes-internes/${id}`, { method: 'DELETE' });
  }

  window.employesBridge = { chargerEmployesReels, creerEmployeReel, modifierEmployeReel, supprimerEmployeReel };
})();
