/**
 * ============================================================================
 * CLIENTS-BRIDGE — relie le carnet clients de l'appli Bibliotheque a la
 * vraie table Clients de Smart Gestion Pro, meme principe que produits-bridge.js.
 * ============================================================================
 */
(function () {
  function api(path, options = {}) {
    const token = localStorage.getItem('sgp_token') || sessionStorage.getItem('sgp_token');
    const base = window.SGP_API_BASE || (window.location.origin + '/api');
    return fetch(base + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: 'Bearer ' + token } : {}),
        ...(options.headers || {}),
      },
    }).then(async (res) => {
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error((body && body.message) || `Erreur HTTP ${res.status}`);
      return body;
    });
  }

  // Note : les points de fidelite (loyaltyPoints) n'ont pas d'equivalent
  // dans le modele Client de Smart Gestion Pro — ils restent geres
  // uniquement dans le bloc JSON local pour l'instant.
  function versFormeBibliotheque(client) {
    return {
      id: client.id,
      name: client.nom,
      phone: client.telephone || "",
      email: client.email || "",
      address: client.adresse || "",
      credit: Number(client.solde) || 0,
      loyaltyPoints: Number(client.pointsFidelite) || 0,
    };
  }

  async function chargerClientsReels() {
    const clients = await api('/clients');
    return clients.map(versFormeBibliotheque);
  }

  async function creerClientReel(champsBibliotheque) {
    const cree = await api('/clients', {
      method: 'POST',
      body: JSON.stringify({
        nom: champsBibliotheque.name,
        telephone: champsBibliotheque.phone || undefined,
        email: champsBibliotheque.email || undefined,
        adresse: champsBibliotheque.address || undefined,
        pointsFidelite: Number(champsBibliotheque.loyaltyPoints) || 0,
      }),
    });
    return versFormeBibliotheque(cree);
  }

  async function modifierClientReel(id, champsBibliotheque) {
    const modifie = await api(`/clients/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({
        nom: champsBibliotheque.name,
        telephone: champsBibliotheque.phone || undefined,
        email: champsBibliotheque.email || undefined,
        adresse: champsBibliotheque.address || undefined,
        pointsFidelite: Number(champsBibliotheque.loyaltyPoints) || 0,
      }),
    });
    return versFormeBibliotheque(modifie);
  }

  async function supprimerClientReel(id) {
    await api(`/clients/${id}`, { method: 'DELETE' });
  }

  // ---- Synchronisation credit/points de fidelite : meme principe que le ----
  // ---- stock (point d'entree centralise dans persist(), voir App.jsx) -----
  async function synchroniserClients(clientsAvant, clientsApres) {
    const avantParId = new Map(clientsAvant.map((c) => [c.id, c]));
    for (const client of clientsApres) {
      const avant = avantParId.get(client.id);
      if (!avant) continue;
      const creditChange = Number(avant.credit) !== Number(client.credit);
      const pointsChange = Number(avant.loyaltyPoints) !== Number(client.loyaltyPoints);
      if (!creditChange && !pointsChange) continue;
      try {
        // Le "credit" (montant du au commerce) est gere via le champ solde,
        // deja mis a jour automatiquement par les ventes/paiements reels
        // cote serveur — on ne synchronise ici QUE les points de fidelite,
        // qui n'ont pas d'autre mecanisme de mise a jour cote serveur.
        if (pointsChange) {
          await api(`/clients/${client.id}`, {
            method: 'PATCH',
            body: JSON.stringify({ pointsFidelite: Number(client.loyaltyPoints) || 0 }),
          });
        }
      } catch (e) {
        console.error('Synchronisation client echouee pour', client.name, e.message);
      }
    }
  }

  window.clientsBridge = {
    chargerClientsReels,
    creerClientReel,
    modifierClientReel,
    supprimerClientReel,
    synchroniserClients,
  };
})();
