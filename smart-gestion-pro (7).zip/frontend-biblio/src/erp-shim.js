/**
 * ============================================================================
 * ERP-SHIM — remplace window.erpApi (qui existait via Electron/preload.js)
 * par de vrais equivalents navigateur, pour que l'application React d'origine
 * fonctionne SANS AUCUNE MODIFICATION de sa logique metier (App.jsx).
 * ============================================================================
 *
 * Mapping des fonctions :
 *   loadData / saveData      -> API Smart Gestion Pro (PostgreSQL, multi-tenant)
 *   savePdf / saveXlsx       -> telechargement navigateur natif (Blob + <a download>)
 *   printHtml                -> fenetre d'impression navigateur (window.print())
 *   getPrinters               -> liste vide (les navigateurs ne donnent pas acces
 *                                aux imprimantes systeme ; la boite de dialogue
 *                                d'impression du navigateur permet quand meme
 *                                de choisir l'imprimante manuellement)
 *   exportBackup / importBackup -> telechargement / selection de fichier .json
 *   getSyncConfig / chooseSyncFolder / setSyncConfig
 *                             -> desactives (obsoletes : la synchronisation
 *                                multi-poste est desormais native et automatique
 *                                via le serveur, plus besoin de dossier partage)
 */
(function () {
  const API_BASE = window.SGP_API_BASE || (window.location.origin + '/api');
  const TOKEN_KEY = 'sgp_token';

  function getToken() {
    return localStorage.getItem(TOKEN_KEY) || sessionStorage.getItem(TOKEN_KEY);
  }

  async function appelApi(path, options = {}) {
    const token = getToken();
    const res = await fetch(API_BASE + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: 'Bearer ' + token } : {}),
        ...(options.headers || {}),
      },
    });
    if (!res.ok) {
      const body = await res.json().catch(() => null);
      throw new Error((body && body.message) || `Erreur HTTP ${res.status}`);
    }
    return res.json();
  }

  function telechargerBlob(nomFichier, blob) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = nomFichier;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return true;
  }

  function base64VersBlob(base64, typeContenu) {
    const propre = base64.includes(',') ? base64.split(',')[1] : base64;
    const octets = atob(propre);
    const tableau = new Uint8Array(octets.length);
    for (let i = 0; i < octets.length; i++) tableau[i] = octets.charCodeAt(i);
    return new Blob([tableau], { type: typeContenu });
  }

  window.erpApi = {
    // ---------------- Donnees metier (remplace le fichier .db local) ----------------
    // Verrouillage optimiste : on retient la version chargee, et on la
    // renvoie a chaque sauvegarde. Si le serveur la refuse (quelqu'un
    // d'autre a sauvegarde entre temps), on le signale clairement au lieu
    // d'ecraser silencieusement son travail.
    _derniereVersion: 0,

    loadData: async () => {
      const reponse = await appelApi('/bibliotheque/data');
      window.erpApi._derniereVersion = reponse.version || 0;
      return reponse.donnees;
    },
    saveData: async (jsonString) => {
      try {
        const reponse = await appelApi('/bibliotheque/data', {
          method: 'PUT',
          body: JSON.stringify({ donnees: jsonString, version: window.erpApi._derniereVersion }),
        });
        window.erpApi._derniereVersion = reponse.version;
        return true;
      } catch (erreur) {
        if (String(erreur.message || '').includes('modifie')) {
          // Conflit de version detecte : on previent clairement au lieu de
          // silencieusement perdre les changements de quelqu'un d'autre.
          alert(
            "⚠️ Quelqu'un d'autre a enregistre des changements entre temps.\n\n" +
              'La page va se recharger pour recuperer la version la plus recente. ' +
              'Vos derniers changements non enregistres seront perdus — verifiez-les ' +
              'avant de les ressaisir.',
          );
          window.location.reload();
          return false;
        }
        throw erreur;
      }
    },

    // ---------------- Sauvegarde/restauration manuelle (.json) ----------------
    exportBackup: async (jsonString) => {
      const horodatage = new Date().toISOString().slice(0, 10);
      telechargerBlob(`sauvegarde-${horodatage}.json`, new Blob([jsonString], { type: 'application/json' }));
      return true;
    },
    importBackup: async () => {
      return new Promise((resolve) => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json';
        input.onchange = () => {
          const fichier = input.files[0];
          if (!fichier) return resolve(null);
          const lecteur = new FileReader();
          lecteur.onload = () => resolve(lecteur.result);
          lecteur.onerror = () => resolve(null);
          lecteur.readAsText(fichier);
        };
        input.click();
      });
    },

    // ---------------- Synchronisation reseau local (obsolete sur le web) ----------------
    // La synchronisation multi-poste est desormais automatique via le serveur
    // (toutes les caisses lisent/ecrivent la meme base). Ces fonctions restent
    // presentes pour ne pas casser l'interface Parametres, mais n'ont plus d'effet.
    getSyncConfig: async () => ({ syncEnabled: false, syncFolderPath: null }),
    chooseSyncFolder: async () => null,
    setSyncConfig: async () => false,

    // ---------------- Export PDF / Excel (telechargement navigateur) ----------------
    savePdf: async (nomParDefaut, base64) => {
      telechargerBlob(nomParDefaut, base64VersBlob(base64, 'application/pdf'));
      return true;
    },
    saveXlsx: async (nomParDefaut, base64) => {
      telechargerBlob(
        nomParDefaut,
        base64VersBlob(base64, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
      );
      return true;
    },

    // ---------------- Impression (fenetre d'impression du navigateur) ----------------
    printHtml: async (html) => {
      const fenetre = window.open('', '_blank');
      if (!fenetre) return { error: "Fenetre d'impression bloquee par le navigateur (autorisez les pop-ups pour ce site)." };
      fenetre.document.write(html);
      fenetre.document.close();
      // Laisse le temps au navigateur de mettre en page avant d'imprimer
      setTimeout(() => {
        fenetre.focus();
        fenetre.print();
      }, 300);
      return true;
    },
    getPrinters: async () => [],
  };
})();
