import React, { useState, useEffect, useRef, useMemo } from "react";
import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";
import ARABIC_FONT_BASE64 from "./arabicFont.js";
import {
  LayoutDashboard, ShoppingCart, FileText, PackagePlus, Truck, Boxes,
  Heart, TrendingUp, DollarSign, BarChart2, Shield, Settings as SettingsIcon,
  Search, Plus, Minus, Trash2, Printer, Download, Eye, Pencil, X, Check,
  Menu, Gift, Users, AlertTriangle, ChevronDown, LogOut, Lock, Building2,
  ReceiptText, PiggyBank, Wallet, Package, MapPin, CalendarClock, Globe, Wrench, RefreshCw, HandCoins, CreditCard
} from "lucide-react";

// ---------- Helpers ----------
const uid = (p = "id") => `${p}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
const todayISO = () => new Date().toISOString().slice(0, 10);
const fmtDate = (iso) => {
  const d = new Date(iso);
  return d.toLocaleDateString("fr-FR");
};
const fmtMoney = (n, cur = "DH") => `${(Number(n) || 0).toFixed(2)} ${cur}`;

// ---------- i18n (Français / Arabe) ----------
const TRANSLATIONS = {
  fr: {
    app_professional: "PROFESSIONNEL",
    nav_dashboard: "Tableau de bord",
    nav_pos: "Caisse Enregistreuse",
    nav_invoices: "Factures & Devis",
    nav_purchases: "Achats & Approvis.",
    nav_suppliers: "Fournisseurs",
    nav_products: "Catalogue Produits",
    nav_services: "Services",
    nav_clients: "Fidélité & Clients",
    nav_stock: "Suivi de Stocks",
    nav_expenses: "Dépenses & Frais",
    nav_reports: "Rapports & Chiffres",
    nav_analysis: "Analyse",
    nav_security: "Sécurité & Rôles",
    nav_securitylog: "Journal de Sécurité",
    nav_settings: "Paramètres",

    login_subtitle: "Connexion à la caisse — code PIN",
    login_placeholder: "Code PIN (4 chiffres)",
    login_button: "Se connecter",
    login_default_code: "Code par défaut : 1234",
    login_error: "Code PIN incorrect.",

    cashier_active: "Caisse Active",
    cashier_closed: "Caisse Fermée",
    cash_balance: "Solde",
    close_day: "Clôturer la journée",
    logout: "Déconnexion",

    dashboard_title: "Tableau de Bord",
    dashboard_subtitle: "Vue d'ensemble de la performance commerciale et de l'état des stocks.",
    kpi_ca_day: "Chiffre d'Affaires (Jour)",
    kpi_ca_month: "Chiffre d'Affaires (Mois)",
    kpi_net_profit: "Bénéfice Net (Mois)",
    kpi_expenses_month: "Dépenses Pro (Mois)",
    kpi_client_credit: "Crédit Global Clients",
    kpi_supplier_debt: "Dettes Globales Fournisseurs",
    kpi_pending: "En attente",
    kpi_topay: "À payer",
    chart_ca_7days: "Chiffre d'Affaires (7 derniers jours)",
    chart_sales_by_category: "Ventes par Catégorie",
    chart_top_products: "Produits les plus vendus",
    no_data: "Aucune donnée pour le moment.",
    no_sales_yet: "Aucune vente enregistrée pour le moment.",
    total: "Total",

    page_pos_title: "Caisse Enregistreuse",
    page_pos_subtitle: "Encaissez vos ventes rapidement.",
    page_invoices_title: "Documents Commerciaux",
    page_invoices_subtitle: "Gérez vos devis, bons de livraison (BL), factures clients et retours de marchandises.",
    page_purchases_title: "Factures d'Achats",
    page_purchases_subtitle: "Consultez l'historique des entrées d'achats fournisseurs.",
    page_suppliers_title: "Fournisseurs",
    page_suppliers_subtitle: "Gérez votre répertoire de fournisseurs et leurs soldes.",
    page_products_title: "Catalogue Produits",
    page_products_subtitle: "Ajoutez, modifiez ou importez vos produits et gérez vos catégories.",
    page_clients_title: "Fidélité & Clients",
    page_clients_subtitle: "Gérez votre répertoire clients, crédits et points de fidélité.",
    page_stock_title: "Mouvements de Stock",
    page_stock_subtitle: "Suivi en temps réel de toutes les entrées, sorties et ajustements manuels d'inventaire.",
    page_expenses_title: "Dépenses & Frais",
    page_expenses_subtitle: "Enregistrez les sorties de fonds pour fournitures, loyers, salaires ou frais généraux.",
    page_reports_title: "Rapports & Chiffres",
    page_reports_subtitle: "Générez des rapports détaillés par type d'activité, filtrables par période.",
    page_analysis_title: "Analyse et Rapports",
    page_security_title: "Sécurité & Rôles",
    page_security_subtitle: "Gérez les comptes des collaborateurs, leurs codes PIN de caisse et configurez les droits d'accès granulaires par rôle.",
    page_securitylog_title: "Journal de Sécurité",
    page_securitylog_subtitle: "Historique complet des connexions, modifications de comptes et actions sensibles effectuées dans l'application.",
    page_settings_title: "Paramètres de l'Établissement",
    page_settings_subtitle: "Gérez les coordonnées d'en-tête de vos reçus, informations fiscales (ICE/IF), devise principale et sauvegardes de données.",

    settings_profile_header: "Profil & En-tête des Factures",
    settings_language_header: "Langue de l'Application",
    settings_language_label: "Choisir la langue",
    lang_fr: "Français",
    lang_ar: "العربية",
    settings_storage_header: "Stockage et Sauvegarde",
    settings_danger_header: "Zone de Danger",
    settings_admin_header: "Administration du Compte Principal (Chef d'Établissement)",
  },
  ar: {
    app_professional: "احترافي",
    nav_dashboard: "لوحة التحكم",
    nav_pos: "الكاسيسة",
    nav_invoices: "الفواتير والعروض",
    nav_purchases: "المشتريات والتزويد",
    nav_suppliers: "الموردون",
    nav_products: "كتالوج المنتجات",
    nav_services: "الخدمات",
    nav_clients: "الزبناء والولاء",
    nav_stock: "تتبع المخزون",
    nav_expenses: "المصاريف",
    nav_reports: "التقارير والأرقام",
    nav_analysis: "التحليل",
    nav_security: "الأمان والأدوار",
    nav_securitylog: "سجل الأمان",
    nav_settings: "الإعدادات",

    login_subtitle: "تسجيل الدخول للكاسيسة — كود PIN",
    login_placeholder: "كود PIN (4 أرقام)",
    login_button: "تسجيل الدخول",
    login_default_code: "الكود الافتراضي: 1234",
    login_error: "كود PIN خاطئ.",

    cashier_active: "الكاسيسة نشطة",
    cashier_closed: "الكاسيسة مغلقة",
    cash_balance: "الرصيد",
    close_day: "إغلاق اليومية",
    logout: "تسجيل الخروج",

    dashboard_title: "لوحة التحكم",
    dashboard_subtitle: "نظرة عامة على الأداء التجاري وحالة المخزون.",
    kpi_ca_day: "رقم المعاملات (اليوم)",
    kpi_ca_month: "رقم المعاملات (الشهر)",
    kpi_net_profit: "صافي الربح (الشهر)",
    kpi_expenses_month: "المصاريف المهنية (الشهر)",
    kpi_client_credit: "إجمالي ديون الزبناء",
    kpi_supplier_debt: "إجمالي ديون الموردين",
    kpi_pending: "في الانتظار",
    kpi_topay: "يجب دفعه",
    chart_ca_7days: "رقم المعاملات (آخر 7 أيام)",
    chart_sales_by_category: "المبيعات حسب الفئة",
    chart_top_products: "المنتجات الأكثر مبيعًا",
    no_data: "لا توجد بيانات حاليًا.",
    no_sales_yet: "لا توجد مبيعات مسجلة حاليًا.",
    total: "المجموع",

    page_pos_title: "الكاسيسة",
    page_pos_subtitle: "سجّل مبيعاتك بسرعة.",
    page_invoices_title: "الوثائق التجارية",
    page_invoices_subtitle: "دبّر الفواتير، سندات التسليم، والمرتجعات.",
    page_purchases_title: "فواتير الشراء",
    page_purchases_subtitle: "تصفح تاريخ مشترياتك من الموردين.",
    page_suppliers_title: "الموردون",
    page_suppliers_subtitle: "دبّر لائحة الموردين وحساباتهم.",
    page_products_title: "كتالوج المنتجات",
    page_products_subtitle: "أضف، عدّل، أو استورد منتجاتك ودبّر الفئات.",
    page_clients_title: "الزبناء والولاء",
    page_clients_subtitle: "دبّر لائحة الزبناء، الديون، ونقاط الولاء.",
    page_stock_title: "حركات المخزون",
    page_stock_subtitle: "تتبع لحظي لكل الدخول والخروج والتعديلات اليدوية.",
    page_expenses_title: "المصاريف",
    page_expenses_subtitle: "سجّل مصاريف الأدوات، الكراء، الأجور، أو المصاريف العامة.",
    page_reports_title: "التقارير والأرقام",
    page_reports_subtitle: "أنشئ تقارير مفصلة حسب نوع النشاط، قابلة للتصفية بالفترة.",
    page_analysis_title: "التحليل والتقارير",
    page_security_title: "الأمان والأدوار",
    page_security_subtitle: "دبّر حسابات الموظفين، أكواد PIN، وحقوق الوصول لكل دور.",
    page_securitylog_title: "سجل الأمان",
    page_securitylog_subtitle: "تاريخ كامل لعمليات تسجيل الدخول والتغييرات الحساسة في التطبيق.",
    page_settings_title: "إعدادات المؤسسة",
    page_settings_subtitle: "دبّر معلومات فواتيرك، المعلومات الضريبية (ICE/IF)، العملة، والنسخ الاحتياطية.",

    settings_profile_header: "الملف الشخصي ورأس الفواتير",
    settings_language_header: "لغة التطبيق",
    settings_language_label: "اختر اللغة",
    lang_fr: "Français",
    lang_ar: "العربية",
    settings_storage_header: "التخزين والنسخ الاحتياطي",
    settings_danger_header: "منطقة الخطر",
    settings_admin_header: "إدارة الحساب الرئيسي (رئيس المؤسسة)",
  },
};

const THEME_PRESETS = [
  { name: "Smart Gestion Pro", primary: "#163a7a", secondary: "#0e5f4e" },
  { name: "Bleu Classique", primary: "#2563eb", secondary: "#64748b" },
  { name: "Émeraude", primary: "#059669", secondary: "#475569" },
  { name: "Violet Royal", primary: "#7c3aed", secondary: "#6b7280" },
  { name: "Rouge Cerise", primary: "#dc2626", secondary: "#57534e" },
  { name: "Orange Vif", primary: "#ea580c", secondary: "#78716c" },
  { name: "Rose Fuchsia", primary: "#db2777", secondary: "#71717a" },
  { name: "Turquoise", primary: "#0891b2", secondary: "#52525b" },
  { name: "Doré", primary: "#ca8a04", secondary: "#57534e" },
  { name: "Nuit (Indigo)", primary: "#4338ca", secondary: "#374151" },
  { name: "Anthracite", primary: "#1e293b", secondary: "#94a3b8" },
];

function darkenColor(hex, amount = 0.85) {
  if (!hex || !/^#?[0-9a-fA-F]{6}$/.test(hex.replace("#", ""))) return "#0f172a";
  const c = hex.replace("#", "");
  const r = parseInt(c.substring(0, 2), 16);
  const g = parseInt(c.substring(2, 4), 16);
  const b = parseInt(c.substring(4, 6), 16);
  const mix = (channel) => Math.round(channel * (1 - amount));
  return `rgb(${mix(r)}, ${mix(g)}, ${mix(b)})`;
}

function makeRef(settings, docType, counter) {
  const prefixes = settings.refPrefixes || {};
  const defaults = { invoice: "FAC", quote: "DEV", delivery: "BL", return: "RET", purchase: "ACH", purchaseOrder: "BC" };
  const prefix = prefixes[docType] || defaults[docType];
  const startNumbers = settings.refStartNumbers || {};
  const startAt = Number(startNumbers[docType]) || Number(settings.refStartNumber) || 1;
  const number = startAt + counter;
  const includeYear = settings.refIncludeYear !== false;
  const padded = String(number).padStart(5, "0");
  return includeYear ? `${prefix}-${new Date().getFullYear()}-${padded}` : `${prefix}-${padded}`;
}

function t(lang, key) {
  return (TRANSLATIONS[lang] && TRANSLATIONS[lang][key]) || TRANSLATIONS.fr[key] || key;
}

const STORAGE_KEY = "gestionpro_erp_data";

// ---------- XLSX helper ----------
async function saveXlsxFile(rows, sheetName, filename) {
  const worksheet = XLSX.utils.aoa_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName);
  const wbout = XLSX.write(workbook, { bookType: "xlsx", type: "base64" });
  try {
    return await window.erpApi.saveXlsx(filename, wbout);
  } catch (e) {
    console.error("Erreur export Excel:", e);
    return false;
  }
}

// ---------- PDF helpers ----------
// ---------- Support de l'arabe dans les PDF ----------
// jsPDF's built-in fonts (Helvetica) only cover Latin characters — any Arabic
// text drawn with them renders as unreadable garbage. We embed a real Arabic
// font (Noto Naskh Arabic) and switch to it automatically whenever the text
// being drawn contains Arabic script, then switch back for Latin text.
const ARABIC_RANGE = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/;
const arabicFontRegistered = new WeakSet();

function ensureArabicFont(pdf) {
  if (arabicFontRegistered.has(pdf)) return;
  try {
    pdf.addFileToVFS("NotoNaskhArabic.ttf", ARABIC_FONT_BASE64);
    pdf.addFont("NotoNaskhArabic.ttf", "NotoNaskhArabic", "normal");
    arabicFontRegistered.add(pdf);
  } catch (e) {
    // If font registration fails for any reason, fall back silently to the
    // default font rather than breaking PDF generation entirely.
  }
}

// Draws text with jsPDF, automatically using the Arabic font for any text
// that contains Arabic characters, and restoring the previous font afterward.
function smartText(pdf, text, x, y, opts) {
  const str = String(text ?? "");
  if (ARABIC_RANGE.test(str)) {
    ensureArabicFont(pdf);
    const prevFont = pdf.getFont();
    try {
      pdf.setFont("NotoNaskhArabic", "normal");
      pdf.text(str, x, y, opts);
    } finally {
      pdf.setFont(prevFont.fontName, prevFont.fontStyle);
    }
  } else {
    pdf.text(str, x, y, opts);
  }
}

function pdfDrawHeader(doc, settings, title) {
  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 15;

  if (settings.logo) {
    try {
      const format = settings.logo.includes("image/png") ? "PNG" : "JPEG";
      doc.addImage(settings.logo, format, 14, y - 5, 18, 18);
    } catch (e) {
      // Ignore malformed logo, header still renders without it.
    }
  }

  doc.setFont("helvetica", "bold");
  doc.setFontSize(14);
  doc.text(settings.companyName || "Mon Entreprise", settings.logo ? 36 : 14, y + 2);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(90);
  const infoLines = [
    settings.address,
    [settings.phone, settings.email].filter(Boolean).join("  •  "),
    [settings.ice ? `ICE: ${settings.ice}` : "", settings.ifisc ? `IF: ${settings.ifisc}` : "", settings.patente ? `Patente: ${settings.patente}` : "", settings.rc ? `RC: ${settings.rc}` : ""]
      .filter(Boolean)
      .join("   "),
  ].filter(Boolean);
  let infoY = y + 7;
  infoLines.forEach((line) => {
    doc.text(line, settings.logo ? 36 : 14, infoY);
    infoY += 4;
  });

  doc.setDrawColor(220);
  doc.line(14, 32, pageWidth - 14, 32);

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(20);
  doc.text(title, 14, 42);

  return 50; // y position to continue content from
}

function pdfDrawTableHeader(doc, y, columns) {
  doc.setFillColor(243, 244, 246);
  doc.rect(14, y, doc.internal.pageSize.getWidth() - 28, 8, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(60);
  columns.forEach((col) => doc.text(col.label, col.x, y + 5.5, { align: col.align || "left" }));
  return y + 8;
}

async function savePdfFile(doc, filename) {
  const base64 = doc.output("datauristring").split(",")[1];
  try {
    const ok = await window.erpApi.savePdf(filename, base64);
    return ok;
  } catch (e) {
    console.error("Erreur export PDF:", e);
    return false;
  }
}

function generateInvoicePDF(invoice, settings) {
  const doc = new jsPDF({ format: settings.paperFormat || "a4" });
  let y = pdfDrawHeader(doc, settings, `Facture ${invoice.ref}`);
  const pageWidth = doc.internal.pageSize.getWidth();
  const isA5 = pageWidth < 180; // A5 portrait is 148mm wide, A4 is 210mm
  const marginX = isA5 ? 10 : 14;
  const fontSizeBase = isA5 ? 8 : 9;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(isA5 ? 9 : 10);
  doc.setTextColor(30);
  doc.text("Client :", marginX, y);
  smartText(doc, invoice.clientName, marginX + 16, y);
  doc.text(`Date : ${fmtDate(invoice.date)}`, pageWidth - marginX - 46, y);
  y += 8;

  // Column positions are proportions of the actual page width, so the same
  // layout logic works correctly on both A4 (210mm) and A5 (148mm) without
  // any column overlap — verified against real text-width measurements.
  const usableWidth = pageWidth - marginX * 2;
  const columns = [
    { label: "Produit", x: marginX, align: "left", maxWidth: usableWidth * 0.46 },
    { label: "Qté", x: marginX + usableWidth * 0.5, align: "center", maxWidth: usableWidth * 0.1 },
    { label: "Prix U.", x: marginX + usableWidth * 0.72, align: "right", maxWidth: usableWidth * 0.2 },
    { label: "Total", x: pageWidth - marginX, align: "right", maxWidth: usableWidth * 0.2 },
  ];

  const fitText = (text, maxWidth) => {
    let str = String(text ?? "");
    if (doc.getTextWidth(str) <= maxWidth) return str;
    while (str.length > 1 && doc.getTextWidth(str + "…") > maxWidth) {
      str = str.slice(0, -1);
    }
    return str + "…";
  };

  y = pdfDrawTableHeader(doc, y, columns);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(fontSizeBase);
  doc.setTextColor(40);
  invoice.items.forEach((it) => {
    y += isA5 ? 6 : 7;
    if (y > (isA5 ? 190 : 270)) {
      doc.addPage();
      y = 20;
    }
    smartText(doc, fitText(it.name, columns[0].maxWidth), columns[0].x, y, { align: "left" });
    doc.text(String(it.qty), columns[1].x, y, { align: "center" });
    doc.text(fitText(fmtMoney(it.price, settings.currency), columns[2].maxWidth), columns[2].x, y, { align: "right" });
    doc.text(fitText(fmtMoney(it.price * it.qty, settings.currency), columns[3].maxWidth), columns[3].x, y, { align: "right" });
  });

  y += 10;
  doc.setDrawColor(220);
  const totalsLabelX = pageWidth - marginX - usableWidth * 0.35;
  doc.line(totalsLabelX, y - 4, pageWidth - marginX, y - 4);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(fontSizeBase + 1);
  const tvaRate = Number(settings.tvaRate) || 0;
  const totalTTC = invoice.subtotal - (invoice.discount || 0);
  const totalHT = tvaRate > 0 ? totalTTC / (1 + tvaRate / 100) : totalTTC;
  const tvaAmount = totalTTC - totalHT;
  doc.text("Sous-total :", totalsLabelX, y);
  doc.text(fmtMoney(invoice.subtotal, settings.currency), pageWidth - marginX, y, { align: "right" });
  y += 6;
  doc.text("Remise :", totalsLabelX, y);
  doc.text(`-${fmtMoney(invoice.discount, settings.currency)}`, pageWidth - marginX, y, { align: "right" });
  y += 6;
  doc.text(`Total HT :`, totalsLabelX, y);
  doc.text(fmtMoney(totalHT, settings.currency), pageWidth - marginX, y, { align: "right" });
  y += 6;
  doc.text(`TVA (${tvaRate}%) :`, totalsLabelX, y);
  doc.text(fmtMoney(tvaAmount, settings.currency), pageWidth - marginX, y, { align: "right" });
  y += 7;
  doc.setFont("helvetica", "bold");
  doc.setFontSize(isA5 ? 10 : 11);
  doc.text("TOTAL TTC :", totalsLabelX, y);
  doc.text(fmtMoney(invoice.total, settings.currency), pageWidth - marginX, y, { align: "right" });

  // ---- Footer with complete company legal/banking info, on every page ----
  const drawFooter = () => {
    const pageHeight = doc.internal.pageSize.getHeight();
    const footerY = pageHeight - 14;
    doc.setDrawColor(220);
    doc.setLineWidth(0.3);
    doc.line(marginX, footerY - 6, pageWidth - marginX, footerY - 6);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(isA5 ? 6 : 7);
    doc.setTextColor(120);
    const footerLine1 = [settings.address, settings.phone ? `Tél : ${settings.phone}` : ""].filter(Boolean).join("   •   ");
    const footerLine2 = [
      settings.ice ? `ICE : ${settings.ice}` : "",
      settings.ifisc ? `IF : ${settings.ifisc}` : "",
      settings.rc ? `RC : ${settings.rc}` : "",
      settings.cnss ? `CNSS : ${settings.cnss}` : "",
      settings.rib ? `RIB : ${settings.rib}` : "",
    ].filter(Boolean).join("   •   ");
    doc.text(footerLine1, pageWidth / 2, footerY - 1, { align: "center" });
    doc.text(footerLine2, pageWidth / 2, footerY + 4, { align: "center" });
  };
  const totalPages = doc.internal.getNumberOfPages();
  for (let p = 1; p <= totalPages; p++) {
    doc.setPage(p);
    drawFooter();
  }

  return savePdfFile(doc, `${invoice.ref}.pdf`);
}

function drawReceiptContent(doc, invoice, settings) {
  const width = 80;
  const centerX = width / 2;
  let y = 8;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.text(settings.companyName || "Mon Entreprise", centerX, y, { align: "center" });
  y += 5;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(70);
  [settings.address, settings.phone, settings.ice ? `ICE: ${settings.ice}` : ""].filter(Boolean).forEach((line) => {
    doc.text(line, centerX, y, { align: "center" });
    y += 3.5;
  });

  y += 1;
  doc.setDrawColor(0);
  doc.setLineDashPattern([0.8, 0.8], 0);
  doc.line(4, y, width - 4, y);
  y += 4;

  doc.setFontSize(8);
  doc.setTextColor(0);
  doc.text(`Ticket: ${invoice.ref}`, 4, y);
  y += 4;
  doc.text(`Date: ${fmtDate(invoice.date)} ${new Date(invoice.date).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`, 4, y);
  y += 4;
  doc.text(`Client: ${invoice.clientName}`, 4, y);
  y += 4;
  doc.line(4, y, width - 4, y);
  y += 4;

  invoice.items.forEach((it) => {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(7.5);
    doc.text(String(it.name).slice(0, 34), 4, y);
    y += 3.6;
    doc.setFont("helvetica", "normal");
    doc.text(`${it.qty} x ${fmtMoney(it.price, settings.currency)}`, 4, y);
    doc.text(fmtMoney(it.price * it.qty, settings.currency), width - 4, y, { align: "right" });
    y += 4.5;
  });

  doc.line(4, y, width - 4, y);
  y += 4.5;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(8);
  doc.text("Sous-total", 4, y);
  doc.text(fmtMoney(invoice.subtotal, settings.currency), width - 4, y, { align: "right" });
  y += 4;
  if (invoice.discount) {
    doc.text("Remise", 4, y);
    doc.text(`-${fmtMoney(invoice.discount, settings.currency)}`, width - 4, y, { align: "right" });
    y += 4;
  }
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.text("TOTAL", 4, y);
  doc.text(fmtMoney(invoice.total, settings.currency), width - 4, y, { align: "right" });
  y += 6;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(70);
  doc.text(`Paiement: ${invoice.payMethod || "-"}`, 4, y);
  y += 6;

  doc.setFont("helvetica", "italic");
  doc.setFontSize(8);
  doc.setTextColor(0);
  doc.text("Merci pour votre confiance !", centerX, y, { align: "center" });
}

function generateReceiptPDF(invoice, settings) {
  const width = 80; // mm — standard thermal receipt width
  const copies = Math.max(1, Math.min(Number(settings.receiptCopies) || 1, 5));
  const doc = new jsPDF({ unit: "mm", format: [width, 200] });

  for (let i = 0; i < copies; i++) {
    if (i > 0) doc.addPage([width, 200]);
    drawReceiptContent(doc, invoice, settings);
  }

  return savePdfFile(doc, `ticket-${invoice.ref}.pdf`);
}

function buildReceiptHTML(invoice, settings) {
  const esc = (s) => String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const itemsHtml = invoice.items
    .map(
      (it) => `
      <div class="line">
        <div class="name">${esc(it.name)}</div>
        <div class="qtyprice">${it.qty} x ${fmtMoney(it.price, settings.currency)}<span class="amt">${fmtMoney(it.price * it.qty, settings.currency)}</span></div>
      </div>`
    )
    .join("");
  const infoLines = [settings.address, settings.phone, settings.ice ? `ICE: ${settings.ice}` : ""].filter(Boolean).map((l) => `<div>${esc(l)}</div>`).join("");
  return `<!DOCTYPE html>
<html><head><meta charset="utf-8" />
<style>
  @page { size: 80mm auto; margin: 4mm 3mm; }
  * { box-sizing: border-box; }
  body { font-family: Arial, Helvetica, sans-serif; width: 72mm; margin: 0; padding: 0 1mm; color: #000; font-size: 11px; }
  .center { text-align: center; }
  .bold { font-weight: bold; }
  .name-co { font-size: 14px; font-weight: bold; text-align: center; }
  .info { text-align: center; font-size: 9px; color: #333; margin-top: 2px; }
  hr { border: none; border-top: 1px dashed #000; margin: 6px 0; }
  .line { display: flex; flex-direction: column; margin-bottom: 3px; }
  .qtyprice { display: flex; justify-content: space-between; font-size: 10px; }
  .amt { font-weight: bold; }
  .totalrow { display: flex; justify-content: space-between; font-size: 12px; font-weight: bold; margin-top: 4px; }
  .footer { text-align: center; font-style: italic; font-size: 10px; margin-top: 8px; }
</style></head>
<body>
  <div class="name-co">${esc(settings.companyName || "Mon Entreprise")}</div>
  <div class="info">${infoLines}</div>
  <hr />
  <div>Ticket: ${esc(invoice.ref)}</div>
  <div>Date: ${fmtDate(invoice.date)} ${new Date(invoice.date).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</div>
  <div>Client: ${esc(invoice.clientName)}</div>
  <hr />
  ${itemsHtml}
  <hr />
  <div class="qtyprice"><span>Sous-total</span><span>${fmtMoney(invoice.subtotal, settings.currency)}</span></div>
  ${invoice.discount ? `<div class="qtyprice"><span>Remise</span><span>-${fmtMoney(invoice.discount, settings.currency)}</span></div>` : ""}
  <div class="totalrow"><span>TOTAL</span><span>${fmtMoney(invoice.total, settings.currency)}</span></div>
  <div class="info" style="margin-top:4px;">Paiement: ${esc(invoice.payMethod || "-")}</div>
  <div class="footer">Merci pour votre confiance !</div>
</body></html>`;
}

async function printReceiptDirect(invoice, settings, showToast) {
  const html = buildReceiptHTML(invoice, settings);
  try {
    const result = await window.erpApi.printHtml(html, !!settings.silentPrint, settings.defaultPrinterName || null);
    if (result === true) {
      showToast && showToast("Impression envoyée à l'imprimante.");
    } else if (result && result.error) {
      showToast && showToast(`Impression annulée ou échouée : ${result.error}`, "error");
    }
  } catch (e) {
    showToast && showToast("Erreur lors de l'impression.", "error");
  }
}

function generateTablePDF(title, columns, rows, settings) {
  const doc = new jsPDF();
  let y = pdfDrawHeader(doc, settings, title);
  const tableWidth = doc.internal.pageSize.getWidth() - 28;
  const colWidth = tableWidth / columns.length;
  const xs = columns.map((_, i) => 14 + i * colWidth);
  const cellPadding = 2;
  const maxCellWidth = colWidth - cellPadding * 2;

  // Truncate text (adding "…" if needed) so its RENDERED width actually fits
  // within its column, instead of a blind fixed character count — this is
  // what previously let long names overflow into the next column.
  const fitText = (text, maxWidth) => {
    let str = String(text ?? "");
    if (doc.getTextWidth(str) <= maxWidth) return str;
    while (str.length > 1 && doc.getTextWidth(str + "…") > maxWidth) {
      str = str.slice(0, -1);
    }
    return str + "…";
  };

  doc.setFillColor(243, 244, 246);
  doc.rect(14, y, tableWidth, 8, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(60);
  columns.forEach((col, i) => doc.text(fitText(col, maxCellWidth), xs[i] + cellPadding, y + 5.5));
  y += 8;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(40);
  rows.forEach((row) => {
    y += 7;
    if (y > 280) {
      doc.addPage();
      y = 20;
    }
    row.forEach((cell, i) => smartText(doc, fitText(cell, maxCellWidth), xs[i] + cellPadding, y));
  });

  return savePdfFile(doc, `${title.toLowerCase().replace(/\s+/g, "-")}-${todayISO()}.pdf`);
}

function generateReportPDF(kpis, period, settings) {
  const doc = new jsPDF();
  let y = pdfDrawHeader(doc, settings, `Rapport d'Analyse — ${period}`);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(30);
  doc.text(`Généré le ${new Date().toLocaleDateString("fr-FR")}`, 14, y);
  y += 10;

  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(20);
  kpis.forEach(([label, value]) => {
    doc.setFont("helvetica", "normal");
    doc.setTextColor(80);
    doc.text(label, 16, y);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(20);
    doc.text(String(value), 150, y);
    y += 8;
    doc.setDrawColor(235);
    doc.line(14, y - 4, doc.internal.pageSize.getWidth() - 14, y - 4);
  });

  return savePdfFile(doc, `rapport-analyse-${todayISO()}.pdf`);
}


function logEvent(data, actor, action, details) {
  const entry = { id: uid("log"), date: new Date().toISOString(), actor: actor || "Système", action, details: details || "" };
  return [entry, ...(data.securityLog || [])].slice(0, 500);
}

const CATEGORIES_DEFAULT = ["Papeterie", "Livres", "Fournitures Scolaires", "Bureau", "Informatique", "Autre"];
const BRANDS_DEFAULT = ["Samsung", "Danone", "Nivea", "Local"];

const PERMISSIONS = [
  { key: "DASHBOARD", label: "Tableau de bord" },
  { key: "POS_OPEN", label: "POS OPEN — Ouvrir la caisse" },
  { key: "POS_CREATE_SALE", label: "POS CREATE SALE — Créer une vente" },
  { key: "POS_MODIFY_SALE", label: "POS MODIFY SALE — Modifier une vente" },
  { key: "POS_CANCEL_SALE", label: "POS CANCEL SALE — Annuler une vente" },
  { key: "POS_PRINT_RECEIPT", label: "POS PRINT RECEIPT — Imprimer le reçu" },
  { key: "POS_OPEN_DRAWER", label: "POS OPEN DRAWER — Ouvrir le tiroir-caisse" },
  { key: "PRODUCTS_VIEW", label: "PRODUCTS VIEW — Voir les produits" },
  { key: "PRODUCTS_ADD", label: "PRODUCTS ADD — Ajouter des produits" },
  { key: "PRODUCTS_EDIT", label: "PRODUCTS EDIT — Modifier les produits" },
  { key: "PRODUCTS_DELETE", label: "PRODUCTS DELETE — Supprimer des produits" },
  { key: "CLIENTS_MANAGE", label: "CLIENTS MANAGE — Gérer les clients" },
  { key: "SUPPLIERS_MANAGE", label: "SUPPLIERS MANAGE — Gérer les fournisseurs" },
  { key: "STOCK_VIEW", label: "STOCK VIEW — Voir les mouvements de stock" },
  { key: "STOCK_ADJUST", label: "STOCK ADJUST — Ajuster l'inventaire" },
  { key: "EXPENSES_MANAGE", label: "EXPENSES MANAGE — Gérer les dépenses" },
  { key: "REPORTS_VIEW", label: "REPORTS VIEW — Voir les rapports" },
  { key: "SECURITY_MANAGE", label: "SECURITY MANAGE — Gérer la sécurité & rôles" },
  { key: "SETTINGS_MANAGE", label: "SETTINGS MANAGE — Gérer les paramètres" },
];
const ALL_PERMISSION_KEYS = PERMISSIONS.map((p) => p.key);

function demoData() {
  const now = new Date();
  const iso = now.toISOString();
  return {
    settings: {
      companyName: "Smart Gestion Pro",
      phone: "+212 6 00 00 00 00",
      email: "contact@entreprise.ma",
      address: "Adresse de l'entreprise, Ville",
      ice: "000000000000000",
      ifisc: "00000000",
      patente: "00000000",
      rc: "",
      cnss: "",
      rib: "",
      currency: "DH",
      tvaRate: 20,
      color: "#163a7a",
      secondaryColor: "#0e5f4e",
      language: "fr",
      refPrefixes: { invoice: "FAC", quote: "DEV", delivery: "BL", return: "RET", purchase: "ACH" },
      refStartNumbers: { invoice: 1, quote: 1, delivery: 1, return: 1, purchase: 1 },
      refStartNumber: 1,
      receiptCopies: 1,
      paperFormat: "a4",
      posEnabled: true,
      zakatNisab: 0,
      zakatRate: 2.5,
      defaultPrinterName: "",
      silentPrint: false,
      enabledDiscountTypes: { "Aucune": true, "% Pourcentage": true, "Valeur Fixe": true },
      enabledDeliveryOptions: { "Emporté": true, "Gratuite": true, "Payante": true },
      enabledPaymentMethods: { "Cash": true, "Carte": true, "Vir.": true, "Credit": true, "Mixte": true },
      refIncludeYear: true,
      defaultDeliveryFee: 0,
      logo: null,
    },
    employees: [
      { id: uid("emp"), name: "Administrateur", email: "admin@erp.com", role: "Administrateur", pin: "1234", active: true, permissions: [...ALL_PERMISSION_KEYS] },
    ],
    categories: [...CATEGORIES_DEFAULT],
    brands: [...BRANDS_DEFAULT],
    products: [
      { id: uid("prod"), name: "Cahier 100 Pages (Petit Format)", brand: "Local", category: "Papeterie", barcode: "6111100000001", buyPrice: 4, sellPrice: 7, stock: 150, alertThreshold: 20 },
      { id: uid("prod"), name: "Stylo Bille Bleu (Bic)", brand: "Bic", category: "Papeterie", barcode: "6111100000002", buyPrice: 1.5, sellPrice: 3, stock: 300, alertThreshold: 30 },
      { id: uid("prod"), name: "Roman \"Le Petit Prince\"", brand: "Éditions Local", category: "Livres", barcode: "6111100000003", buyPrice: 25, sellPrice: 45, stock: 20, alertThreshold: 5 },
      { id: uid("prod"), name: "Ramette Papier A4 (500 feuilles)", brand: "Local", category: "Papeterie", barcode: "6111100000004", buyPrice: 28, sellPrice: 42, stock: 40, alertThreshold: 8 },
    ],
    services: [
      { id: uid("srv"), name: "Photocopie Noir & Blanc (A4)", category: "Photocopie", price: 0.5 },
      { id: uid("srv"), name: "Photocopie Couleur (A4)", category: "Photocopie", price: 2 },
      { id: uid("srv"), name: "Impression Document (par page)", category: "Impression", price: 1 },
      { id: uid("srv"), name: "Reliure Spirale", category: "Reliure", price: 15 },
      { id: uid("srv"), name: "Plastification A4", category: "Plastification", price: 5 },
    ],
    serviceCategories: ["Photocopie", "Impression", "Reliure", "Plastification", "Autre"],
    clients: [
      { id: uid("cli"), name: "Client de Passage", phone: "", email: "", address: "", loyaltyPoints: 0, credit: 0 },
    ],
    suppliers: [],
    invoices: [],
    quotes: [],
    deliveryNotes: [],
    returns: [],
    purchases: [],
    purchaseOrders: [],
    expenses: [],
    stockMovements: [],
    taxReminders: [],
    zakatHistory: [],
    creditMovements: [],
    securityLog: [
      { id: uid("log"), date: iso, actor: "Système", action: "INSTALLATION", details: "Application installée et initialisée avec le catalogue de démonstration." },
    ],
    cashRegister: { active: true, solde: 1000, openedAt: iso },
    invoiceCounter: 0,
    purchaseCounter: 0,
    purchaseOrderCounter: 0,
    quoteCounter: 0,
    deliveryCounter: 0,
    returnCounter: 0,
  };
}

function normalizeData(loaded) {
  const base = demoData();
  if (!loaded || typeof loaded !== "object") return base;
  return {
    ...base,
    ...loaded,
    settings: { ...base.settings, ...(loaded.settings || {}) },
    employees: Array.isArray(loaded.employees) && loaded.employees.length
      ? loaded.employees.map((e) => ({ active: true, permissions: [...ALL_PERMISSION_KEYS], ...e }))
      : base.employees,
    categories: Array.isArray(loaded.categories) && loaded.categories.length ? loaded.categories : base.categories,
    brands: Array.isArray(loaded.brands) && loaded.brands.length ? loaded.brands : base.brands,
    products: Array.isArray(loaded.products) ? loaded.products : base.products,
    services: Array.isArray(loaded.services) ? loaded.services : base.services,
    serviceCategories: Array.isArray(loaded.serviceCategories) && loaded.serviceCategories.length ? loaded.serviceCategories : base.serviceCategories,
    clients: Array.isArray(loaded.clients) && loaded.clients.length ? loaded.clients : base.clients,
    suppliers: Array.isArray(loaded.suppliers) ? loaded.suppliers : [],
    invoices: Array.isArray(loaded.invoices) ? loaded.invoices : [],
    quotes: Array.isArray(loaded.quotes) ? loaded.quotes : [],
    deliveryNotes: Array.isArray(loaded.deliveryNotes) ? loaded.deliveryNotes : [],
    returns: Array.isArray(loaded.returns) ? loaded.returns : [],
    purchases: Array.isArray(loaded.purchases) ? loaded.purchases : [],
    purchaseOrders: Array.isArray(loaded.purchaseOrders) ? loaded.purchaseOrders : [],
    expenses: Array.isArray(loaded.expenses) ? loaded.expenses : [],
    stockMovements: Array.isArray(loaded.stockMovements) ? loaded.stockMovements : [],
    taxReminders: Array.isArray(loaded.taxReminders) ? loaded.taxReminders : [],
    zakatHistory: Array.isArray(loaded.zakatHistory) ? loaded.zakatHistory : [],
    creditMovements: Array.isArray(loaded.creditMovements) ? loaded.creditMovements : [],
    securityLog: Array.isArray(loaded.securityLog) ? loaded.securityLog : base.securityLog,
    cashRegister: { ...base.cashRegister, ...(loaded.cashRegister || {}) },
    invoiceCounter: Number.isFinite(loaded.invoiceCounter) ? loaded.invoiceCounter : 0,
    purchaseCounter: Number.isFinite(loaded.purchaseCounter) ? loaded.purchaseCounter : 0,
    purchaseOrderCounter: Number.isFinite(loaded.purchaseOrderCounter) ? loaded.purchaseOrderCounter : 0,
    quoteCounter: Number.isFinite(loaded.quoteCounter) ? loaded.quoteCounter : 0,
    deliveryCounter: Number.isFinite(loaded.deliveryCounter) ? loaded.deliveryCounter : 0,
    returnCounter: Number.isFinite(loaded.returnCounter) ? loaded.returnCounter : 0,
  };
}

// ---------- Root App ----------
// ---------- Error Boundary (safety net: one broken page can never blank the whole app) ----------
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, info) {
    console.error("Erreur interceptée par ErrorBoundary:", error, info);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="p-10 text-center">
          <AlertTriangle className="mx-auto mb-3 text-amber-500" size={36} />
          <h2 className="text-lg font-semibold text-slate-800 mb-1">Cette page a rencontré un problème</h2>
          <p className="text-sm text-slate-500 mb-4 max-w-md mx-auto">
            Le reste de l'application continue de fonctionner normalement. Vous pouvez retourner au tableau de bord et réessayer.
          </p>
          <p className="text-xs text-slate-400 mb-4 font-mono bg-slate-50 rounded-lg p-3 max-w-lg mx-auto break-all">{String(this.state.error?.message || this.state.error)}</p>
          <button
            onClick={() => { this.setState({ hasError: false, error: null }); this.props.onReset?.(); }}
            className="bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium px-4 py-2 rounded-lg"
          >
            Retour au Tableau de Bord
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

export default function App() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [session, setSession] = useState(null); // logged in employee
  const [page, setPage] = useState("dashboard");

  useEffect(() => {
    if (data && page === "pos" && data.settings.posEnabled === false) setPage("dashboard");
  }, [page, data]);

  useEffect(() => {
    if (!session?.permissions) return;
    const item = NAV_ITEMS(data?.settings?.language || "fr").find((n) => n.key === page);
    if (item && !session.permissions.includes(item.perm)) setPage("dashboard");
  }, [page, session]);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [toast, setToast] = useState(null);
  const lastRawRef = useRef(null);
  const lastLocalWriteRef = useRef(0);

  useEffect(() => {
    (async () => {
      let donnees;
      try {
        const raw = await window.erpApi.loadData();
        if (raw) {
          lastRawRef.current = raw;
          donnees = normalizeData(JSON.parse(raw));
        } else {
          donnees = demoData();
          const jsonString = JSON.stringify(donnees);
          lastRawRef.current = jsonString;
          await window.erpApi.saveData(jsonString);
        }
      } catch (e) {
        console.error(e);
        donnees = demoData();
      }

      // Remplace le catalogue produits du bloc JSON par les vrais produits
      // de la base de donnees relationnelle Smart Gestion Pro (source de
      // verite desormais). En cas d'echec (ex: hors ligne), on garde le
      // catalogue du bloc JSON tel quel plutot que de bloquer l'appli.
      if (window.produitsBridge) {
        try {
          let produitsReels = await window.produitsBridge.chargerProduitsReels();
          if (produitsReels.length === 0 && donnees.products.length > 0) {
            // Premiere synchronisation pour cette entreprise : les produits
            // n'existaient jusque-la que localement (bloc JSON) — on les
            // cree cote serveur une bonne fois pour toutes, plutot que de
            // les faire silencieusement disparaitre en les remplacant par
            // une liste vide venant du serveur.
            for (const p of donnees.products) {
              try { await window.produitsBridge.creerProduitReel(p); }
              catch (e) { console.error('Migration initiale du produit echouee:', p.name, e.message); }
            }
            produitsReels = await window.produitsBridge.chargerProduitsReels();
          }
          donnees = { ...donnees, products: produitsReels };
        } catch (e) {
          console.error('Chargement des produits depuis la base de donnees echoue, catalogue local utilise:', e.message);
        }
        try {
          const fournisseursReels = await window.produitsBridge.chargerFournisseursReels();
          donnees = { ...donnees, suppliers: fournisseursReels };
        } catch (e) {
          console.error('Chargement des fournisseurs depuis la base de donnees echoue, liste locale utilisee:', e.message);
        }
        try {
          const bonsCommandeReels = await window.produitsBridge.chargerBonsCommandeReels();
          donnees = { ...donnees, purchaseOrders: bonsCommandeReels };
        } catch (e) {
          console.error('Chargement des bons de commande depuis la base de donnees echoue:', e.message);
        }
        try {
          let servicesReels = await window.produitsBridge.chargerServicesReels();
          if (servicesReels.length === 0 && donnees.services.length > 0) {
            for (const s of donnees.services) {
              try { await window.produitsBridge.creerServiceReel(s); }
              catch (e) { console.error('Migration initiale du service echouee:', s.name, e.message); }
            }
            servicesReels = await window.produitsBridge.chargerServicesReels();
          }
          donnees = { ...donnees, services: servicesReels };
        } catch (e) {
          console.error('Chargement des services depuis la base de donnees echoue:', e.message);
        }
      }
      if (window.employesBridge) {
        try {
          let employesReels = await window.employesBridge.chargerEmployesReels();
          if (employesReels.length === 0 && donnees.employees.length > 0) {
            for (const emp of donnees.employees) {
              try { await window.employesBridge.creerEmployeReel(emp); }
              catch (e) { console.error('Migration initiale du collaborateur echouee:', emp.name, e.message); }
            }
            employesReels = await window.employesBridge.chargerEmployesReels();
          }
          donnees = { ...donnees, employees: employesReels };
        } catch (e) {
          console.error('Chargement des collaborateurs depuis la base de donnees echoue:', e.message);
        }
      }
      if (window.clientsBridge) {
        try {
          let clientsReels = await window.clientsBridge.chargerClientsReels();
          if (clientsReels.length === 0 && donnees.clients.length > 0) {
            // Meme logique que pour les produits : migration initiale au
            // lieu de faire disparaitre "Client de Passage" et les autres.
            for (const c of donnees.clients) {
              try { await window.clientsBridge.creerClientReel(c); }
              catch (e) { console.error('Migration initiale du client echouee:', c.name, e.message); }
            }
            clientsReels = await window.clientsBridge.chargerClientsReels();
          }
          donnees = { ...donnees, clients: clientsReels };
        } catch (e) {
          console.error('Chargement des clients depuis la base de donnees echoue, carnet local utilise:', e.message);
        }
      }
      if (window.depensesBridge) {
        try {
          let depensesReelles = await window.depensesBridge.chargerDepensesReelles();
          if (depensesReelles.length === 0 && donnees.expenses.length > 0) {
            for (const dep of donnees.expenses) {
              try { await window.depensesBridge.creerDepenseReelle(dep); }
              catch (e) { console.error('Migration initiale de la depense echouee:', dep.title, e.message); }
            }
            depensesReelles = await window.depensesBridge.chargerDepensesReelles();
          }
          donnees = { ...donnees, expenses: depensesReelles };
        } catch (e) {
          console.error('Chargement des depenses depuis la base de donnees echoue, liste locale utilisee:', e.message);
        }
      }
      if (window.fiscalBridge) {
        try {
          let rappelsReels = await window.fiscalBridge.chargerRappelsReels();
          if (rappelsReels.length === 0 && donnees.taxReminders.length > 0) {
            for (const r of donnees.taxReminders) {
              try { await window.fiscalBridge.creerRappelReel(r); }
              catch (e) { console.error('Migration initiale du rappel fiscal echouee:', r.label, e.message); }
            }
            rappelsReels = await window.fiscalBridge.chargerRappelsReels();
          }
          donnees = { ...donnees, taxReminders: rappelsReels };
        } catch (e) {
          console.error('Chargement du calendrier fiscal depuis la base de donnees echoue:', e.message);
        }
        try {
          const zakatReel = await window.fiscalBridge.chargerZakatReel();
          donnees = { ...donnees, zakatHistory: zakatReel };
        } catch (e) {
          console.error('Chargement de l\'historique Zakat depuis la base de donnees echoue:', e.message);
        }
      }

      setData(donnees);
      setLoading(false);
    })();
  }, []);

  // Auto-sync: if this app is pointed at a shared network folder (or cloud
  // folder) used by another PC on the same office, periodically check for
  // changes written by that other PC and pull them in automatically — so an
  // operation done on PC A appears on PC B within a few seconds, with no
  // manual refresh or restart needed.
  useEffect(() => {
    const interval = setInterval(async () => {
      if (Date.now() - lastLocalWriteRef.current < 2500) return; // avoid racing our own just-made write
      try {
        const raw = await window.erpApi.loadData();
        if (raw && raw !== lastRawRef.current) {
          lastRawRef.current = raw;
          setData(normalizeData(JSON.parse(raw)));
        }
      } catch (e) {
        // Silent: a transient read failure (e.g., other PC mid-write) just waits for the next tick.
      }
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const persist = async (next) => {
    const produitsAvant = data.products;
    const clientsAvant = data.clients;
    setData(next);
    const jsonString = JSON.stringify(next);
    lastRawRef.current = jsonString;
    lastLocalWriteRef.current = Date.now();
    try {
      await window.erpApi.saveData(jsonString);
    } catch (e) {
      console.error("Erreur de sauvegarde", e);
    }
    // Synchronise le stock reel (base de donnees) chaque fois qu'un produit
    // change de quantite, quelle que soit l'operation d'origine (vente,
    // achat, retour, ajustement manuel...) — un seul point centralise au
    // lieu de modifier chacun des 9 endroits qui touchent p.stock.
    if (window.produitsBridge && next.products) {
      window.produitsBridge.synchroniserStock(produitsAvant, next.products).catch((e) => {
        console.error('Synchronisation stock (base de donnees) echouee:', e.message);
      });
    }
    // Meme principe pour les points de fidelite des clients.
    if (window.clientsBridge && next.clients) {
      window.clientsBridge.synchroniserClients(clientsAvant, next.clients).catch((e) => {
        console.error('Synchronisation clients (base de donnees) echouee:', e.message);
      });
    }
  };

  const showToast = (msg, type = "success") => {
    setToast({ msg, type, id: uid() });
    setTimeout(() => setToast(null), 2600);
  };

  if (loading || !data) {
    return (
      <div className="w-full h-full min-h-[600px] flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 text-sm">Chargement de l'application...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return <LoginScreen data={data} persist={persist} onLogin={setSession} showToast={showToast} />;
  }

  const lang = data.settings.language || "fr";
  const dir = "ltr"; // le menu reste toujours a gauche, seule la langue change

  return (
    <div dir={dir} className="w-full h-full min-h-[700px] flex bg-slate-50 text-slate-800 font-sans">
      <Sidebar
        page={page}
        setPage={setPage}
        open={sidebarOpen}
        setOpen={setSidebarOpen}
        settings={data.settings}
        session={session}
        cashRegister={data.cashRegister}
        onLogout={() => setSession(null)}
        onCloture={async () => {
          const next = { ...data, cashRegister: { ...data.cashRegister, active: false } };
          await persist(next);
          showToast(lang === "ar" ? "تم إغلاق اليومية." : "Journée clôturée.");
        }}
      />
      <main className="flex-1 min-w-0 overflow-y-auto">
        <TopBar settings={data.settings} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
        <div className="p-6">
          <ErrorBoundary key={page} onReset={() => setPage("dashboard")}>
            {page === "dashboard" && <Dashboard data={data} />}
            {page === "pos" && <POS data={data} persist={persist} showToast={showToast} session={session} />}
            {page === "invoices" && <Invoices data={data} persist={persist} showToast={showToast} />}
            {page === "purchases" && <Purchases data={data} persist={persist} showToast={showToast} />}
            {page === "suppliers" && <Suppliers data={data} persist={persist} showToast={showToast} />}
            {page === "products" && <Products data={data} persist={persist} showToast={showToast} />}
            {page === "services" && <Services data={data} persist={persist} showToast={showToast} />}
            {page === "clients" && <Clients data={data} persist={persist} showToast={showToast} />}
            {page === "stock" && <Stock data={data} persist={persist} showToast={showToast} />}
            {page === "expenses" && <Expenses data={data} persist={persist} showToast={showToast} />}
            {page === "reports" && <Reports data={data} showToast={showToast} />}
            {page === "analysis" && <Analysis data={data} showToast={showToast} />}
            {page === "security" && <Security data={data} persist={persist} showToast={showToast} session={session} />}
            {page === "securitylog" && <SecurityLog data={data} />}
            {page === "taxcalendar" && <TaxCalendar data={data} persist={persist} showToast={showToast} />}
            {page === "clientcredits" && <ClientCredits data={data} persist={persist} showToast={showToast} session={session} />}
            {page === "zakat" && <Zakat data={data} persist={persist} showToast={showToast} />}
            {page === "settings" && <SettingsPage data={data} persist={persist} showToast={showToast} session={session} />}
          </ErrorBoundary>
        </div>
      </main>
      {toast && <Toast toast={toast} />}
    </div>
  );
}

// ---------- Toast ----------
function Toast({ toast }) {
  const colors = {
    success: "bg-emerald-600",
    error: "bg-red-600",
    info: "bg-blue-600",
  };
  return (
    <div className={`fixed bottom-6 right-6 ${colors[toast.type] || colors.success} text-white px-4 py-3 rounded-lg shadow-lg text-sm z-50 flex items-center gap-2`}>
      <Check size={16} /> {toast.msg}
    </div>
  );
}

// ---------- Login ----------
function LoginScreen({ data, persist, onLogin, showToast }) {
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const lang = data.settings.language || "fr";
  const dir = "ltr"; // le menu reste toujours a gauche, seule la langue change

  const tryLogin = async () => {
    const emp = data.employees.find((e) => e.pin === pin && e.active !== false);
    if (emp) {
      setError("");
      await persist({ ...data, securityLog: logEvent(data, emp.name, "CONNEXION", "Connexion réussie à la caisse.") });
      onLogin(emp);
    } else {
      await persist({ ...data, securityLog: logEvent(data, "Inconnu", "ÉCHEC DE CONNEXION", "Tentative de connexion avec un code PIN incorrect.") });
      setError(t(lang, "login_error"));
    }
  };

  return (
    <div
      dir={dir}
      className="w-full h-full min-h-[700px] flex items-center justify-center font-sans p-6 relative overflow-hidden"
      style={{ background: "radial-gradient(circle at 30% 20%, #1e293b 0%, #0f172a 55%, #020617 100%)" }}
    >
      <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(circle, #3b82f6 1px, transparent 1px)", backgroundSize: "32px 32px" }} />
      <div className="w-full max-w-sm bg-slate-900/90 backdrop-blur rounded-2xl p-8 shadow-2xl border border-slate-800 relative z-10">
        <div className="flex flex-col items-center mb-6">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center mb-3 shadow-lg shadow-blue-900/50 overflow-hidden">
            {data.settings.logo ? <img src={data.settings.logo} alt="logo" className="w-full h-full object-cover" /> : <Building2 className="text-white" size={30} />}
          </div>
          <h1 className="text-white text-lg font-semibold">{data.settings.companyName}</h1>
          <p className="text-slate-400 text-xs mt-1">{t(lang, "login_subtitle")}</p>
        </div>
        <div className="mb-4">
          <div className="flex items-center gap-2 bg-slate-800 rounded-lg px-3 py-2.5 border border-slate-700 focus-within:border-blue-500 transition-colors">
            <Lock size={16} className="text-slate-400" />
            <input
              type="password"
              maxLength={4}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
              onKeyDown={(e) => e.key === "Enter" && tryLogin()}
              placeholder={t(lang, "login_placeholder")}
              className="bg-transparent outline-none text-white text-sm w-full tracking-widest"
              autoFocus
            />
          </div>
          {error && <p className="text-red-400 text-xs mt-2 flex items-center gap-1"><AlertTriangle size={12} /> {error}</p>}
        </div>
        <button
          onClick={tryLogin}
          className="w-full bg-blue-600 hover:bg-blue-500 active:scale-[0.98] transition-all text-white rounded-lg py-2.5 text-sm font-medium shadow-lg shadow-blue-900/30"
        >
          {t(lang, "login_button")}
        </button>
        <p className="text-slate-500 text-xs text-center mt-4">{t(lang, "login_default_code")}</p>
      </div>
    </div>
  );
}

// ---------- Sidebar ----------
function NAV_ITEMS(lang) {
  return [
    { key: "dashboard", label: t(lang, "nav_dashboard"), icon: LayoutDashboard, perm: "DASHBOARD" },
    { key: "pos", label: t(lang, "nav_pos"), icon: ShoppingCart, perm: "POS_OPEN" },
    { key: "invoices", label: t(lang, "nav_invoices"), icon: FileText, perm: "POS_CREATE_SALE" },
    { key: "purchases", label: t(lang, "nav_purchases"), icon: PackagePlus, perm: "SUPPLIERS_MANAGE" },
    { key: "suppliers", label: t(lang, "nav_suppliers"), icon: Truck, perm: "SUPPLIERS_MANAGE" },
    { key: "products", label: t(lang, "nav_products"), icon: Boxes, perm: "PRODUCTS_VIEW" },
    { key: "services", label: t(lang, "nav_services"), icon: Wrench, perm: "PRODUCTS_VIEW" },
    { key: "clients", label: t(lang, "nav_clients"), icon: Heart, perm: "CLIENTS_MANAGE" },
    { key: "stock", label: t(lang, "nav_stock"), icon: TrendingUp, perm: "STOCK_VIEW" },
    { key: "expenses", label: t(lang, "nav_expenses"), icon: DollarSign, perm: "EXPENSES_MANAGE" },
    { key: "reports", label: t(lang, "nav_reports"), icon: ReceiptText, perm: "REPORTS_VIEW" },
    { key: "analysis", label: t(lang, "nav_analysis"), icon: BarChart2, perm: "REPORTS_VIEW" },
    { key: "security", label: t(lang, "nav_security"), icon: Shield, perm: "SECURITY_MANAGE" },
    { key: "securitylog", label: t(lang, "nav_securitylog"), icon: Lock, perm: "SECURITY_MANAGE" },
    { key: "taxcalendar", label: "Calendrier Fiscal", icon: CalendarClock, perm: "SETTINGS_MANAGE" },
    { key: "clientcredits", label: "Crédits Clients", icon: CreditCard, perm: "CLIENTS_MANAGE" },
    { key: "zakat", label: "Calcul de la Zakat", icon: HandCoins, perm: "SETTINGS_MANAGE" },
    { key: "settings", label: t(lang, "nav_settings"), icon: SettingsIcon, perm: "SETTINGS_MANAGE" },
  ];
}

function Sidebar({ page, setPage, open, settings, session, cashRegister, onLogout, onCloture }) {
  const lang = settings.language || "fr";
  const sidebarBg = darkenColor(settings.color, 0.87);
  const panelBg = darkenColor(settings.color, 0.8);
  const borderCol = darkenColor(settings.color, 0.7);
  return (
    <aside
      className={`${open ? "w-72" : "w-0"} transition-all duration-200 shrink-0 overflow-hidden flex flex-col`}
      style={{ backgroundColor: sidebarBg }}
    >
      <div className="w-72 flex flex-col h-full">
        <div className="p-5 flex items-center gap-3" style={{ borderBottom: `1px solid ${borderCol}` }}>
          <div
            className="w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold shrink-0 overflow-hidden"
            style={{ backgroundColor: settings.color }}
          >
            {settings.logo ? <img src={settings.logo} alt="logo" className="w-full h-full object-cover" /> : settings.companyName.charAt(0).toUpperCase()}
          </div>
          <div className="min-w-0">
            <p className="text-white text-sm font-semibold truncate">
              {settings.companyName} <span style={{ color: settings.color }}>ERP</span>
            </p>
            <p className="text-slate-500 text-[10px] uppercase tracking-wide">{t(lang, "app_professional")}</p>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-3 px-3 space-y-0.5">
          {NAV_ITEMS(lang)
            .filter((item) => item.key !== "pos" || settings.posEnabled !== false)
            .filter((item) => !session?.permissions || session.permissions.includes(item.perm))
            .map((item) => {
            const Icon = item.icon;
            const active = page === item.key;
            return (
              <button
                key={item.key}
                onClick={() => setPage(item.key)}
                className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-150"
                style={
                  active
                    ? { backgroundColor: settings.color, color: "#fff", boxShadow: `0 4px 10px -2px ${settings.color}66` }
                    : { color: "#94a3b8" }
                }
                onMouseEnter={(e) => { if (!active) e.currentTarget.style.backgroundColor = borderCol; }}
                onMouseLeave={(e) => { if (!active) e.currentTarget.style.backgroundColor = "transparent"; }}
              >
                <Icon size={17} className={active ? "" : "opacity-80"} />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-3 space-y-2" style={{ borderTop: `1px solid ${borderCol}` }}>
          <div className="rounded-lg p-3" style={{ backgroundColor: panelBg }}>
            <div className="flex items-center gap-2 mb-1">
              <span className={`w-2 h-2 rounded-full ${cashRegister.active ? "bg-emerald-500" : "bg-slate-600"}`} />
              <span className="text-xs text-slate-300 font-medium">{cashRegister.active ? t(lang, "cashier_active") : t(lang, "cashier_closed")}</span>
            </div>
            <p className="text-emerald-400 text-sm font-mono">{t(lang, "cash_balance")} : {fmtMoney(cashRegister.solde, settings.currency)}</p>
            {cashRegister.active && (
              <button
                onClick={onCloture}
                className="mt-2 w-full text-white text-xs py-1.5 rounded-md hover:opacity-80 transition-opacity"
                style={{ backgroundColor: borderCol }}
              >
                {t(lang, "close_day")}
              </button>
            )}
          </div>
          <div className="flex items-center justify-between px-1">
            <div className="min-w-0">
              <p className="text-white text-xs font-medium truncate">{session.name}</p>
              <p className="text-slate-500 text-[10px]">{session.role}</p>
            </div>
            <button onClick={onLogout} className="text-slate-400 hover:text-white p-1.5" title={t(lang, "logout")}>
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}

function TopBar({ settings, sidebarOpen, setSidebarOpen }) {
  const [now] = useState(new Date());
  return (
    <div className="h-14 bg-white border-b border-slate-200 flex items-center justify-between px-5 sticky top-0 z-10">
      <button onClick={() => setSidebarOpen(!sidebarOpen)} className="text-slate-500 hover:text-slate-800">
        <Menu size={20} />
      </button>
      <div className="flex items-center gap-2 text-sm text-slate-500">
        <span>{now.toLocaleDateString("fr-FR", { weekday: "short", day: "2-digit", month: "short" })}</span>
        <span className="text-slate-300">•</span>
        <span>{now.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</span>
      </div>
    </div>
  );
}

// ---------- Shared UI bits ----------
function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="flex flex-wrap items-start justify-between gap-3 mb-6">
      <div>
        <h1 className="text-2xl font-bold text-slate-900">{title}</h1>
        {subtitle && <p className="text-slate-500 text-sm mt-1">{subtitle}</p>}
      </div>
      {actions && <div className="flex items-center gap-2 flex-wrap">{actions}</div>}
    </div>
  );
}

function Card({ children, className = "" }) {
  return <div className={`bg-white rounded-xl border border-slate-200 transition-shadow ${className}`}>{children}</div>;
}

function Btn({ children, onClick, variant = "primary", icon: Icon, size = "md", type = "button", disabled }) {
  const variants = {
    primary: "bg-blue-600 hover:bg-blue-500 text-white",
    success: "bg-emerald-600 hover:bg-emerald-500 text-white",
    danger: "bg-red-600 hover:bg-red-500 text-white",
    ghost: "bg-slate-100 hover:bg-slate-200 text-slate-700",
    outline: "border border-slate-300 hover:bg-slate-50 text-slate-700",
  };
  const sizes = { sm: "px-2.5 py-1.5 text-xs", md: "px-4 py-2 text-sm" };
  return (
    <button
      type={type}
      disabled={disabled}
      onClick={onClick}
      className={`inline-flex items-center gap-1.5 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${variants[variant]} ${sizes[size]}`}
    >
      {Icon && <Icon size={size === "sm" ? 14 : 16} />}
      {children}
    </button>
  );
}

function Modal({ title, onClose, children, wide }) {
  return (
    <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center z-40 p-4" onClick={onClose}>
      <div
        className={`bg-white rounded-xl shadow-2xl w-full ${wide ? "max-w-2xl" : "max-w-md"} max-h-[85vh] overflow-y-auto`}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200 sticky top-0 bg-white z-10">
          <h3 className="font-semibold text-slate-900">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-700">
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

// Custom dropdown that renders its own option list in the page (no native OS
// popup involved at all) — used in place of <select> where native dropdown
// interactions have caused issues on some Windows setups.
function Dropdown({ value, onChange, options, className }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onDocClick = (e) => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, [open]);

  return (
    <div ref={ref} className="relative">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className={(className || inputCls) + " flex items-center justify-between text-left"}
      >
        <span className="truncate">{value || <span className="text-slate-400">—</span>}</span>
        <ChevronDown size={14} className="text-slate-400 shrink-0 ml-1" />
      </button>
      {open && (
        <div className="absolute z-50 mt-1 w-full max-h-56 overflow-y-auto bg-white border border-slate-200 rounded-lg shadow-lg">
          {options.map((opt) => (
            <button
              key={opt}
              type="button"
              onClick={() => { onChange(opt); setOpen(false); }}
              className={`w-full text-left px-3 py-2 text-sm hover:bg-slate-50 ${opt === value ? "bg-blue-50 text-blue-700 font-medium" : "text-slate-700"}`}
            >
              {opt}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div className="mb-3">
      <label className="block text-xs font-medium text-slate-600 mb-1">{label}</label>
      {children}
    </div>
  );
}

const inputCls =
  "w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white transition-colors";

// inputCls already includes "w-full" — appending another width class (e.g.
// "w-20") does NOT reliably override it, since both have equal CSS
// specificity and Tailwind's generated stylesheet order decides the winner,
// not the order in the className string. This helper swaps "w-full" out for
// the desired width class instead, guaranteeing the intended size.
const inputClsW = (widthClass) => inputCls.replace("w-full", widthClass);

function StatCard({ icon: Icon, label, value, color, sub }) {
  return (
    <Card className="p-5 flex items-start gap-4">
      <div className="w-11 h-11 rounded-full flex items-center justify-center shrink-0" style={{ backgroundColor: color + "1a" }}>
        <Icon size={20} style={{ color }} />
      </div>
      <div className="min-w-0">
        <p className="text-slate-500 text-xs">{label}</p>
        <p className="text-xl font-bold text-slate-900 truncate">{value}</p>
        {sub && <p className="text-slate-400 text-[11px] mt-0.5">{sub}</p>}
      </div>
    </Card>
  );
}

function EmptyState({ text }) {
  return (
    <div className="py-16 text-center text-slate-400 text-sm">
      <Package className="mx-auto mb-2 opacity-40" size={32} />
      {text}
    </div>
  );
}

// ---------- Dashboard ----------
function Dashboard({ data }) {
  const lang = data.settings.language || "fr";
  const dateLocale = lang === "ar" ? "ar-MA" : "fr-FR";
  const today = todayISO();
  const thisMonth = today.slice(0, 7);
  const invToday = data.invoices.filter((i) => i.date.slice(0, 10) === today);
  const invMonth = data.invoices.filter((i) => i.date.slice(0, 7) === thisMonth);
  const expMonth = data.expenses.filter((e) => e.date.slice(0, 7) === thisMonth);

  const caJour = invToday.reduce((s, i) => s + i.total, 0);
  const caMois = invMonth.reduce((s, i) => s + i.total, 0);
  const depMois = expMonth.reduce((s, e) => s + Number(e.amount), 0);
  const beneficeMois = caMois - depMois;
  const creditClients = data.clients.reduce((s, c) => s + (c.credit || 0), 0);
  const dettesFournisseurs = data.suppliers.reduce((s, f) => s + (f.debt || 0), 0);

  const productSales = {};
  data.invoices.forEach((inv) =>
    inv.items.forEach((it) => {
      productSales[it.name] = (productSales[it.name] || 0) + it.qty;
    })
  );
  const topProducts = Object.entries(productSales)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  const last7 = [...Array(7)].map((_, idx) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - idx));
    const iso = d.toISOString().slice(0, 10);
    const total = data.invoices.filter((i) => i.date.slice(0, 10) === iso).reduce((s, i) => s + i.total, 0);
    return { label: d.toLocaleDateString(dateLocale, { weekday: "short" }), total };
  });
  const maxCA = Math.max(...last7.map((d) => d.total), 1);

  const categorySales = {};
  data.invoices.forEach((inv) =>
    inv.items.forEach((it) => {
      const prod = data.products.find((p) => p.id === it.productId);
      const cat = prod?.category || "Autre";
      categorySales[cat] = (categorySales[cat] || 0) + it.price * it.qty;
    })
  );
  const DONUT_COLORS = ["#2563eb", "#16a34a", "#f59e0b", "#dc2626", "#7c3aed", "#0891b2", "#db2777"];
  const catEntries = Object.entries(categorySales).sort((a, b) => b[1] - a[1]);
  const catTotal = catEntries.reduce((s, [, v]) => s + v, 0) || 1;
  let cumulative = 0;
  const donutSegments = catEntries.map(([cat, val], idx) => {
    const start = (cumulative / catTotal) * 360;
    cumulative += val;
    const end = (cumulative / catTotal) * 360;
    return { cat, val, color: DONUT_COLORS[idx % DONUT_COLORS.length], start, end };
  });
  const donutGradient = donutSegments.length
    ? `conic-gradient(${donutSegments.map((s) => `${s.color} ${s.start}deg ${s.end}deg`).join(", ")})`
    : "conic-gradient(#e2e8f0 0deg 360deg)";

  return (
    <div>
      <PageHeader title={t(lang, "dashboard_title")} subtitle={t(lang, "dashboard_subtitle")} />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={ShoppingCart} color="#2563eb" label={t(lang, "kpi_ca_day")} value={fmtMoney(caJour, data.settings.currency)} sub={`${invToday.length} ${lang === "ar" ? "عملية اليوم" : "transaction(s) aujourd'hui"}`} />
        <StatCard icon={TrendingUp} color="#16a34a" label={t(lang, "kpi_ca_month")} value={fmtMoney(caMois, data.settings.currency)} sub={lang === "ar" ? "نشط هذا الشهر" : "Actif ce mois"} />
        <StatCard icon={PiggyBank} color="#7c3aed" label={t(lang, "kpi_net_profit")} value={fmtMoney(beneficeMois, data.settings.currency)} sub={`${lang === "ar" ? "بعد خصم" : "Après déduction de"} ${fmtMoney(depMois, data.settings.currency)}`} />
        <StatCard icon={DollarSign} color="#dc2626" label={t(lang, "kpi_expenses_month")} value={fmtMoney(depMois, data.settings.currency)} sub={lang === "ar" ? "إجمالي المصاريف" : "Total des sorties"} />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <p className="text-slate-500 text-sm">{t(lang, "kpi_client_credit")}</p>
            <span className="text-xs bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full">{t(lang, "kpi_pending")}</span>
          </div>
          <p className="text-xl font-bold text-amber-600 mt-1">{fmtMoney(creditClients, data.settings.currency)}</p>
        </Card>
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <p className="text-slate-500 text-sm">{t(lang, "kpi_supplier_debt")}</p>
            <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded-full">{t(lang, "kpi_topay")}</span>
          </div>
          <p className="text-xl font-bold text-red-600 mt-1">{fmtMoney(dettesFournisseurs, data.settings.currency)}</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="p-5 lg:col-span-2">
          <p className="font-semibold text-slate-800 mb-5">{t(lang, "chart_ca_7days")}</p>
          <div className="flex items-end gap-3 h-44">
            {last7.map((d, idx) => {
              const pct = Math.max((d.total / maxCA) * 100, 2);
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1.5 group">
                  <span className="text-[10px] font-medium text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">
                    {d.total > 0 ? fmtMoney(d.total, data.settings.currency) : ""}
                  </span>
                  <div
                    className="w-full rounded-t-lg transition-all duration-500 ease-out"
                    style={{
                      height: `${pct}%`,
                      background: "linear-gradient(180deg, #3b82f6 0%, #2563eb 100%)",
                      minHeight: "4px",
                    }}
                    title={fmtMoney(d.total, data.settings.currency)}
                  />
                  <span className="text-[10px] text-slate-400 capitalize font-medium">{d.label}</span>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="p-5">
          <p className="font-semibold text-slate-800 mb-4">{t(lang, "chart_sales_by_category")}</p>
          {donutSegments.length === 0 ? (
            <EmptyState text={t(lang, "no_data")} />
          ) : (
            <div className="flex flex-col items-center">
              <div
                className="w-32 h-32 rounded-full mb-4 relative flex items-center justify-center"
                style={{ background: donutGradient }}
              >
                <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center">
                  <span className="text-[10px] text-slate-400 font-medium text-center">{t(lang, "total")}<br />{fmtMoney(catTotal, data.settings.currency)}</span>
                </div>
              </div>
              <div className="w-full space-y-1.5">
                {donutSegments.slice(0, 5).map((s) => (
                  <div key={s.cat} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1.5 text-slate-600 truncate">
                      <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: s.color }} />
                      {s.cat}
                    </span>
                    <span className="text-slate-400 shrink-0 ml-2">{Math.round((s.val / catTotal) * 100)}%</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </Card>

        <Card className="p-5 lg:col-span-3">
          <p className="font-semibold text-slate-800 mb-4">{t(lang, "chart_top_products")}</p>
          {topProducts.length === 0 ? (
            <EmptyState text={t(lang, "no_sales_yet")} />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-3">
              {topProducts.map(([name, qty]) => (
                <div key={name}>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-slate-700 truncate">{name}</span>
                    <span className="text-slate-400">{qty} u.</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-blue-400 to-blue-600 rounded-full transition-all duration-500" style={{ width: `${(qty / topProducts[0][1]) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}

// ---------- POS (Caisse) ----------
function POS({ data, persist, showToast, session }) {
  const lang = data.settings.language || "fr";

  const ALL_DISCOUNT_TYPES = ["Aucune", "% Pourcentage", "Valeur Fixe"];
  const ALL_DELIVERY_OPTIONS = ["Emporté", "Gratuite", "Payante"];
  const ALL_PAYMENT_METHODS = ["Cash", "Carte", "Vir.", "Credit", "Mixte"];
  const discountTypes = ALL_DISCOUNT_TYPES.filter((d) => data.settings.enabledDiscountTypes?.[d] !== false);
  const deliveryOptions = ALL_DELIVERY_OPTIONS.filter((l) => data.settings.enabledDeliveryOptions?.[l] !== false);
  const paymentMethods = ALL_PAYMENT_METHODS.filter((m) => data.settings.enabledPaymentMethods?.[m] !== false);
  const safeDiscountTypes = discountTypes.length ? discountTypes : ["Aucune"];
  const safeDeliveryOptions = deliveryOptions.length ? deliveryOptions : ["Emporté"];
  const safePaymentMethods = paymentMethods.length ? paymentMethods : ["Cash"];
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("Tout");
  const [itemMode, setItemMode] = useState("products");
  const searchInputRef = useRef(null);
  const refocusSearch = () => setTimeout(() => searchInputRef.current?.focus(), 30);
  const [cart, setCart] = useState([]); // {productId, name, price, qty}
  const [clientId, setClientId] = useState(data.clients[0]?.id || "");
  const [discountType, setDiscountType] = useState(safeDiscountTypes[0]);
  const [discountValue, setDiscountValue] = useState(0);
  const [logistic, setLogistic] = useState(safeDeliveryOptions[0]);
  const [deliveryFee, setDeliveryFee] = useState(0);
  const [payMethod, setPayMethod] = useState(safePaymentMethods[0]);
  const [saleDate, setSaleDate] = useState(todayISO());
  const [received, setReceived] = useState(0);
  const [useLoyalty, setUseLoyalty] = useState(false);
  const [showQuickClient, setShowQuickClient] = useState(false);
  const [lastInvoice, setLastInvoice] = useState(null);
  const [quickClientForm, setQuickClientForm] = useState({ name: "", phone: "", email: "", address: "" });

  const client = data.clients.find((c) => c.id === clientId) || data.clients[0];
  const cats = ["Tout", ...(data.categories || CATEGORIES_DEFAULT)];
  const serviceCats = ["Tout", ...(data.serviceCategories || [])];

  const filtered = data.products.filter(
    (p) =>
      (category === "Tout" || p.category === category) &&
      (String(p.name || "").toLowerCase().includes(search.toLowerCase()) || String(p.barcode || "").includes(search))
  );

  const filteredServices = data.services.filter(
    (s) => (category === "Tout" || s.category === category) && String(s.name || "").toLowerCase().includes(search.toLowerCase())
  );

  const addToCart = (p) => {
    if (p.stock <= 0) {
      showToast("Stock épuisé pour ce produit.", "error");
      refocusSearch();
      return;
    }
    setCart((c) => {
      const existing = c.find((it) => it.productId === p.id);
      if (existing) {
        if (existing.qty >= p.stock) {
          showToast("Quantité maximale atteinte (stock).", "error");
          return c;
        }
        return c.map((it) => (it.productId === p.id ? { ...it, qty: it.qty + 1 } : it));
      }
      return [...c, { productId: p.id, name: p.name, price: p.sellPrice, qty: 1 }];
    });
    refocusSearch();
  };

  const addServiceToCart = (s) => {
    setCart((c) => {
      const existing = c.find((it) => it.serviceId === s.id);
      if (existing) {
        return c.map((it) => (it.serviceId === s.id ? { ...it, qty: it.qty + 1 } : it));
      }
      return [...c, { serviceId: s.id, name: s.name, price: s.price, qty: 1, isService: true }];
    });
    refocusSearch();
  };

  const changeQty = (id, delta) => {
    const prod = data.products.find((p) => p.id === id);
    setCart((c) =>
      c
        .map((it) => {
          if (it.productId !== id && it.serviceId !== id) return it;
          const newQty = it.qty + delta;
          if (prod && newQty > prod.stock) {
            showToast("Quantité maximale atteinte (stock).", "error");
            return it;
          }
          return { ...it, qty: newQty };
        })
        .filter((it) => it.qty > 0)
    );
  };

  const removeItem = (id) => setCart((c) => c.filter((it) => it.productId !== id && it.serviceId !== id));

  const toggleGift = (id) => {
    setCart((c) =>
      c.map((it) => {
        if (it.productId !== id && it.serviceId !== id) return it;
        if (it.gifted) return { ...it, gifted: false, price: it.originalPrice ?? it.price };
        return { ...it, gifted: true, originalPrice: it.price, price: 0 };
      })
    );
  };

  const subtotal = cart.reduce((s, it) => s + it.price * it.qty, 0);
  let discountAmount = 0;
  if (discountType === "% Pourcentage") discountAmount = (subtotal * Number(discountValue || 0)) / 100;
  if (discountType === "Valeur Fixe") discountAmount = Number(discountValue || 0);
  const loyaltyDiscount = useLoyalty && client ? Math.min((client.loyaltyPoints || 0) * 0.1, subtotal) : 0;
  const fee = logistic === "Payante" ? Number(deliveryFee || 0) : 0;
  const total = Math.max(subtotal - discountAmount - loyaltyDiscount + fee, 0);
  const change = Math.max(Number(received || 0) - total, 0);

  const saveQuickClient = async () => {
    if (!quickClientForm.name.trim()) {
      showToast("Le nom du client est requis.", "error");
      return;
    }
    try {
      const newClient = window.clientsBridge
        ? await window.clientsBridge.creerClientReel(quickClientForm)
        : { id: uid("cli"), loyaltyPoints: 0, credit: 0, ...quickClientForm };
      await persist({ ...data, clients: [...data.clients, newClient] });
      setClientId(newClient.id);
      setShowQuickClient(false);
      setQuickClientForm({ name: "", phone: "", email: "", address: "" });
      showToast("Client ajouté et sélectionné.");
    } catch (e) {
      showToast("Erreur lors de l'ajout du client : " + e.message, "error");
    }
  };

  const resetCart = () => {
    setCart([]);
    setDiscountType(safeDiscountTypes[0]);
    setDiscountValue(0);
    setLogistic(safeDeliveryOptions[0]);
    setDeliveryFee(0);
    setReceived(0);
    setUseLoyalty(false);
    setSaleDate(todayISO());
  };

  const validateSale = async () => {
    if (cart.length === 0) {
      showToast("Le panier est vide.", "error");
      return;
    }
    const ref = makeRef(data.settings, "invoice", data.invoiceCounter);
    const paidNow = payMethod === "Credit" ? 0 : Math.min(Number(received || 0) || total, total);
    const status = paidNow >= total ? "PAID" : paidNow > 0 ? "PARTIAL" : "UNPAID";

    const invoice = {
      id: uid("inv"),
      ref,
      date: new Date(saleDate + "T" + new Date().toTimeString().slice(0, 8)).toISOString(),
      clientId: client?.id,
      clientName: client?.name || "Client de Passage",
      items: cart.map((it) => ({ ...it })),
      subtotal,
      discount: discountAmount + loyaltyDiscount,
      deliveryFee: fee,
      total,
      paid: paidNow,
      status,
      payMethod,
      counterValue: data.invoiceCounter,
      cashierName: session?.name || "",
    };

    let products = [...data.products];
    let stockMovements = [...data.stockMovements];
    cart.forEach((it) => {
      products = products.map((p) => {
        if (p.id !== it.productId) return p;
        const oldStock = p.stock;
        const newStock = oldStock - it.qty;
        stockMovements = [
          {
            id: uid("mov"),
            date: new Date().toISOString(),
            product: p.name,
            type: "Sortie",
            delta: -it.qty,
            oldStock,
            newStock,
            reason: `Vente caisse ${ref}`,
          },
          ...stockMovements,
        ];
        return { ...p, stock: newStock };
      });
    });

    let clients = data.clients;
    if (client) {
      clients = data.clients.map((c) => {
        if (c.id !== client.id) return c;
        const remaining = total - paidNow;
        const pointsEarned = Math.floor(total / 10);
        const pointsUsed = useLoyalty ? Math.min(c.loyaltyPoints || 0, Math.floor(loyaltyDiscount / 0.1)) : 0;
        return {
          ...c,
          credit: (c.credit || 0) + remaining,
          loyaltyPoints: Math.max((c.loyaltyPoints || 0) - pointsUsed, 0) + pointsEarned,
        };
      });
    }

    const cashRegister = { ...data.cashRegister, solde: (data.cashRegister.solde || 0) + paidNow };

    const next = {
      ...data,
      invoices: [invoice, ...data.invoices],
      products,
      stockMovements,
      clients,
      cashRegister,
      invoiceCounter: data.invoiceCounter + 1,
    };
    // Enregistre la vraie vente cote base de donnees AVANT persist() : c'est
    // cet appel qui doit deduire le stock reel (une seule fois). persist()
    // declenche ensuite une synchronisation generique du stock qui, dans ce
    // cas, ne fait que confirmer la meme valeur (aucune double deduction).
    if (window.produitsBridge) {
      await window.produitsBridge.creerVenteReelle(cart, client?.id);
    }
    await persist(next);
    showToast(`Vente validée — ${ref}`);
    setLastInvoice(invoice);
    resetCart();
  };

  return (
    <div>
      <PageHeader title={t(lang, "page_pos_title")} subtitle={t(lang, "page_pos_subtitle")} />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2">
          <div className="flex gap-2 mb-4">
            <button
              onClick={() => { setItemMode("products"); setCategory("Tout"); }}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium border ${
                itemMode === "products" ? "bg-slate-900 text-white border-slate-900" : "bg-white border-slate-200 text-slate-600"
              }`}
            >
              <Package size={15} /> Produits
            </button>
            <button
              onClick={() => { setItemMode("services"); setCategory("Tout"); }}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-sm font-medium border ${
                itemMode === "services" ? "bg-slate-900 text-white border-slate-900" : "bg-white border-slate-200 text-slate-600"
              }`}
            >
              <Wrench size={15} /> Services
            </button>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 mb-4">
            <div className="flex-1 flex items-center gap-2 bg-white border border-slate-200 rounded-lg px-3 py-2">
              <Search size={16} className="text-slate-400" />
              <input
                ref={searchInputRef}
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key !== "Enter" || itemMode !== "products") return;
                  const match = data.products.find((p) => p.barcode && String(p.barcode) === search.trim());
                  if (match) {
                    addToCart(match);
                    setSearch("");
                  }
                }}
                placeholder={itemMode === "products" ? "Rechercher / Scanner..." : "Rechercher un service..."}
                className="flex-1 outline-none text-sm"
                autoFocus
              />
            </div>
            {itemMode === "products" && (
              <span className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-700 text-xs px-3 py-2 rounded-lg whitespace-nowrap">
                <span className="w-2 h-2 bg-emerald-500 rounded-full" /> Scanner Prêt
              </span>
            )}
          </div>
          <div className="flex flex-wrap gap-2 mb-4">
            {(itemMode === "products" ? cats : serviceCats).map((c) => (
              <button
                key={c}
                onClick={() => setCategory(c)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
                  category === c ? "bg-slate-900 text-white" : "bg-white border border-slate-200 text-slate-600 hover:bg-slate-50"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
          {itemMode === "products" ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
            {filtered.map((p) => (
              <button
                key={p.id}
                onClick={() => addToCart(p)}
                className="bg-white border border-slate-200 rounded-xl p-3 text-left hover:border-blue-400 hover:shadow-sm transition-all relative"
              >
                <span className="absolute top-2 right-2 text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-full">{p.stock}</span>
                <div className="w-full h-16 bg-slate-50 rounded-lg mb-2 flex items-center justify-center text-slate-300 overflow-hidden">
                  {p.image ? <img src={p.image} alt={p.name} className="w-full h-full object-cover" /> : <Package size={26} />}
                </div>
                <p className="text-xs font-medium text-slate-800 leading-tight line-clamp-2 min-h-[2rem]">{p.name}</p>
                <p className="text-sm font-bold text-blue-600 mt-1">{fmtMoney(p.sellPrice, data.settings.currency)}</p>
              </button>
            ))}
            {filtered.length === 0 && (
              <div className="col-span-full">
                <EmptyState text="Aucun produit trouvé." />
              </div>
            )}
          </div>
          ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
            {filteredServices.map((s) => (
              <button
                key={s.id}
                onClick={() => addServiceToCart(s)}
                className="bg-white border border-slate-200 rounded-xl p-3 text-left hover:border-purple-400 hover:shadow-sm transition-all relative"
              >
                <div className="w-full h-16 bg-purple-50 rounded-lg mb-2 flex items-center justify-center text-purple-300">
                  <Wrench size={24} />
                </div>
                <p className="text-xs font-medium text-slate-800 leading-tight line-clamp-2 min-h-[2rem]">{s.name}</p>
                <p className="text-sm font-bold text-purple-600 mt-1">{fmtMoney(s.price, data.settings.currency)}</p>
              </button>
            ))}
            {filteredServices.length === 0 && (
              <div className="col-span-full">
                <EmptyState text="Aucun service trouvé." />
              </div>
            )}
          </div>
          )}
        </div>

        <div>
          <Card className="p-4 sticky top-16">
            <div className="flex items-center justify-between gap-2 mb-3">
              <span className="text-xs text-slate-500 font-medium">Client :</span>
              <select value={clientId} onChange={(e) => setClientId(e.target.value)} className={"flex-1 min-w-0 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white transition-colors"}>
                {data.clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
              <button
                onClick={() => setShowQuickClient(true)}
                className="shrink-0 flex items-center gap-1 text-xs font-medium text-blue-600 hover:text-blue-700 whitespace-nowrap"
                title="Ajouter un nouveau client"
              >
                <Users size={14} /> + Tiers
              </button>
            </div>

            <div className="max-h-56 overflow-y-auto space-y-3 mb-3 pr-1">
              {cart.length === 0 && <p className="text-slate-400 text-sm text-center py-6">Le panier est vide.</p>}
              {cart.map((it) => {
                const itemId = it.productId || it.serviceId;
                return (
                <div key={itemId} className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-xs font-medium text-slate-800 truncate">
                      {it.isService && <Wrench size={10} className="inline mr-1 text-purple-500" />}
                      {it.name} {it.gifted && <span className="text-emerald-600 text-[10px]">(Offert)</span>}
                    </p>
                    <p className="text-[11px] text-slate-400">
                      PU: {it.gifted ? <span className="line-through">{fmtMoney(it.originalPrice ?? it.price, data.settings.currency)}</span> : fmtMoney(it.price, data.settings.currency)}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => toggleGift(itemId)}
                      className={`w-6 h-6 rounded flex items-center justify-center ${it.gifted ? "bg-emerald-100 text-emerald-600" : "bg-slate-100 text-slate-400"}`}
                      title="Marquer comme offert"
                    >
                      <Gift size={12} />
                    </button>
                    <button onClick={() => changeQty(itemId, -1)} className="w-6 h-6 bg-slate-100 rounded flex items-center justify-center">
                      <Minus size={12} />
                    </button>
                    <span className="w-5 text-center text-xs">{it.qty}</span>
                    <button onClick={() => changeQty(itemId, 1)} className="w-6 h-6 bg-slate-100 rounded flex items-center justify-center">
                      <Plus size={12} />
                    </button>
                    <button onClick={() => removeItem(itemId)} className="w-6 h-6 text-red-500 flex items-center justify-center">
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
                );
              })}
            </div>

            <div className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2 mb-3">
              <label className="text-xs text-slate-500 font-medium">Date de la vente</label>
              <input
                type="date"
                value={saleDate}
                onChange={(e) => setSaleDate(e.target.value)}
                className="text-xs bg-white border border-slate-200 rounded px-2 py-1"
              />
            </div>

            {client && client.loyaltyPoints > 0 && (
              <label className="flex items-center justify-between bg-emerald-50 rounded-lg px-3 py-2 mb-3 text-xs cursor-pointer">
                <span className="text-emerald-700">
                  Utiliser les points fidélité ? <br /> Dispo : {client.loyaltyPoints} pts (= {fmtMoney(client.loyaltyPoints * 0.1)})
                </span>
                <input type="checkbox" checked={useLoyalty} onChange={(e) => setUseLoyalty(e.target.checked)} />
              </label>
            )}

            <p className="text-[11px] font-semibold text-slate-500 mb-1.5">REMISES & PROMOTIONS</p>
            <div className="grid grid-cols-3 gap-1.5 mb-3">
              {safeDiscountTypes.map((d) => (
                <button
                  key={d}
                  onClick={() => setDiscountType(d)}
                  className={`py-1.5 rounded-lg text-[11px] font-medium border ${
                    discountType === d ? "bg-slate-900 text-white border-slate-900" : "border-slate-200 text-slate-600"
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>
            {discountType !== "Aucune" && (
              <input
                type="number"
                value={discountValue}
                onChange={(e) => setDiscountValue(e.target.value)}
                className={inputCls + " mb-3"}
                placeholder="Valeur de la remise"
              />
            )}

            <p className="text-[11px] font-semibold text-slate-500 mb-1.5">LOGISTIQUE & LIVRAISON</p>
            <div className="grid grid-cols-3 gap-1.5 mb-3">
              {safeDeliveryOptions.map((l) => (
                <button
                  key={l}
                  onClick={() => setLogistic(l)}
                  className={`py-1.5 rounded-lg text-[11px] font-medium border ${
                    logistic === l ? "bg-slate-900 text-white border-slate-900" : "border-slate-200 text-slate-600"
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>
            {logistic === "Payante" && (
              <div className="mb-3">
                <label className="text-xs text-slate-500 mb-1 block">Frais :</label>
                <input type="number" value={deliveryFee} onChange={(e) => setDeliveryFee(e.target.value)} className={inputCls} />
              </div>
            )}

            <div className="grid grid-cols-3 gap-1.5 mb-3">
              {safePaymentMethods.map((m) => (
                <button
                  key={m}
                  onClick={() => setPayMethod(m)}
                  className={`py-1.5 rounded-lg text-[11px] font-medium border ${
                    payMethod === m ? "bg-blue-600 text-white border-blue-600" : "border-slate-200 text-slate-600"
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>

            {payMethod !== "Credit" && (
              <div className="flex items-center justify-between gap-2 mb-3">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-[11px] text-slate-500">PERÇU</label>
                    <button type="button" onClick={() => setReceived(total)} className="text-[11px] text-blue-600 font-medium hover:underline">
                      Montant exact
                    </button>
                  </div>
                  <input type="number" value={received} onChange={(e) => setReceived(e.target.value)} className={inputCls} />
                </div>
                <div className="flex-1 text-right">
                  <label className="text-[11px] text-slate-500 block">RENDU</label>
                  <p className="text-sm font-semibold">{fmtMoney(change, data.settings.currency)}</p>
                </div>
              </div>
            )}

            <div className="bg-slate-900 rounded-xl p-4 flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-[11px]">TOTAL NET</p>
                <p className="text-white text-lg font-bold">{fmtMoney(total, data.settings.currency)}</p>
              </div>
              <Btn onClick={validateSale} variant="primary">Valider la vente</Btn>
            </div>
          </Card>
        </div>
      </div>

      {showQuickClient && (
        <Modal title="Ajouter un Nouveau Client" onClose={() => setShowQuickClient(false)}>
          <Field label="Nom Complet *">
            <input value={quickClientForm.name} onChange={(e) => setQuickClientForm({ ...quickClientForm, name: e.target.value })} className={inputCls} placeholder="Nom complet ou raison sociale" />
          </Field>
          <Field label="Téléphone">
            <input value={quickClientForm.phone} onChange={(e) => setQuickClientForm({ ...quickClientForm, phone: e.target.value })} className={inputCls} placeholder="Ex: 0661123456" />
          </Field>
          <Field label="E-mail">
            <input value={quickClientForm.email} onChange={(e) => setQuickClientForm({ ...quickClientForm, email: e.target.value })} className={inputCls} placeholder="Ex: client@mail.com" />
          </Field>
          <Field label="Adresse Géographique">
            <input value={quickClientForm.address} onChange={(e) => setQuickClientForm({ ...quickClientForm, address: e.target.value })} className={inputCls} placeholder="Adresse, Ville" />
          </Field>
          <Btn onClick={saveQuickClient}>Ajouter</Btn>
        </Modal>
      )}

      {lastInvoice && (
        <div className="fixed bottom-6 right-6 bg-slate-900 text-white rounded-xl shadow-2xl p-4 flex items-center gap-4 z-40 animate-in">
          <div className="w-9 h-9 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
            <Check size={18} className="text-emerald-400" />
          </div>
          <div>
            <p className="text-sm font-medium">Vente {lastInvoice.ref} enregistrée</p>
            <p className="text-xs text-slate-400">{fmtMoney(lastInvoice.total, data.settings.currency)}</p>
          </div>
          <Btn size="sm" variant="success" icon={Printer} onClick={() => printReceiptDirect(lastInvoice, data.settings, showToast)}>
            Imprimer le Ticket
          </Btn>
          <button onClick={() => generateReceiptPDF(lastInvoice, data.settings)} className="text-slate-400 hover:text-white p-1" title="Télécharger en PDF">
            <Download size={16} />
          </button>
          <button onClick={() => setLastInvoice(null)} className="text-slate-400 hover:text-white">
            <X size={16} />
          </button>
        </div>
      )}
    </div>
  );
}

// ---------- Invoices / Documents Commerciaux ----------
function DocLineEditor({ data, items, setItems }) {
  const addRow = () => setItems((it) => [...it, { productId: "", qty: 1, price: 0 }]);
  const updateRow = (idx, patch) =>
    setItems((it) =>
      it.map((r, i) => {
        if (i !== idx) return r;
        const next = { ...r, ...patch };
        if (patch.productId) {
          const p = data.products.find((pp) => pp.id === patch.productId);
          if (p) next.price = p.sellPrice;
        }
        return next;
      })
    );
  const removeRow = (idx) => setItems((it) => it.filter((_, i) => i !== idx));

  return (
    <div className="space-y-2 mb-3">
      {items.map((r, idx) => (
        <div key={idx} className="flex gap-2 items-center">
          <select
            value={r.productId}
            onChange={(e) => updateRow(idx, { productId: e.target.value })}
            className="flex-1 min-w-0 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white transition-colors"
          >
            <option value="">Sélectionner un produit</option>
            {data.products.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
          <input type="number" value={r.qty} onChange={(e) => updateRow(idx, { qty: e.target.value })} className={inputClsW("w-20")} placeholder="Qté" />
          <input type="number" value={r.price} onChange={(e) => updateRow(idx, { price: e.target.value })} className={inputClsW("w-28")} placeholder="Prix" />
          <button onClick={() => removeRow(idx)} className="text-red-500 p-2"><Trash2 size={16} /></button>
        </div>
      ))}
      <Btn variant="ghost" icon={Plus} onClick={addRow}>Ajouter une ligne</Btn>
    </div>
  );
}

function Invoices({ data, persist, showToast }) {
  const lang = data.settings.language || "fr";
  const [tab, setTab] = useState("invoices");
  const [q, setQ] = useState("");
  const [viewing, setViewing] = useState(null);
  const [docModal, setDocModal] = useState(null); // 'quote' | 'bl'
  const [returnModal, setReturnModal] = useState(false);
  const [clientId, setClientId] = useState(data.clients[0]?.id || "");
  const [items, setItems] = useState([{ productId: "", qty: 1, price: 0 }]);
  const [invoicePaymentStatus, setInvoicePaymentStatus] = useState("Payé");
  const [invoiceAdvance, setInvoiceAdvance] = useState(0);
  const [returnInvoiceId, setReturnInvoiceId] = useState("");
  const [returnItems, setReturnItems] = useState([]);
  const [editingInvoice, setEditingInvoice] = useState(null);
  const [editForm, setEditForm] = useState(null);
  const [editItems, setEditItems] = useState([]);
  const [editingDoc, setEditingDoc] = useState(null); // { doc, type: "quote" | "bl" }
  const [editDocClientId, setEditDocClientId] = useState("");
  const [editDocItems, setEditDocItems] = useState([]);

  const list = data.invoices.filter(
    (i) => String(i.ref || "").toLowerCase().includes(q.toLowerCase()) || String(i.clientName || "").toLowerCase().includes(q.toLowerCase())
  );

  const del = async (id) => {
    const target = data.invoices.find((i) => i.id === id);
    const invoices = data.invoices.filter((i) => i.id !== id);
    const wasLastCreated =
      target?.counterValue != null && !data.invoices.some((i) => i.id !== id && i.counterValue > target.counterValue);
    const invoiceCounter = wasLastCreated ? Math.max(data.invoiceCounter - 1, 0) : data.invoiceCounter;
    await persist({ ...data, invoices, invoiceCounter });
    showToast(wasLastCreated ? "Facture supprimée — numéro réutilisable pour la prochaine facture." : "Facture supprimée.");
  };

  const openEditInvoice = (inv) => {
    setEditingInvoice(inv);
    setEditForm({ clientName: inv.clientName, paid: inv.paid, status: inv.status });
    setEditItems(inv.items.map((it) => ({ ...it })));
  };

  const saveEditInvoice = async () => {
    const validItems = editItems.filter((r) => r.productId && Number(r.qty) > 0);
    const newTotal = validItems.reduce((s, r) => s + Number(r.qty) * Number(r.price), 0);
    const paidNum = Math.min(Number(editForm.paid) || 0, newTotal);
    const oldPaid = editingInvoice.paid;
    const oldRemaining = editingInvoice.total - oldPaid;
    const newRemaining = newTotal - paidNum;
    const deltaPaid = paidNum - oldPaid;
    const status = paidNum >= newTotal && newTotal > 0 ? "PAID" : paidNum > 0 ? "PARTIAL" : "UNPAID";

    const oldQty = {};
    editingInvoice.items.forEach((it) => { if (it.productId) oldQty[it.productId] = (oldQty[it.productId] || 0) + Number(it.qty); });
    const newQty = {};
    validItems.forEach((it) => { newQty[it.productId] = (newQty[it.productId] || 0) + Number(it.qty); });
    const allProductIds = new Set([...Object.keys(oldQty), ...Object.keys(newQty)]);

    let products = [...data.products];
    let stockMovements = [...data.stockMovements];
    allProductIds.forEach((pid) => {
      const delta = (newQty[pid] || 0) - (oldQty[pid] || 0);
      if (delta === 0) return;
      products = products.map((p) => {
        if (p.id !== pid) return p;
        const oldStock = p.stock;
        const newStock = oldStock - delta;
        stockMovements = [
          { id: uid("mov"), date: new Date().toISOString(), product: p.name, type: delta > 0 ? "Sortie" : "Entrée", delta: -delta, oldStock, newStock, reason: `Modification Facture ${editingInvoice.ref}` },
          ...stockMovements,
        ];
        return { ...p, stock: newStock };
      });
    });

    const enrichedItems = validItems.map((r) => ({ ...r, name: products.find((p) => p.id === r.productId)?.name || r.name, qty: Number(r.qty), price: Number(r.price) }));

    const invoices = data.invoices.map((i) =>
      i.id === editingInvoice.id ? { ...i, clientName: editForm.clientName, items: enrichedItems, subtotal: newTotal, total: newTotal, paid: paidNum, status } : i
    );
    const clients = data.clients.map((c) =>
      c.id === editingInvoice.clientId ? { ...c, credit: Math.max((c.credit || 0) + (newRemaining - oldRemaining), 0) } : c
    );
    const cashRegister = { ...data.cashRegister, solde: (data.cashRegister.solde || 0) + deltaPaid };
    await persist({ ...data, invoices, clients, cashRegister, products, stockMovements });
    showToast("Facture modifiée.");
    setEditingInvoice(null);
  };

  const [payingInvoice, setPayingInvoice] = useState(null);
  const [payAmount, setPayAmount] = useState(0);
  const [payMethodInput, setPayMethodInput] = useState("Cash");
  const [payReference, setPayReference] = useState("");

  const saveInvoicePayment = async () => {
    const amountReceived = Number(payAmount) || 0;
    if (amountReceived <= 0) return showToast("Le montant doit être supérieur à 0.", "error");
    const newPaid = (payingInvoice.paid || 0) + amountReceived;
    const status = newPaid >= payingInvoice.total ? "PAID" : newPaid > 0 ? "PARTIAL" : "UNPAID";
    const paymentEntry = {
      id: uid("pay"),
      date: new Date().toISOString(),
      amount: amountReceived,
      method: payMethodInput,
      reference: payReference,
      remainingAfter: Math.max(payingInvoice.total - newPaid, 0),
    };
    const invoices = data.invoices.map((i) =>
      i.id === payingInvoice.id ? { ...i, paid: newPaid, status, paymentHistory: [...(i.paymentHistory || []), paymentEntry] } : i
    );
    const clients = data.clients.map((c) =>
      c.id === payingInvoice.clientId ? { ...c, credit: Math.max((c.credit || 0) - amountReceived, 0) } : c
    );
    const cashRegister = { ...data.cashRegister, solde: (data.cashRegister.solde || 0) + amountReceived };
    const securityLog = logEvent(data, "Administrateur", "PAIEMENT FACTURE ENREGISTRÉ", `${fmtMoney(amountReceived, data.settings.currency)} reçu pour ${payingInvoice.ref}.`);
    await persist({ ...data, invoices, clients, cashRegister, securityLog });
    showToast(status === "PAID" ? `Facture ${payingInvoice.ref} entièrement payée.` : "Paiement enregistré.");
    setPayingInvoice(null);
    setPayReference("");
  };

  const openEditDoc = (doc, type) => {
    console.log("DEBUG: openEditDoc called with", doc.ref, type);
    setEditingDoc({ doc, type });
    setEditDocClientId(doc.clientId || "");
    setEditDocItems(doc.items.map((it) => ({ ...it })));
    console.log("DEBUG: setEditingDoc called");
  };

  const saveEditDoc = async () => {
    const { doc, type } = editingDoc;
    const validItems = editDocItems.filter((r) => r.productId && Number(r.qty) > 0);
    if (validItems.length === 0) return showToast("Ajoutez au moins un produit.", "error");
    const client = data.clients.find((c) => c.id === editDocClientId);
    const newTotal = validItems.reduce((s, r) => s + Number(r.qty) * Number(r.price), 0);
    const enrichedItems = validItems.map((r) => ({ ...r, name: data.products.find((p) => p.id === r.productId)?.name, qty: Number(r.qty), price: Number(r.price) }));

    if (type === "quote") {
      // Devis don't affect stock at all, so editing is a simple content update.
      const quotes = data.quotes.map((q) =>
        q.id === doc.id ? { ...q, clientId: editDocClientId, clientName: client?.name || "Client de Passage", items: enrichedItems, total: newTotal } : q
      );
      await persist({ ...data, quotes });
      showToast("Devis modifié.");
    } else {
      // BL affects stock at creation — adjust stock by the DELTA between the
      // old and new quantities for every affected product, same principle
      // used for editing Factures.
      const oldQty = {};
      doc.items.forEach((it) => { if (it.productId) oldQty[it.productId] = (oldQty[it.productId] || 0) + Number(it.qty); });
      const newQty = {};
      validItems.forEach((it) => { newQty[it.productId] = (newQty[it.productId] || 0) + Number(it.qty); });
      const allProductIds = new Set([...Object.keys(oldQty), ...Object.keys(newQty)]);

      let products = [...data.products];
      let stockMovements = [...data.stockMovements];
      allProductIds.forEach((pid) => {
        const delta = (newQty[pid] || 0) - (oldQty[pid] || 0);
        if (delta === 0) return;
        products = products.map((p) => {
          if (p.id !== pid) return p;
          const oldStock = p.stock;
          const newStock = oldStock - delta;
          stockMovements = [
            { id: uid("mov"), date: new Date().toISOString(), product: p.name, type: delta > 0 ? "Sortie" : "Entrée", delta: -delta, oldStock, newStock, reason: `Modification BL ${doc.ref}` },
            ...stockMovements,
          ];
          return { ...p, stock: newStock };
        });
      });

      const deliveryNotes = data.deliveryNotes.map((b) =>
        b.id === doc.id ? { ...b, clientId: editDocClientId, clientName: client?.name || "Client de Passage", items: enrichedItems, total: newTotal } : b
      );
      await persist({ ...data, deliveryNotes, products, stockMovements });
      showToast("Bon de Livraison modifié.");
    }
    setEditingDoc(null);
  };

  const createBLFromInvoice = async (inv) => {
    const ref = makeRef(data.settings, "delivery", data.deliveryCounter);
    const bl = {
      id: uid("bl"), ref, date: new Date().toISOString(), clientId: inv.clientId, clientName: inv.clientName,
      items: inv.items.map((it) => ({ ...it })), total: inv.total, converted: true,
      fromInvoiceRef: inv.ref,
    };
    await persist({ ...data, deliveryNotes: [bl, ...data.deliveryNotes], deliveryCounter: data.deliveryCounter + 1 });
    showToast(`BL créé à partir de ${inv.ref} — ${ref}`);
  };

  const statusColor = { PAID: "bg-emerald-100 text-emerald-700", PARTIAL: "bg-amber-100 text-amber-700", UNPAID: "bg-red-100 text-red-700" };

  const resetDocForm = () => {
    setItems([{ productId: "", qty: 1, price: 0 }]);
    setClientId(data.clients[0]?.id || "");
  };

  const saveDoc = async () => {
    const valid = items.filter((r) => r.productId && Number(r.qty) > 0);
    if (valid.length === 0) return showToast("Ajoutez au moins un produit.", "error");
    const client = data.clients.find((c) => c.id === clientId);
    const total = valid.reduce((s, r) => s + Number(r.qty) * Number(r.price), 0);
    const enrichedItems = valid.map((r) => ({ ...r, name: data.products.find((p) => p.id === r.productId)?.name, qty: Number(r.qty), price: Number(r.price) }));

    if (docModal === "invoice") {
      const ref = makeRef(data.settings, "invoice", data.invoiceCounter);
      let products = [...data.products];
      let stockMovements = [...data.stockMovements];
      enrichedItems.forEach((it) => {
        products = products.map((p) => {
          if (p.id !== it.productId) return p;
          const oldStock = p.stock;
          const newStock = oldStock - it.qty;
          stockMovements = [{ id: uid("mov"), date: new Date().toISOString(), product: p.name, type: "Sortie", delta: -it.qty, oldStock, newStock, reason: `Vente ${ref}` }, ...stockMovements];
          return { ...p, stock: newStock };
        });
      });
      const paid = invoicePaymentStatus === "Payé" ? total : invoicePaymentStatus === "Avance" ? Number(invoiceAdvance) || 0 : 0;
      const status = paid >= total ? "PAID" : paid > 0 ? "PARTIAL" : "UNPAID";
      const invoice = {
        id: uid("inv"), ref, date: new Date().toISOString(), clientId, clientName: client?.name || "Client de Passage",
        items: enrichedItems, subtotal: total, discount: 0, deliveryFee: 0, total, paid, status,
        payMethod: invoicePaymentStatus === "Payé" ? "Cash" : "Credit",
        counterValue: data.invoiceCounter,
        paymentHistory: paid > 0 ? [{ id: uid("pay"), date: new Date().toISOString(), amount: paid, method: invoicePaymentStatus === "Payé" ? "Cash" : "Avance", reference: "" }] : [],
      };
      const clients = data.clients.map((c) => (c.id === clientId ? { ...c, credit: (c.credit || 0) + (total - paid) } : c));
      const cashRegister = { ...data.cashRegister, solde: (data.cashRegister.solde || 0) + paid };
      if (window.produitsBridge) {
        await window.produitsBridge.creerVenteReelle(enrichedItems.map((it) => ({ productId: it.productId, qty: it.qty, price: it.price })), clientId);
      }
      await persist({ ...data, invoices: [invoice, ...data.invoices], invoiceCounter: data.invoiceCounter + 1, products, stockMovements, clients, cashRegister });
      showToast(`Facture créée — ${ref}`);
      setDocModal(null);
      return;
    }

    if (docModal === "quote") {
      const ref = makeRef(data.settings, "quote", data.quoteCounter);
      const quote = { id: uid("quo"), ref, date: new Date().toISOString(), clientId, clientName: client?.name || "Client de Passage", items: enrichedItems, total, converted: false };
      if (window.produitsBridge) await window.produitsBridge.creerDocumentReel("devis", clientId, enrichedItems);
      await persist({ ...data, quotes: [quote, ...data.quotes], quoteCounter: data.quoteCounter + 1 });
      showToast(`Devis créé — ${ref}`);
    } else {
      const ref = makeRef(data.settings, "delivery", data.deliveryCounter);
      let products = [...data.products];
      let stockMovements = [...data.stockMovements];
      enrichedItems.forEach((it) => {
        products = products.map((p) => {
          if (p.id !== it.productId) return p;
          const oldStock = p.stock;
          const newStock = oldStock - it.qty;
          stockMovements = [{ id: uid("mov"), date: new Date().toISOString(), product: p.name, type: "Sortie", delta: -it.qty, oldStock, newStock, reason: `Livraison ${ref}` }, ...stockMovements];
          return { ...p, stock: newStock };
        });
      });
      const bl = { id: uid("bl"), ref, date: new Date().toISOString(), clientId, clientName: client?.name || "Client de Passage", items: enrichedItems, total, converted: false };
      if (window.produitsBridge) await window.produitsBridge.creerDocumentReel("bon_livraison", clientId, enrichedItems);
      await persist({ ...data, deliveryNotes: [bl, ...data.deliveryNotes], deliveryCounter: data.deliveryCounter + 1, products, stockMovements });
      showToast(`Bon de livraison créé — ${ref}`);
    }
    setDocModal(null);
    resetDocForm();
  };

  const convertToInvoice = async (doc, type) => {
    const ref = makeRef(data.settings, "invoice", data.invoiceCounter);
    let products = [...data.products];
    let stockMovements = [...data.stockMovements];
    if (type === "quote") {
      // stock leaves only now, since a quote had no stock impact yet
      doc.items.forEach((it) => {
        products = products.map((p) => {
          if (p.id !== it.productId) return p;
          const oldStock = p.stock;
          const newStock = oldStock - it.qty;
          stockMovements = [{ id: uid("mov"), date: new Date().toISOString(), product: p.name, type: "Sortie", delta: -it.qty, oldStock, newStock, reason: `Vente (devis converti) ${ref}` }, ...stockMovements];
          return { ...p, stock: newStock };
        });
      });
    }
    const invoice = {
      id: uid("inv"),
      ref,
      date: new Date().toISOString(),
      clientId: doc.clientId,
      clientName: doc.clientName,
      items: doc.items,
      subtotal: doc.total,
      discount: 0,
      deliveryFee: 0,
      total: doc.total,
      paid: 0,
      status: "UNPAID",
      payMethod: "Credit",
      counterValue: data.invoiceCounter,
    };
    const clients = data.clients.map((c) => (c.id === doc.clientId ? { ...c, credit: (c.credit || 0) + doc.total } : c));

    const patch = { invoices: [invoice, ...data.invoices], invoiceCounter: data.invoiceCounter + 1, products, stockMovements, clients };
    if (type === "quote") patch.quotes = data.quotes.map((x) => (x.id === doc.id ? { ...x, converted: true } : x));
    if (type === "bl") patch.deliveryNotes = data.deliveryNotes.map((x) => (x.id === doc.id ? { ...x, converted: true } : x));

    if (window.produitsBridge) {
      if (type === "quote") {
        // Le devis n'avait pas touche le stock ; la conversion agit comme
        // une vraie vente (creerVenteReelle gere stock + enregistrement).
        await window.produitsBridge.creerVenteReelle(doc.items.map((it) => ({ productId: it.productId, qty: it.qty, price: it.price })), doc.clientId);
      } else {
        // Le BL avait deja affecte le stock a sa creation ; on enregistre
        // ici uniquement le document facture, sans toucher au stock a nouveau.
        await window.produitsBridge.creerDocumentReel("facture", doc.clientId, doc.items);
      }
    }
    await persist({ ...data, ...patch });
    showToast(`Converti en facture — ${ref}`);
  };

  const toggleReturnItem = (invItem) => {
    setReturnItems((cur) => {
      const exists = cur.find((r) => r.productId === invItem.productId);
      if (exists) return cur.filter((r) => r.productId !== invItem.productId);
      return [...cur, { productId: invItem.productId, name: invItem.name, qty: 1, maxQty: invItem.qty, price: invItem.price }];
    });
  };
  const updateReturnQty = (productId, qty) => {
    setReturnItems((cur) => cur.map((r) => (r.productId === productId ? { ...r, qty: Math.min(Math.max(Number(qty), 1), r.maxQty) } : r)));
  };

  const submitReturn = async () => {
    const invoice = data.invoices.find((i) => i.id === returnInvoiceId);
    if (!invoice) return showToast("Sélectionnez une facture.", "error");
    if (returnItems.length === 0) return showToast("Sélectionnez au moins un article à retourner.", "error");
    const ref = makeRef(data.settings, "return", data.returnCounter);
    const totalReturn = returnItems.reduce((s, r) => s + r.qty * r.price, 0);

    let products = [...data.products];
    let stockMovements = [...data.stockMovements];
    returnItems.forEach((r) => {
      products = products.map((p) => {
        if (p.id !== r.productId) return p;
        const oldStock = p.stock;
        const newStock = oldStock + r.qty;
        stockMovements = [{ id: uid("mov"), date: new Date().toISOString(), product: p.name, type: "Entrée", delta: r.qty, oldStock, newStock, reason: `Retour ${ref} (${invoice.ref})` }, ...stockMovements];
        return { ...p, stock: newStock };
      });
    });

    const clients = data.clients.map((c) => (c.id === invoice.clientId ? { ...c, credit: Math.max((c.credit || 0) - totalReturn, 0) } : c));
    const returnDoc = { id: uid("ret"), ref, date: new Date().toISOString(), invoiceRef: invoice.ref, clientName: invoice.clientName, items: returnItems, total: totalReturn };

    if (window.produitsBridge) {
      await window.produitsBridge.creerDocumentReel("avoir", invoice.clientId, returnItems);
    }
    await persist({ ...data, returns: [returnDoc, ...data.returns], returnCounter: data.returnCounter + 1, products, stockMovements, clients });
    showToast(`Retour / Avoir enregistré — ${ref}`);
    setReturnModal(false);
    setReturnInvoiceId("");
    setReturnItems([]);
  };

  return (
    <div>
      <PageHeader
        title={t(lang, "page_invoices_title")}
        subtitle={t(lang, "page_invoices_subtitle")}
        actions={
          <>
            <Btn onClick={() => { resetDocForm(); setDocModal("invoice"); }}>+ Créer une Facture</Btn>
            <Btn variant="ghost" onClick={() => { resetDocForm(); setDocModal("quote"); }}>+ Créer un Devis</Btn>
            <Btn variant="success" onClick={() => { resetDocForm(); setDocModal("bl"); }}>+ Créer un BL</Btn>
            <Btn variant="danger" onClick={() => setReturnModal(true)}>+ Retour Marchandise</Btn>
          </>
        }
      />
      <div className="flex gap-1 mb-4 border-b border-slate-200">
        {[
          ["invoices", `Factures de Vente (${data.invoices.length})`],
          ["quotes", `Devis (Propositions) (${data.quotes.length})`],
          ["bl", `Bons de Livraison (${data.deliveryNotes.length})`],
          ["returns", `Retours / Avoirs (${data.returns.length})`],
        ].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px ${
              tab === key ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "invoices" && (
        <Card>
          <div className="p-4 border-b border-slate-100">
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 max-w-md">
              <Search size={16} className="text-slate-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher par numéro de document, ou nom du tiers..." className="flex-1 outline-none text-sm bg-transparent" />
            </div>
          </div>
          {list.length === 0 ? (
            <EmptyState text="Aucune facture enregistrée." />
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                  <th className="px-5 py-3 font-medium">Référence</th>
                  <th className="px-5 py-3 font-medium">Date</th>
                  <th className="px-5 py-3 font-medium">Client</th>
                  <th className="px-5 py-3 font-medium">Montant TTC</th>
                  <th className="px-5 py-3 font-medium">Statut</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {list.map((inv) => (
                  <tr key={inv.id} className="border-b border-slate-50 hover:bg-slate-50">
                    <td className="px-5 py-3 font-semibold text-slate-800">{inv.ref}</td>
                    <td className="px-5 py-3 text-slate-500">{fmtDate(inv.date)}</td>
                    <td className="px-5 py-3">{inv.clientName}</td>
                    <td className="px-5 py-3 font-medium">{fmtMoney(inv.total, data.settings.currency)}</td>
                    <td className="px-5 py-3">
                      <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${statusColor[inv.status]}`}>{inv.status}</span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-1 text-slate-400">
                        <button onClick={() => setViewing({ ...inv, _type: "Facture" })} className="p-1.5 hover:text-blue-600" title="Voir">
                          <Eye size={15} />
                        </button>
                        {inv.status !== "PAID" && (
                          <button
                            onClick={() => { setPayingInvoice(inv); setPayAmount(Math.max(inv.total - (inv.paid || 0), 0)); }}
                            className="p-1.5 hover:text-emerald-600"
                            title="Enregistrer un Paiement"
                          >
                            <HandCoins size={15} />
                          </button>
                        )}
                        <button onClick={() => openEditInvoice(inv)} className="p-1.5 hover:text-slate-700" title="Modifier">
                          <Pencil size={15} />
                        </button>
                        <button onClick={() => createBLFromInvoice(inv)} className="p-1.5 hover:text-blue-600" title="Créer un BL à partir de cette Facture">
                          <Truck size={15} />
                        </button>
                        <button onClick={() => printReceiptDirect(inv, data.settings, showToast)} className="p-1.5 hover:text-slate-700" title="Imprimer le Ticket">
                          <Printer size={15} />
                        </button>
                        <button onClick={() => generateInvoicePDF(inv, data.settings)} className="p-1.5 hover:text-slate-700" title="Télécharger en PDF">
                          <Download size={15} />
                        </button>
                        <button onClick={() => del(inv.id)} className="p-1.5 hover:text-red-600" title="Supprimer">
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}

      {tab === "quotes" && (
        <Card>
          {data.quotes.length === 0 ? (
            <EmptyState text="Aucun devis créé pour le moment." />
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                  <th className="px-5 py-3 font-medium">Référence</th>
                  <th className="px-5 py-3 font-medium">Date</th>
                  <th className="px-5 py-3 font-medium">Client</th>
                  <th className="px-5 py-3 font-medium">Montant</th>
                  <th className="px-5 py-3 font-medium">Statut</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.quotes.map((doc) => (
                  <tr key={doc.id} className="border-b border-slate-50">
                    <td className="px-5 py-3 font-semibold">{doc.ref}</td>
                    <td className="px-5 py-3 text-slate-500">{fmtDate(doc.date)}</td>
                    <td className="px-5 py-3">{doc.clientName}</td>
                    <td className="px-5 py-3 font-medium">{fmtMoney(doc.total, data.settings.currency)}</td>
                    <td className="px-5 py-3">
                      <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${doc.converted ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                        {doc.converted ? "Converti" : "En attente"}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => setViewing({ ...doc, _type: "Devis" })} className="p-1.5 text-slate-400 hover:text-blue-600" title="Voir"><Eye size={15} /></button>
                        {!doc.converted && (
                          <button onClick={() => openEditDoc(doc, "quote")} className="p-1.5 text-slate-400 hover:text-slate-700" title="Modifier"><Pencil size={15} /></button>
                        )}
                        {!doc.converted && <Btn size="sm" onClick={() => convertToInvoice(doc, "quote")}>Convertir en Facture</Btn>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}

      {tab === "bl" && (
        <Card>
          {data.deliveryNotes.length === 0 ? (
            <EmptyState text="Aucun bon de livraison créé pour le moment." />
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                  <th className="px-5 py-3 font-medium">Référence</th>
                  <th className="px-5 py-3 font-medium">Date</th>
                  <th className="px-5 py-3 font-medium">Client</th>
                  <th className="px-5 py-3 font-medium">Montant</th>
                  <th className="px-5 py-3 font-medium">Statut</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.deliveryNotes.map((doc) => (
                  <tr key={doc.id} className="border-b border-slate-50">
                    <td className="px-5 py-3 font-semibold">{doc.ref}</td>
                    <td className="px-5 py-3 text-slate-500">{fmtDate(doc.date)}</td>
                    <td className="px-5 py-3">{doc.clientName}</td>
                    <td className="px-5 py-3 font-medium">{fmtMoney(doc.total, data.settings.currency)}</td>
                    <td className="px-5 py-3">
                      <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${doc.converted ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-500"}`}>
                        {doc.converted ? "Facturé" : "Livré, non facturé"}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => setViewing({ ...doc, _type: "Bon de Livraison" })} className="p-1.5 text-slate-400 hover:text-blue-600" title="Voir"><Eye size={15} /></button>
                        {!doc.converted && (
                          <button onClick={() => openEditDoc(doc, "bl")} className="p-1.5 text-slate-400 hover:text-slate-700" title="Modifier"><Pencil size={15} /></button>
                        )}
                        {!doc.converted && <Btn size="sm" onClick={() => convertToInvoice(doc, "bl")}>Convertir en Facture</Btn>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}

      {tab === "returns" && (
        <Card>
          {data.returns.length === 0 ? (
            <EmptyState text="Aucun retour / avoir enregistré." />
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                  <th className="px-5 py-3 font-medium">Référence</th>
                  <th className="px-5 py-3 font-medium">Date</th>
                  <th className="px-5 py-3 font-medium">Facture liée</th>
                  <th className="px-5 py-3 font-medium">Client</th>
                  <th className="px-5 py-3 font-medium">Montant</th>
                </tr>
              </thead>
              <tbody>
                {data.returns.map((doc) => (
                  <tr key={doc.id} className="border-b border-slate-50">
                    <td className="px-5 py-3 font-semibold">{doc.ref}</td>
                    <td className="px-5 py-3 text-slate-500">{fmtDate(doc.date)}</td>
                    <td className="px-5 py-3">{doc.invoiceRef}</td>
                    <td className="px-5 py-3">{doc.clientName}</td>
                    <td className="px-5 py-3 font-medium text-red-600">-{fmtMoney(doc.total, data.settings.currency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      )}

      {viewing && (
        <Modal title={`${viewing._type} ${viewing.ref}`} onClose={() => setViewing(null)}>
          <p className="text-sm text-slate-500 mb-1">Client : <span className="text-slate-800 font-medium">{viewing.clientName}</span></p>
          <p className="text-sm text-slate-500 mb-4">Date : {fmtDate(viewing.date)}</p>
          <div className="border border-slate-100 rounded-lg divide-y divide-slate-100 mb-4">
            {viewing.items.map((it, idx) => (
              <div key={idx} className="flex justify-between px-3 py-2 text-sm">
                <span>{it.name} × {it.qty}</span>
                <span className="font-medium">{fmtMoney(it.price * it.qty, data.settings.currency)}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between text-base font-bold text-slate-900 pt-2 border-t border-slate-100">
            <span>Total</span> <span>{fmtMoney(viewing.total, data.settings.currency)}</span>
          </div>
          {viewing.paid !== undefined && (
            <div className="mt-3 bg-slate-50 rounded-lg p-3 space-y-1.5">
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Déjà Payé</span>
                <span className="font-medium text-emerald-600">{fmtMoney(viewing.paid || 0, data.settings.currency)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-500">Reste à Payer</span>
                <span className={`font-semibold ${viewing.total - (viewing.paid || 0) > 0 ? "text-red-600" : "text-emerald-600"}`}>
                  {fmtMoney(Math.max(viewing.total - (viewing.paid || 0), 0), data.settings.currency)}
                </span>
              </div>
            </div>
          )}
          {viewing.paymentHistory && viewing.paymentHistory.length > 0 && (
            <div className="mt-3">
              <p className="text-xs font-semibold text-slate-500 uppercase mb-1.5">Historique des Paiements</p>
              <div className="space-y-1.5">
                {viewing.paymentHistory.map((p) => (
                  <div key={p.id} className="flex justify-between items-center bg-slate-50 rounded-lg px-3 py-2 text-xs">
                    <div>
                      <p className="font-medium text-slate-700">{fmtMoney(p.amount, data.settings.currency)} — {p.method}</p>
                      <p className="text-slate-400">{fmtDate(p.date)}{p.reference ? ` • Réf: ${p.reference}` : ""}</p>
                    </div>
                    <span className="text-slate-500">Reste: {fmtMoney(p.remainingAfter, data.settings.currency)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          {viewing._type === "Facture" && viewing.status !== "PAID" && (
            <div className="mt-3">
              <Btn
                icon={HandCoins}
                variant="success"
                onClick={() => {
                  const fullInvoice = data.invoices.find((i) => i.id === viewing.id);
                  setPayingInvoice(fullInvoice);
                  setPayAmount(Math.max(fullInvoice.total - (fullInvoice.paid || 0), 0));
                  setViewing(null);
                }}
              >
                Enregistrer un Paiement
              </Btn>
            </div>
          )}
        </Modal>
      )}

      {payingInvoice && (
        <Modal title={`Enregistrer un Paiement — ${payingInvoice.ref}`} onClose={() => setPayingInvoice(null)}>
          <div className="bg-slate-50 rounded-lg p-3 mb-4 space-y-1.5">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Total de la Facture</span>
              <span className="font-medium">{fmtMoney(payingInvoice.total, data.settings.currency)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Déjà Payé</span>
              <span className="font-medium text-emerald-600">{fmtMoney(payingInvoice.paid || 0, data.settings.currency)}</span>
            </div>
            <div className="flex justify-between text-sm border-t border-slate-200 pt-1.5">
              <span className="text-slate-600 font-medium">Reste à Payer</span>
              <span className="font-semibold text-red-600">{fmtMoney(Math.max(payingInvoice.total - (payingInvoice.paid || 0), 0), data.settings.currency)}</span>
            </div>
          </div>
          <Field label="Montant Reçu Maintenant">
            <input type="number" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} className={inputCls} />
          </Field>
          <Field label="Mode de Paiement">
            <div className="grid grid-cols-4 gap-2">
              {["Cash", "Carte", "Vir.", "Chèque"].map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setPayMethodInput(m)}
                  className={`py-1.5 rounded-lg text-xs font-medium border ${payMethodInput === m ? "bg-slate-900 text-white border-slate-900" : "border-slate-200 text-slate-600"}`}
                >
                  {m}
                </button>
              ))}
            </div>
          </Field>
          <Field label="Référence (optionnel)">
            <input value={payReference} onChange={(e) => setPayReference(e.target.value)} className={inputCls} placeholder="Ex: N° de chèque, référence virement..." />
          </Field>
          <div className="flex gap-2 mb-4">
            <Btn variant="outline" size="sm" onClick={() => setPayAmount(Math.max(payingInvoice.total - (payingInvoice.paid || 0), 0))}>
              Marquer Payée en Totalité
            </Btn>
          </div>
          <Btn icon={Check} onClick={saveInvoicePayment}>Enregistrer le Paiement</Btn>
        </Modal>
      )}

      {editingInvoice && editForm && (
        <Modal title={`Modifier la Facture ${editingInvoice.ref}`} onClose={() => setEditingInvoice(null)} wide>
          <Field label="Nom du Client">
            <input value={editForm.clientName} onChange={(e) => setEditForm({ ...editForm, clientName: e.target.value })} className={inputCls} />
          </Field>
          <p className="text-xs font-semibold text-slate-500 mb-2 uppercase">Articles</p>
          <DocLineEditor data={data} items={editItems} setItems={setEditItems} />
          <div className="flex items-center justify-between border-t border-slate-100 pt-3 mb-3">
            <p className="font-bold">Nouveau Total : {fmtMoney(editItems.filter((r) => r.productId && r.qty > 0).reduce((s, r) => s + Number(r.qty) * Number(r.price), 0), data.settings.currency)}</p>
          </div>
          <Field label="Montant Payé">
            <input type="number" value={editForm.paid} onChange={(e) => setEditForm({ ...editForm, paid: e.target.value })} className={inputCls} />
          </Field>
          <p className="text-xs text-slate-400 mb-4">Le stock, le solde de caisse et le crédit client seront ajustés automatiquement selon les changements.</p>
          <Btn onClick={saveEditInvoice}>Enregistrer</Btn>
        </Modal>
      )}

      {editingDoc && (
        <Modal
          title={`Modifier le ${editingDoc.type === "quote" ? "Devis" : "Bon de Livraison"} ${editingDoc.doc.ref}`}
          onClose={() => setEditingDoc(null)}
          wide
        >
          <Field label="Client">
            <select value={editDocClientId} onChange={(e) => setEditDocClientId(e.target.value)} className={inputCls}>
              {data.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <p className="text-xs font-semibold text-slate-500 mb-2 uppercase">Articles</p>
          <DocLineEditor data={data} items={editDocItems} setItems={setEditDocItems} />
          <div className="flex items-center justify-between border-t border-slate-100 pt-3 mb-3">
            <p className="font-bold">
              Nouveau Total : {fmtMoney(editDocItems.filter((r) => r.productId && r.qty > 0).reduce((s, r) => s + Number(r.qty) * Number(r.price), 0), data.settings.currency)}
            </p>
          </div>
          {editingDoc.type === "bl" && (
            <p className="text-xs text-slate-400 mb-4">Le stock sera ajusté automatiquement selon les changements de quantité.</p>
          )}
          <Btn onClick={saveEditDoc}>Enregistrer</Btn>
        </Modal>
      )}

      {docModal && (
        <Modal
          title={docModal === "quote" ? "Créer un Devis" : docModal === "invoice" ? "Créer une Facture" : "Créer un Bon de Livraison"}
          onClose={() => setDocModal(null)}
          wide
        >
          <Field label="Client">
            <select value={clientId} onChange={(e) => setClientId(e.target.value)} className={inputCls}>
              {data.clients.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <DocLineEditor data={data} items={items} setItems={setItems} />
          {docModal === "invoice" && (
            <>
              <Field label="État de Paiement">
                <div className="grid grid-cols-3 gap-2">
                  {["Payé", "Crédit", "Avance"].map((st) => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setInvoicePaymentStatus(st)}
                      className={`py-2 rounded-lg text-sm font-medium border ${invoicePaymentStatus === st ? "bg-slate-900 text-white border-slate-900" : "border-slate-200 text-slate-600"}`}
                    >
                      {st}
                    </button>
                  ))}
                </div>
              </Field>
              {invoicePaymentStatus === "Avance" && (
                <Field label="Montant de l'Avance">
                  <input type="number" value={invoiceAdvance} onChange={(e) => setInvoiceAdvance(e.target.value)} className={inputCls} />
                </Field>
              )}
            </>
          )}
          <div className="flex items-center justify-between border-t border-slate-100 pt-4">
            <p className="font-bold text-lg">
              Total : {fmtMoney(items.reduce((s, r) => s + Number(r.qty || 0) * Number(r.price || 0), 0), data.settings.currency)}
            </p>
            <Btn onClick={saveDoc}>{docModal === "quote" ? "Créer le Devis" : docModal === "invoice" ? "Créer la Facture" : "Créer le BL"}</Btn>
          </div>
        </Modal>
      )}

      {returnModal && (
        <Modal title="Retour Marchandise / Avoir" onClose={() => setReturnModal(false)} wide>
          <Field label="Facture concernée">
            <select value={returnInvoiceId} onChange={(e) => { setReturnInvoiceId(e.target.value); setReturnItems([]); }} className={inputCls}>
              <option value="">Sélectionner une facture...</option>
              {data.invoices.map((inv) => (
                <option key={inv.id} value={inv.id}>{inv.ref} — {inv.clientName} ({fmtMoney(inv.total, data.settings.currency)})</option>
              ))}
            </select>
          </Field>
          {returnInvoiceId && (
            <div className="space-y-2 mb-4">
              <p className="text-xs font-medium text-slate-500">Sélectionnez les articles à retourner :</p>
              {data.invoices.find((i) => i.id === returnInvoiceId)?.items.map((it) => {
                const selected = returnItems.find((r) => r.productId === it.productId);
                return (
                  <div key={it.productId} className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2">
                    <label className="flex items-center gap-2 text-sm flex-1">
                      <input type="checkbox" checked={!!selected} onChange={() => toggleReturnItem(it)} />
                      {it.name} <span className="text-slate-400">(acheté: {it.qty})</span>
                    </label>
                    {selected && (
                      <input
                        type="number"
                        min={1}
                        max={it.qty}
                        value={selected.qty}
                        onChange={(e) => updateReturnQty(it.productId, e.target.value)}
                        className={inputClsW("w-20")}
                      />
                    )}
                  </div>
                );
              })}
            </div>
          )}
          <div className="flex items-center justify-between border-t border-slate-100 pt-4">
            <p className="font-bold text-lg text-red-600">
              Montant à rembourser : {fmtMoney(returnItems.reduce((s, r) => s + r.qty * r.price, 0), data.settings.currency)}
            </p>
            <Btn variant="danger" onClick={submitReturn}>Valider le Retour</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ---------- Purchases ----------
function Purchases({ data, persist, showToast }) {
  const lang = data.settings.language || "fr";
  const [showForm, setShowForm] = useState(false);
  const [viewing, setViewing] = useState(null);
  const [supplierId, setSupplierId] = useState(data.suppliers[0]?.id || "");
  const [items, setItems] = useState([{ productId: "", qty: 1, price: 0 }]);
  const [paid, setPaid] = useState(0);
  const [purchasePayMethod, setPurchasePayMethod] = useState("Cash");
  const [purchasePayReference, setPurchasePayReference] = useState("");

  const addRow = () => setItems((it) => [...it, { productId: "", qty: 1, price: 0 }]);
  const updateRow = (idx, patch) => setItems((it) => it.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
  const removeRow = (idx) => setItems((it) => it.filter((_, i) => i !== idx));

  const total = items.reduce((s, r) => s + Number(r.qty || 0) * Number(r.price || 0), 0);

  const submit = async () => {
    const validItems = items.filter((r) => r.productId && Number(r.qty) > 0);
    if (validItems.length === 0) {
      showToast("Ajoutez au moins un produit.", "error");
      return;
    }
    const ref = makeRef(data.settings, "purchase", data.purchaseCounter);
    let products = [...data.products];
    let stockMovements = [...data.stockMovements];
    validItems.forEach((r) => {
      products = products.map((p) => {
        if (p.id !== r.productId) return p;
        const oldStock = p.stock;
        const newStock = oldStock + Number(r.qty);
        stockMovements = [
          { id: uid("mov"), date: new Date().toISOString(), product: p.name, type: "Entrée", delta: Number(r.qty), oldStock, newStock, reason: `Achat ${ref}` },
          ...stockMovements,
        ];
        return { ...p, stock: newStock, buyPrice: Number(r.price) || p.buyPrice };
      });
    });

    const supplier = data.suppliers.find((s) => s.id === supplierId);
    const purchase = {
      id: uid("pur"),
      ref,
      date: new Date().toISOString(),
      supplierId,
      supplierName: supplier?.name || "Fournisseur divers",
      items: validItems.map((r) => ({ ...r, name: products.find((p) => p.id === r.productId)?.name })),
      total,
      paid: Number(paid) || 0,
      payMethod: Number(paid) > 0 ? purchasePayMethod : "",
      payReference: Number(paid) > 0 ? purchasePayReference : "",
    };

    const suppliers = data.suppliers.map((s) =>
      s.id === supplierId ? { ...s, debt: (s.debt || 0) + (total - (Number(paid) || 0)) } : s
    );

    if (window.produitsBridge) {
      await window.produitsBridge.creerAchatReel(validItems, supplierId);
    }
    await persist({
      ...data,
      products,
      stockMovements,
      suppliers,
      purchases: [purchase, ...data.purchases],
      purchaseCounter: data.purchaseCounter + 1,
    });
    showToast(`Achat enregistré — ${ref}`);
    setShowForm(false);
    setItems([{ productId: "", qty: 1, price: 0 }]);
    setPaid(0);
    setPurchasePayMethod("Cash");
    setPurchasePayReference("");
  };

  const del = async (id) => {
    await persist({ ...data, purchases: data.purchases.filter((p) => p.id !== id) });
    showToast("Facture d'achat supprimée.");
  };

  const [poTab, setPoTab] = useState("achats"); // 'achats' | 'commandes'
  const [showPOForm, setShowPOForm] = useState(false);
  const [editingPO, setEditingPO] = useState(null);
  const [receivingPO, setReceivingPO] = useState(null);
  const [receivePaidAmount, setReceivePaidAmount] = useState(0);
  const [poSupplierId, setPoSupplierId] = useState(data.suppliers[0]?.id || "");
  const [poItems, setPoItems] = useState([{ productId: "", qty: 1, price: 0 }]);
  const [viewingPO, setViewingPO] = useState(null);

  const addPoRow = () => setPoItems((it) => [...it, { productId: "", qty: 1, price: 0 }]);
  const updatePoRow = (idx, patch) => setPoItems((it) => it.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
  const removePoRow = (idx) => setPoItems((it) => it.filter((_, i) => i !== idx));
  const poTotal = poItems.reduce((s, r) => s + Number(r.qty || 0) * Number(r.price || 0), 0);

  const submitPO = async () => {
    const validItems = poItems.filter((r) => r.productId && Number(r.qty) > 0);
    if (validItems.length === 0) return showToast("Ajoutez au moins un produit.", "error");
    const ref = makeRef(data.settings, "purchaseOrder", data.purchaseOrderCounter);
    const supplier = data.suppliers.find((s) => s.id === poSupplierId);
    const enrichedItems = validItems.map((r) => ({ ...r, name: data.products.find((p) => p.id === r.productId)?.name, qty: Number(r.qty), price: Number(r.price) }));
    let po = {
      id: uid("po"), ref, date: new Date().toISOString(), supplierId: poSupplierId,
      supplierName: supplier?.name || "Fournisseur divers", items: enrichedItems, total: poTotal, status: "En attente",
    };
    try {
      if (window.produitsBridge) {
        const reel = await window.produitsBridge.creerBonCommandeReel(enrichedItems, poSupplierId);
        if (reel) po = { ...po, id: reel.id, ref: reel.ref };
      }
    } catch (e) {
      console.error('Creation du bon de commande (base de donnees) echouee:', e.message);
    }
    await persist({ ...data, purchaseOrders: [po, ...data.purchaseOrders], purchaseOrderCounter: data.purchaseOrderCounter + 1 });
    showToast(`Bon de Commande créé — ${po.ref}`);
    setShowPOForm(false);
    setPoItems([{ productId: "", qty: 1, price: 0 }]);
  };

  // When goods actually arrive, receiving a PO creates a real stock-entry
  // Achat from the same items — the PO itself is then marked as reçu.
  const openEditPO = (po) => {
    setEditingPO(po);
    setPoSupplierId(po.supplierId);
    setPoItems(po.items.map((it) => ({ ...it })));
  };

  const saveEditPO = async () => {
    const validItems = poItems.filter((r) => r.productId && Number(r.qty) > 0);
    if (validItems.length === 0) return showToast("Ajoutez au moins un produit.", "error");
    const supplier = data.suppliers.find((s) => s.id === poSupplierId);
    const enrichedItems = validItems.map((r) => ({ ...r, name: data.products.find((p) => p.id === r.productId)?.name, qty: Number(r.qty), price: Number(r.price) }));
    const newTotal = enrichedItems.reduce((s, r) => s + r.qty * r.price, 0);
    const purchaseOrders = data.purchaseOrders.map((x) =>
      x.id === editingPO.id ? { ...x, supplierId: poSupplierId, supplierName: supplier?.name || "Fournisseur divers", items: enrichedItems, total: newTotal } : x
    );
    await persist({ ...data, purchaseOrders });
    showToast("Bon de Commande modifié.");
    setEditingPO(null);
    setPoItems([{ productId: "", qty: 1, price: 0 }]);
  };

  // When goods actually arrive, receiving a PO creates a real stock-entry
  // Achat from the same items — the PO itself is then marked as reçu. The
  // user specifies how much was actually paid, so Payé/Manque/Reste are all
  // tracked correctly instead of silently assuming nothing was paid.
  const receivePO = async () => {
    const po = receivingPO;
    const ref = makeRef(data.settings, "purchase", data.purchaseCounter);
    let products = [...data.products];
    let stockMovements = [...data.stockMovements];
    po.items.forEach((r) => {
      products = products.map((p) => {
        if (p.id !== r.productId) return p;
        const oldStock = p.stock;
        const newStock = oldStock + Number(r.qty);
        stockMovements = [
          { id: uid("mov"), date: new Date().toISOString(), product: p.name, type: "Entrée", delta: Number(r.qty), oldStock, newStock, reason: `Réception Bon de Commande ${po.ref}` },
          ...stockMovements,
        ];
        return { ...p, stock: newStock, buyPrice: Number(r.price) || p.buyPrice };
      });
    });
    const paid = Math.min(Number(receivePaidAmount) || 0, po.total);
    const purchase = {
      id: uid("pur"), ref, date: new Date().toISOString(), supplierId: po.supplierId, supplierName: po.supplierName,
      items: po.items, total: po.total, paid, fromOrderRef: po.ref,
    };
    const suppliers = data.suppliers.map((s) => (s.id === po.supplierId ? { ...s, debt: (s.debt || 0) + (po.total - paid) } : s));
    const purchaseOrders = data.purchaseOrders.map((x) => (x.id === po.id ? { ...x, status: "Reçu" } : x));
    if (window.produitsBridge) {
      await window.produitsBridge.creerAchatReel(po.items, po.supplierId);
      await window.produitsBridge.marquerBonCommandeRecuReel(po.id);
    }
    await persist({ ...data, products, stockMovements, suppliers, purchaseOrders, purchases: [purchase, ...data.purchases], purchaseCounter: data.purchaseCounter + 1 });
    showToast(`Marchandise reçue — Achat ${ref} créé (Payé : ${fmtMoney(paid, data.settings.currency)}, Reste : ${fmtMoney(po.total - paid, data.settings.currency)}).`);
    setReceivingPO(null);
    setReceivePaidAmount(0);
  };

  const delPO = async (id) => {
    try {
      if (window.produitsBridge) await window.produitsBridge.supprimerBonCommandeReel(id);
      await persist({ ...data, purchaseOrders: data.purchaseOrders.filter((x) => x.id !== id) });
      showToast("Bon de Commande supprimé.");
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  return (
    <div>
      <PageHeader
        title={t(lang, "page_purchases_title")}
        subtitle={t(lang, "page_purchases_subtitle")}
        actions={
          poTab === "achats" ? (
            <Btn icon={Plus} onClick={() => setShowForm(true)}>Nouvel Achat (Entrée de Stock)</Btn>
          ) : (
            <Btn icon={Plus} onClick={() => setShowPOForm(true)}>Nouveau Bon de Commande</Btn>
          )
        }
      />

      <div className="flex gap-2 mb-4">
        {[["achats", "Achats (Stock Reçu)"], ["commandes", `Bons de Commande (${data.purchaseOrders.length})`]].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setPoTab(key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium ${poTab === key ? "bg-slate-900 text-white" : "bg-white border border-slate-200 text-slate-600"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {poTab === "commandes" ? (
        <Card>
          {data.purchaseOrders.length === 0 ? (
            <EmptyState text="Aucun bon de commande créé pour le moment." />
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                  <th className="px-5 py-3 font-medium">Référence</th>
                  <th className="px-5 py-3 font-medium">Date</th>
                  <th className="px-5 py-3 font-medium">Fournisseur</th>
                  <th className="px-5 py-3 font-medium">Montant</th>
                  <th className="px-5 py-3 font-medium">Statut</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.purchaseOrders.map((po) => (
                  <tr key={po.id} className="border-b border-slate-50">
                    <td className="px-5 py-3 font-semibold">{po.ref}</td>
                    <td className="px-5 py-3 text-slate-500">{fmtDate(po.date)}</td>
                    <td className="px-5 py-3">{po.supplierName}</td>
                    <td className="px-5 py-3 font-medium">{fmtMoney(po.total, data.settings.currency)}</td>
                    <td className="px-5 py-3">
                      <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${po.status === "Reçu" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>
                        {po.status}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-right">
                      <div className="flex justify-end gap-1">
                        <button onClick={() => setViewingPO(po)} className="p-1.5 text-slate-400 hover:text-blue-600" title="Voir"><Eye size={15} /></button>
                        {po.status !== "Reçu" && (
                          <>
                            <button onClick={() => openEditPO(po)} className="p-1.5 text-slate-400 hover:text-slate-700" title="Modifier"><Pencil size={15} /></button>
                            <Btn size="sm" variant="success" onClick={() => { setReceivingPO(po); setReceivePaidAmount(po.total); }}>Marchandise Reçue</Btn>
                          </>
                        )}
                        <button onClick={() => delPO(po.id)} className="p-1.5 text-red-500" title="Supprimer"><Trash2 size={15} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      ) : (
      <Card>
        {data.purchases.length === 0 ? (
          <EmptyState text="Aucune facture d'achat enregistrée." />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Référence</th>
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Fournisseur</th>
                <th className="px-5 py-3 font-medium">Articles Achetés</th>
                <th className="px-5 py-3 font-medium">Montant Total</th>
                <th className="px-5 py-3 font-medium">Payé</th>
                <th className="px-5 py-3 font-medium">Restant</th>
                <th className="px-5 py-3 font-medium">Statut</th>
                <th className="px-5 py-3 font-medium text-right">Action</th>
              </tr>
            </thead>
            <tbody>
              {data.purchases.map((p) => {
                const restant = p.total - p.paid;
                const status = restant <= 0 ? "PAYÉ" : p.paid > 0 ? "PARTIEL" : "IMPAYÉ";
                const statusColor = restant <= 0 ? "bg-emerald-100 text-emerald-700" : p.paid > 0 ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700";
                return (
                  <tr key={p.id} className="border-b border-slate-50">
                    <td className="px-5 py-3 font-semibold">{p.ref}</td>
                    <td className="px-5 py-3 text-slate-500">{fmtDate(p.date)}</td>
                    <td className="px-5 py-3">{p.supplierName}</td>
                    <td className="px-5 py-3 text-slate-500">{p.items.reduce((s, it) => s + Number(it.qty), 0)} article(s)</td>
                    <td className="px-5 py-3">{fmtMoney(p.total, data.settings.currency)}</td>
                    <td className="px-5 py-3 text-emerald-600">{fmtMoney(p.paid, data.settings.currency)}</td>
                    <td className="px-5 py-3 text-red-600">{fmtMoney(restant, data.settings.currency)}</td>
                    <td className="px-5 py-3">
                      <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${statusColor}`}>{status}</span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-1 text-slate-400">
                        <button onClick={() => setViewing(p)} className="p-1.5 hover:text-blue-600" title="Voir"><Eye size={15} /></button>
                        <button onClick={() => del(p.id)} className="p-1.5 hover:text-red-600" title="Supprimer"><Trash2 size={15} /></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </Card>
      )}

      {viewing && (
        <Modal title={`Achat ${viewing.ref}`} onClose={() => setViewing(null)}>
          <p className="text-sm text-slate-500 mb-1">Fournisseur : <span className="text-slate-800 font-medium">{viewing.supplierName}</span></p>
          <p className="text-sm text-slate-500 mb-4">Date : {fmtDate(viewing.date)}</p>
          <div className="border border-slate-100 rounded-lg divide-y divide-slate-100 mb-4">
            {viewing.items.map((it, idx) => (
              <div key={idx} className="flex justify-between px-3 py-2 text-sm">
                <span>{it.name} × {it.qty}</span>
                <span className="font-medium">{fmtMoney(it.price * it.qty, data.settings.currency)}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between text-base font-bold text-slate-900 pt-2 border-t border-slate-100">
            <span>Total</span> <span>{fmtMoney(viewing.total, data.settings.currency)}</span>
          </div>
          {viewing.paid !== undefined && (
            <div className="mt-3 bg-slate-50 rounded-lg p-3 space-y-1.5 text-sm">
              <div className="flex justify-between">
                <span className="text-slate-500">Payé</span>
                <span className="font-medium text-emerald-600">{fmtMoney(viewing.paid || 0, data.settings.currency)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Reste à Payer</span>
                <span className="font-semibold text-red-600">{fmtMoney(Math.max(viewing.total - (viewing.paid || 0), 0), data.settings.currency)}</span>
              </div>
              {viewing.payMethod && (
                <div className="flex justify-between">
                  <span className="text-slate-500">Mode de Paiement</span>
                  <span className="font-medium">{viewing.payMethod}{viewing.payReference ? ` — ${viewing.payReference}` : ""}</span>
                </div>
              )}
            </div>
          )}
        </Modal>
      )}

      {showForm && (
        <Modal title="Nouvel Achat (Entrée de Stock)" onClose={() => setShowForm(false)} wide>
          <Field label="Fournisseur">
            <select value={supplierId} onChange={(e) => setSupplierId(e.target.value)} className={inputCls}>
              <option value="">— Fournisseur divers —</option>
              {data.suppliers.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </Field>
          <div className="space-y-2 mb-3">
            {items.map((r, idx) => (
              <div key={idx} className="flex gap-2 items-center">
                <select value={r.productId} onChange={(e) => updateRow(idx, { productId: e.target.value })} className={"flex-1 min-w-0 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white transition-colors"}>
                  <option value="">Sélectionner un produit</option>
                  {data.products.map((p) => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
                <input type="number" value={r.qty} onChange={(e) => updateRow(idx, { qty: e.target.value })} className={inputClsW("w-20")} placeholder="Qté" />
                <input type="number" value={r.price} onChange={(e) => updateRow(idx, { price: e.target.value })} className={inputClsW("w-28")} placeholder="Prix achat" />
                <button onClick={() => removeRow(idx)} className="text-red-500 p-2"><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
          <Btn variant="ghost" icon={Plus} onClick={addRow}>Ajouter une ligne</Btn>
          <div className="border-t border-slate-100 mt-4 pt-4">
            <div className="flex items-center justify-between mb-3">
              <Field label="Montant payé maintenant">
                <input type="number" value={paid} onChange={(e) => setPaid(e.target.value)} className={inputClsW("w-40")} />
              </Field>
              <p className="font-bold text-lg">Total : {fmtMoney(total, data.settings.currency)}</p>
            </div>
            {Number(paid) > 0 && (
              <>
                <Field label="Mode de Paiement">
                  <div className="grid grid-cols-4 gap-2">
                    {["Cash", "Carte", "Virement", "Chèque"].map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setPurchasePayMethod(m)}
                        className={`py-1.5 rounded-lg text-xs font-medium border ${purchasePayMethod === m ? "bg-slate-900 text-white border-slate-900" : "border-slate-200 text-slate-600"}`}
                      >
                        {m}
                      </button>
                    ))}
                  </div>
                </Field>
                {(purchasePayMethod === "Chèque" || purchasePayMethod === "Virement") && (
                  <Field label={purchasePayMethod === "Chèque" ? "N° de Chèque" : "Référence / N° de Série du Virement"}>
                    <input
                      value={purchasePayReference}
                      onChange={(e) => setPurchasePayReference(e.target.value)}
                      className={inputCls}
                      placeholder={purchasePayMethod === "Chèque" ? "Ex: 1234567" : "Ex: VIR-2026-00458"}
                    />
                  </Field>
                )}
              </>
            )}
          </div>
          <Btn onClick={submit}>Enregistrer l'achat</Btn>
        </Modal>
      )}

      {showPOForm && (
        <Modal title="Nouveau Bon de Commande" onClose={() => setShowPOForm(false)} wide>
          <Field label="Fournisseur">
            <select value={poSupplierId} onChange={(e) => setPoSupplierId(e.target.value)} className={inputCls}>
              <option value="">— Fournisseur divers —</option>
              {data.suppliers.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </Field>
          <div className="space-y-2 mb-3">
            {poItems.map((r, idx) => (
              <div key={idx} className="flex gap-2 items-center">
                <select
                  value={r.productId}
                  onChange={(e) => {
                    const prod = data.products.find((p) => p.id === e.target.value);
                    updatePoRow(idx, { productId: e.target.value, price: prod ? prod.buyPrice : r.price });
                  }}
                  className={"flex-1 min-w-0 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white transition-colors"}
                >
                  <option value="">Sélectionner un produit</option>
                  {data.products.map((p) => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
                <input type="number" value={r.qty} onChange={(e) => updatePoRow(idx, { qty: e.target.value })} className={inputClsW("w-20")} placeholder="Qté" />
                <input type="number" value={r.price} onChange={(e) => updatePoRow(idx, { price: e.target.value })} className={inputClsW("w-28")} placeholder="Prix prévu" />
                <button onClick={() => removePoRow(idx)} className="text-red-500 p-2"><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
          <Btn variant="ghost" icon={Plus} onClick={addPoRow}>Ajouter une ligne</Btn>
          <div className="border-t border-slate-100 mt-4 pt-4 flex items-center justify-between">
            <p className="text-xs text-slate-400 max-w-xs">
              Ceci envoie une commande prévisionnelle au fournisseur — le stock ne bouge pas encore. Utilisez
              "Marchandise Reçue" plus tard pour enregistrer l'entrée réelle.
            </p>
            <p className="font-bold text-lg">Total : {fmtMoney(poTotal, data.settings.currency)}</p>
          </div>
          <Btn onClick={submitPO}>Créer le Bon de Commande</Btn>
        </Modal>
      )}

      {viewingPO && (
        <Modal title={`Bon de Commande ${viewingPO.ref}`} onClose={() => setViewingPO(null)}>
          <p className="text-sm text-slate-500 mb-1">Fournisseur : <span className="text-slate-800 font-medium">{viewingPO.supplierName}</span></p>
          <p className="text-sm text-slate-500 mb-4">Date : {fmtDate(viewingPO.date)} — Statut : <span className="font-medium">{viewingPO.status}</span></p>
          <div className="border border-slate-100 rounded-lg divide-y divide-slate-100 mb-4">
            {viewingPO.items.map((it, idx) => (
              <div key={idx} className="flex justify-between px-3 py-2 text-sm">
                <span>{it.name} × {it.qty}</span>
                <span className="font-medium">{fmtMoney(it.price * it.qty, data.settings.currency)}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-between text-base font-bold text-slate-900 pt-2 border-t border-slate-100">
            <span>Total</span> <span>{fmtMoney(viewingPO.total, data.settings.currency)}</span>
          </div>
          {viewingPO.status !== "Reçu" && (
            <div className="mt-4">
              <Btn variant="success" onClick={() => { setReceivingPO(viewingPO); setReceivePaidAmount(viewingPO.total); setViewingPO(null); }}>Marchandise Reçue</Btn>
            </div>
          )}
        </Modal>
      )}

      {editingPO && (
        <Modal title={`Modifier le Bon de Commande ${editingPO.ref}`} onClose={() => setEditingPO(null)} wide>
          <Field label="Fournisseur">
            <select value={poSupplierId} onChange={(e) => setPoSupplierId(e.target.value)} className={inputCls}>
              <option value="">— Fournisseur divers —</option>
              {data.suppliers.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </Field>
          <div className="space-y-2 mb-3">
            {poItems.map((r, idx) => (
              <div key={idx} className="flex gap-2 items-center">
                <select
                  value={r.productId}
                  onChange={(e) => {
                    const prod = data.products.find((p) => p.id === e.target.value);
                    updatePoRow(idx, { productId: e.target.value, price: prod ? prod.buyPrice : r.price });
                  }}
                  className="flex-1 min-w-0 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500 focus:bg-white transition-colors"
                >
                  <option value="">Sélectionner un produit</option>
                  {data.products.map((p) => (
                    <option key={p.id} value={p.id}>{p.name}</option>
                  ))}
                </select>
                <input type="number" value={r.qty} onChange={(e) => updatePoRow(idx, { qty: e.target.value })} className={inputClsW("w-20")} placeholder="Qté" />
                <input type="number" value={r.price} onChange={(e) => updatePoRow(idx, { price: e.target.value })} className={inputClsW("w-28")} placeholder="Prix prévu" />
                <button onClick={() => removePoRow(idx)} className="text-red-500 p-2"><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
          <Btn variant="ghost" icon={Plus} onClick={addPoRow}>Ajouter une ligne</Btn>
          <div className="border-t border-slate-100 mt-4 pt-4 flex items-center justify-between">
            <p className="text-xs text-slate-400 max-w-xs">
              Utile si le fournisseur a changé les quantités, les prix, ou les articles avant la livraison réelle.
            </p>
            <p className="font-bold text-lg">
              Total : {fmtMoney(poItems.reduce((s, r) => s + Number(r.qty || 0) * Number(r.price || 0), 0), data.settings.currency)}
            </p>
          </div>
          <Btn onClick={saveEditPO}>Enregistrer les Modifications</Btn>
        </Modal>
      )}

      {receivingPO && (
        <Modal title={`Réception — ${receivingPO.ref}`} onClose={() => setReceivingPO(null)}>
          <p className="text-sm text-slate-500 mb-4">
            Confirmez le montant réellement payé au fournisseur <span className="font-medium text-slate-700">{receivingPO.supplierName}</span> à la
            réception de cette marchandise.
          </p>
          <div className="bg-slate-50 rounded-lg p-3 mb-4 space-y-1.5">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Total de la Commande</span>
              <span className="font-medium">{fmtMoney(receivingPO.total, data.settings.currency)}</span>
            </div>
          </div>
          <Field label="Montant Payé Maintenant">
            <input type="number" value={receivePaidAmount} onChange={(e) => setReceivePaidAmount(e.target.value)} className={inputCls} />
          </Field>
          <div className="bg-slate-50 rounded-lg p-3 mb-4 space-y-1.5">
            <div className="flex justify-between text-sm">
              <span className="text-slate-500">Payé</span>
              <span className="font-medium text-emerald-600">{fmtMoney(Math.min(Number(receivePaidAmount) || 0, receivingPO.total), data.settings.currency)}</span>
            </div>
            <div className="flex justify-between text-sm border-t border-slate-200 pt-1.5">
              <span className="text-slate-600 font-medium">Reste (Manque)</span>
              <span className="font-semibold text-red-600">
                {fmtMoney(Math.max(receivingPO.total - (Number(receivePaidAmount) || 0), 0), data.settings.currency)}
              </span>
            </div>
          </div>
          <div className="flex gap-2 mb-4">
            <Btn variant="outline" size="sm" onClick={() => setReceivePaidAmount(0)}>Rien Payé (Tout à Crédit)</Btn>
            <Btn variant="outline" size="sm" onClick={() => setReceivePaidAmount(receivingPO.total)}>Payé en Totalité</Btn>
          </div>
          <Btn icon={Check} onClick={receivePO}>Confirmer la Réception</Btn>
        </Modal>
      )}
    </div>
  );
}

// ---------- Crédits Clients ----------
function ClientCredits({ data, persist, showToast, session }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ clientId: data.clients[0]?.id || "", type: "Ajout", amount: 0, reason: "" });
  const [q, setQ] = useState("");
  const actor = session?.name || "Administrateur";

  const totalCredit = data.clients.reduce((s, c) => s + (c.credit || 0), 0);
  const clientsFiltered = data.clients.filter((c) => String(c.name || "").toLowerCase().includes(q.toLowerCase()));

  const openNew = (clientId) => {
    setForm({ clientId: clientId || data.clients[0]?.id || "", type: "Ajout", amount: 0, reason: "" });
    setShowForm(true);
  };

  const save = async () => {
    const client = data.clients.find((c) => c.id === form.clientId);
    if (!client) return showToast("Sélectionnez un client.", "error");
    const amount = Number(form.amount);
    if (!amount || amount <= 0) return showToast("Le montant doit être supérieur à 0.", "error");

    const delta = form.type === "Ajout" ? amount : -amount;
    const newCredit = Math.max((client.credit || 0) + delta, 0);

    const movement = {
      id: uid("cm"),
      date: new Date().toISOString(),
      clientId: client.id,
      clientName: client.name,
      type: form.type,
      amount,
      reason: form.reason || (form.type === "Ajout" ? "Crédit accordé" : "Remboursement reçu"),
      actor,
    };

    const clients = data.clients.map((c) => (c.id === client.id ? { ...c, credit: newCredit } : c));
    const securityLog = logEvent(
      data,
      actor,
      form.type === "Ajout" ? "CRÉDIT CLIENT AJOUTÉ" : "REMBOURSEMENT CLIENT ENREGISTRÉ",
      `${fmtMoney(amount, data.settings.currency)} pour ${client.name}.`
    );
    await persist({ ...data, clients, creditMovements: [movement, ...data.creditMovements], securityLog });
    showToast(form.type === "Ajout" ? "Crédit ajouté au client." : "Remboursement enregistré.");
    setShowForm(false);
  };

  const delMovement = async (m) => {
    // Reverse the movement's effect on the client's balance, then remove it from history.
    const client = data.clients.find((c) => c.id === m.clientId);
    if (client) {
      const reversedDelta = m.type === "Ajout" ? -m.amount : m.amount;
      const clients = data.clients.map((c) => (c.id === m.clientId ? { ...c, credit: Math.max((c.credit || 0) + reversedDelta, 0) } : c));
      await persist({ ...data, clients, creditMovements: data.creditMovements.filter((x) => x.id !== m.id) });
    } else {
      await persist({ ...data, creditMovements: data.creditMovements.filter((x) => x.id !== m.id) });
    }
    showToast("Mouvement supprimé et solde ajusté.");
  };

  const exportHistory = async () => {
    const rows = [
      ["Date", "Client", "Type", "Montant", "Raison", "Enregistré par"],
      ...data.creditMovements.map((m) => [fmtDate(m.date), m.clientName, m.type, m.amount, m.reason, m.actor]),
    ];
    await saveXlsxFile(rows, "Crédits Clients", `credits-clients-${todayISO()}.xlsx`);
  };

  return (
    <div>
      <PageHeader
        title="Crédits Clients"
        subtitle="Notez directement un crédit accordé à un client, ou enregistrez un remboursement — sans passer par une vente."
        actions={<Btn icon={Plus} onClick={() => openNew()}>Nouveau Mouvement de Crédit</Btn>}
      />

      <Card className="p-5 mb-5">
        <p className="text-xs text-slate-500">Crédit Total Accordé (tous clients)</p>
        <p className="text-2xl font-bold text-amber-600">{fmtMoney(totalCredit, data.settings.currency)}</p>
      </Card>

      <Card className="mb-5">
        <div className="p-4 border-b border-slate-100">
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 max-w-md">
            <Search size={16} className="text-slate-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher un client..." className="flex-1 outline-none text-sm bg-transparent" />
          </div>
        </div>
        {clientsFiltered.length === 0 ? (
          <EmptyState text="Aucun client trouvé." />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Client</th>
                <th className="px-5 py-3 font-medium">Solde Actuel</th>
                <th className="px-5 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {clientsFiltered.map((c) => (
                <tr key={c.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 font-medium">{c.name}</td>
                  <td className={`px-5 py-3 font-semibold ${c.credit > 0 ? "text-amber-600" : "text-emerald-600"}`}>
                    {fmtMoney(c.credit || 0, data.settings.currency)}
                  </td>
                  <td className="px-5 py-3 text-right">
                    <Btn size="sm" variant="outline" icon={Plus} onClick={() => openNew(c.id)}>Mouvement</Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>

      <Card>
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <p className="font-semibold text-slate-800">Historique des Mouvements</p>
          {data.creditMovements.length > 0 && <Btn size="sm" variant="outline" icon={Download} onClick={exportHistory}>Exporter (.xlsx)</Btn>}
        </div>
        {data.creditMovements.length === 0 ? (
          <EmptyState text="Aucun mouvement de crédit enregistré pour le moment." />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Client</th>
                <th className="px-5 py-3 font-medium">Type</th>
                <th className="px-5 py-3 font-medium">Montant</th>
                <th className="px-5 py-3 font-medium">Raison</th>
                <th className="px-5 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.creditMovements.map((m) => (
                <tr key={m.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 text-slate-500">{fmtDate(m.date)}</td>
                  <td className="px-5 py-3 font-medium">{m.clientName}</td>
                  <td className="px-5 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${m.type === "Ajout" ? "bg-amber-100 text-amber-700" : "bg-emerald-100 text-emerald-700"}`}>
                      {m.type === "Ajout" ? "Crédit Accordé" : "Remboursement"}
                    </span>
                  </td>
                  <td className="px-5 py-3 font-semibold">{fmtMoney(m.amount, data.settings.currency)}</td>
                  <td className="px-5 py-3 text-slate-500">{m.reason}</td>
                  <td className="px-5 py-3 text-right">
                    <button onClick={() => delMovement(m)} className="text-red-500 p-1.5"><Trash2 size={15} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>

      {showForm && (
        <Modal title="Nouveau Mouvement de Crédit" onClose={() => setShowForm(false)}>
          <Field label="Client *">
            <select value={form.clientId} onChange={(e) => setForm({ ...form, clientId: e.target.value })} className={inputCls}>
              {data.clients.map((c) => (
                <option key={c.id} value={c.id}>{c.name} (solde actuel: {fmtMoney(c.credit || 0, data.settings.currency)})</option>
              ))}
            </select>
          </Field>
          <Field label="Type de Mouvement">
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setForm({ ...form, type: "Ajout" })}
                className={`py-2 rounded-lg text-sm font-medium border ${form.type === "Ajout" ? "bg-amber-600 text-white border-amber-600" : "border-slate-200 text-slate-600"}`}
              >
                Ajouter du Crédit
              </button>
              <button
                type="button"
                onClick={() => setForm({ ...form, type: "Remboursement" })}
                className={`py-2 rounded-lg text-sm font-medium border ${form.type === "Remboursement" ? "bg-emerald-600 text-white border-emerald-600" : "border-slate-200 text-slate-600"}`}
              >
                Enregistrer un Remboursement
              </button>
            </div>
          </Field>
          <Field label="Montant"><input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} className={inputCls} /></Field>
          <Field label="Raison / Note (optionnel)">
            <input value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} className={inputCls} placeholder="Ex: Avance pour commande, remboursement partiel..." />
          </Field>
          <Btn onClick={save}>Enregistrer le Mouvement</Btn>
        </Modal>
      )}
    </div>
  );
}

// ---------- Calcul de la Zakat ----------
function Zakat({ data, persist, showToast }) {
  const lang = data.settings.language || "fr";
  const [nisabInput, setNisabInput] = useState(data.settings.zakatNisab || 0);
  const [rateInput, setRateInput] = useState(data.settings.zakatRate ?? 2.5);

  // All figures below are pulled live from data already tracked elsewhere in
  // the app — nothing here is a separate/duplicate data entry.
  const stockValue = data.products.reduce((s, p) => s + p.stock * p.sellPrice, 0);
  const cashValue = data.cashRegister.solde || 0;
  const clientReceivables = data.clients.reduce((s, c) => s + (c.credit || 0), 0);
  const supplierDebts = data.suppliers.reduce((s, f) => s + (f.debt || 0), 0);
  const zakatableBase = stockValue + cashValue + clientReceivables - supplierDebts;

  const nisab = Number(data.settings.zakatNisab) || 0;
  const rate = Number(data.settings.zakatRate) || 0;
  const aboveNisab = nisab > 0 && zakatableBase >= nisab;
  const zakatDue = aboveNisab ? zakatableBase * (rate / 100) : 0;

  const saveSettings = async () => {
    await persist({ ...data, settings: { ...data.settings, zakatNisab: Number(nisabInput) || 0, zakatRate: Number(rateInput) || 0 } });
    showToast("Paramètres de la Zakat enregistrés.");
  };

  const saveToHistory = async () => {
    const entryLocal = {
      stockValue, cashValue, clientReceivables, supplierDebts, zakatableBase, nisab, rate, zakatDue,
    };
    try {
      const entry = window.fiscalBridge
        ? await window.fiscalBridge.creerZakatReel(entryLocal)
        : { id: uid("zk"), date: new Date().toISOString(), ...entryLocal };
      await persist({ ...data, zakatHistory: [entry, ...data.zakatHistory] });
      showToast("Calcul enregistré dans l'historique.");
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  const delHistory = async (id) => {
    try {
      if (window.fiscalBridge) await window.fiscalBridge.supprimerZakatReel(id);
      await persist({ ...data, zakatHistory: data.zakatHistory.filter((h) => h.id !== id) });
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  const exportHistory = async () => {
    const rows = [
      ["Date", "Valeur Stock", "Caisse", "Créances Clients", "Dettes Fournisseurs", "Base Zakatable", "Nisab", "Taux %", "Zakat Due"],
      ...data.zakatHistory.map((h) => [fmtDate(h.date), h.stockValue, h.cashValue, h.clientReceivables, h.supplierDebts, h.zakatableBase, h.nisab, h.rate, h.zakatDue]),
    ];
    await saveXlsxFile(rows, "Zakat", `historique-zakat-${todayISO()}.xlsx`);
  };

  const Row = ({ label, value, positive = true, bold = false }) => (
    <div className={`flex justify-between py-2 ${bold ? "border-t border-slate-200 mt-1 pt-3" : ""}`}>
      <span className={`text-sm ${bold ? "font-semibold text-slate-800" : "text-slate-500"}`}>{label}</span>
      <span className={`text-sm ${bold ? "font-bold text-slate-900" : positive ? "text-slate-700" : "text-red-600"}`}>
        {positive ? "" : "− "}{fmtMoney(value, data.settings.currency)}
      </span>
    </div>
  );

  return (
    <div>
      <PageHeader
        title="Calcul de la Zakat (زكاة التجارة)"
        subtitle="Estimation automatique de la Zakat sur le commerce, basée sur les données déjà enregistrées dans votre système."
      />

      <Card className="p-5 mb-5 border-amber-200 bg-amber-50">
        <p className="text-sm text-amber-800">
          Cet outil calcule une <strong>estimation</strong> selon la méthode la plus communément admise pour la Zakat sur le commerce
          (زكاة التجارة) : valeur du stock + liquidités + créances récupérables − dettes envers les fournisseurs, puis 2.5% si le
          total dépasse le Nisab. Les avis divergent selon les écoles et les savants sur certains détails (valorisation du stock,
          créances douteuses, etc.) — <strong>consultez un imam ou un savant qualifié</strong> pour confirmer votre cas précis.
        </p>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="p-5 lg:col-span-2">
          <p className="font-semibold text-slate-800 mb-3">Détail du Calcul</p>
          <Row label="Valeur du Stock (prix de vente)" value={stockValue} />
          <Row label="Solde de Caisse" value={cashValue} />
          <Row label="Créances Clients (à récupérer)" value={clientReceivables} />
          <Row label="Dettes Fournisseurs (à payer)" value={supplierDebts} positive={false} />
          <Row label="Base Zakatable" value={zakatableBase} bold />

          <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-2 gap-4">
            <Field label="Seuil du Nisab (DH)">
              <input type="number" value={nisabInput} onChange={(e) => setNisabInput(e.target.value)} className={inputCls} placeholder="Ex: 25000" />
            </Field>
            <Field label="Taux de Zakat (%)">
              <input type="number" step="0.1" value={rateInput} onChange={(e) => setRateInput(e.target.value)} className={inputCls} />
            </Field>
          </div>
          <Btn icon={Check} onClick={saveSettings}>Enregistrer ces Paramètres</Btn>
        </Card>

        <div>
          <Card className={`p-5 ${aboveNisab ? "border-emerald-300 bg-emerald-50" : "border-slate-200"}`}>
            <p className="text-xs text-slate-500 mb-1">Résultat</p>
            {nisab <= 0 ? (
              <p className="text-sm text-amber-700">Renseignez le seuil du Nisab pour voir le résultat.</p>
            ) : aboveNisab ? (
              <>
                <p className="text-xs text-emerald-700 mb-1">Base au-dessus du Nisab — Zakat due :</p>
                <p className="text-2xl font-bold text-emerald-700">{fmtMoney(zakatDue, data.settings.currency)}</p>
                <p className="text-[11px] text-slate-500 mt-2">({rate}% de {fmtMoney(zakatableBase, data.settings.currency)})</p>
              </>
            ) : (
              <>
                <p className="text-sm text-slate-600">Base en dessous du Nisab.</p>
                <p className="text-lg font-bold text-slate-400 mt-1">Aucune Zakat due</p>
              </>
            )}
          </Card>
          <div className="mt-4">
            <Btn variant="success" icon={HandCoins} onClick={saveToHistory}>Enregistrer ce Calcul</Btn>
          </div>
        </div>
      </div>

      <Card className="mt-5">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <p className="font-semibold text-slate-800">Historique des Calculs</p>
          {data.zakatHistory.length > 0 && <Btn size="sm" variant="outline" icon={Download} onClick={exportHistory}>Exporter (.xlsx)</Btn>}
        </div>
        {data.zakatHistory.length === 0 ? (
          <EmptyState text="Aucun calcul enregistré pour le moment." />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Base Zakatable</th>
                <th className="px-5 py-3 font-medium">Nisab</th>
                <th className="px-5 py-3 font-medium">Taux</th>
                <th className="px-5 py-3 font-medium">Zakat Due</th>
                <th className="px-5 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.zakatHistory.map((h) => (
                <tr key={h.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 text-slate-500">{fmtDate(h.date)}</td>
                  <td className="px-5 py-3 font-medium">{fmtMoney(h.zakatableBase, data.settings.currency)}</td>
                  <td className="px-5 py-3 text-slate-500">{fmtMoney(h.nisab, data.settings.currency)}</td>
                  <td className="px-5 py-3 text-slate-500">{h.rate}%</td>
                  <td className="px-5 py-3 font-semibold text-emerald-700">{fmtMoney(h.zakatDue, data.settings.currency)}</td>
                  <td className="px-5 py-3 text-right">
                    <button onClick={() => delHistory(h.id)} className="text-red-500 p-1.5"><Trash2 size={15} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}

// ---------- Suppliers ----------
function Suppliers({ data, persist, showToast }) {
  const lang = data.settings.language || "fr";
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", phone: "", email: "", address: "" });
  const [statementSupplier, setStatementSupplier] = useState(null);

  const openNew = () => {
    setEditing(null);
    setForm({ name: "", phone: "", email: "", address: "" });
    setShowForm(true);
  };
  const openEdit = (s) => {
    setEditing(s);
    setForm(s);
    setShowForm(true);
  };

  const save = async () => {
    if (!form.name) return showToast("Le nom est requis.", "error");
    try {
      if (editing) {
        const fournisseurReel = window.produitsBridge
          ? await window.produitsBridge.modifierFournisseurReel(editing.id, form)
          : { ...editing, ...form };
        await persist({ ...data, suppliers: data.suppliers.map((s) => (s.id === editing.id ? fournisseurReel : s)) });
        showToast("Fournisseur modifié.");
      } else {
        const fournisseurReel = window.produitsBridge
          ? await window.produitsBridge.creerFournisseurReel(form)
          : { id: uid("sup"), debt: 0, ...form };
        await persist({ ...data, suppliers: [...data.suppliers, fournisseurReel] });
        showToast("Fournisseur ajouté.");
      }
      setShowForm(false);
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  const del = async (id) => {
    try {
      if (window.produitsBridge) await window.produitsBridge.supprimerFournisseurReel(id);
      await persist({ ...data, suppliers: data.suppliers.filter((s) => s.id !== id) });
      showToast("Fournisseur supprimé.");
    } catch (e) {
      showToast("Erreur lors de la suppression : " + e.message, "error");
    }
  };

  return (
    <div>
      <PageHeader title={t(lang, "page_suppliers_title")} subtitle={t(lang, "page_suppliers_subtitle")} actions={<Btn icon={Plus} onClick={openNew}>Nouveau Fournisseur</Btn>} />
      <Card>
        {data.suppliers.length === 0 ? (
          <EmptyState text="Aucun fournisseur enregistré." />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Nom</th>
                <th className="px-5 py-3 font-medium">Téléphone</th>
                <th className="px-5 py-3 font-medium">Email</th>
                <th className="px-5 py-3 font-medium">Dette</th>
                <th className="px-5 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.suppliers.map((s) => (
                <tr key={s.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 font-medium">{s.name}</td>
                  <td className="px-5 py-3 text-slate-500">{s.phone}</td>
                  <td className="px-5 py-3 text-slate-500">{s.email}</td>
                  <td className="px-5 py-3 text-red-600 font-medium">{fmtMoney(s.debt || 0, data.settings.currency)}</td>
                  <td className="px-5 py-3">
                    <div className="flex justify-end gap-1">
                      <Btn size="sm" variant="outline" icon={ReceiptText} onClick={() => setStatementSupplier(s)}>Relevé</Btn>
                      <Btn size="sm" variant="outline" icon={Pencil} onClick={() => openEdit(s)}>Modifier</Btn>
                      <Btn size="sm" variant="danger" icon={Trash2} onClick={() => del(s.id)}>Suppr.</Btn>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>

      {showForm && (
        <Modal title={editing ? "Modifier le Fournisseur" : "Nouveau Fournisseur"} onClose={() => setShowForm(false)}>
          <Field label="Nom *"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} /></Field>
          <Field label="Téléphone"><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={inputCls} /></Field>
          <Field label="Email"><input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputCls} /></Field>
          <Field label="Adresse"><input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className={inputCls} /></Field>
          <Btn onClick={save}>{editing ? "Enregistrer" : "Ajouter"}</Btn>
        </Modal>
      )}

      {statementSupplier && (
        <Modal title={`Relevé de Compte — ${statementSupplier.name}`} onClose={() => setStatementSupplier(null)} wide>
          {(() => {
            const supplierPurchases = data.purchases
              .filter((p) => p.supplierId === statementSupplier.id)
              .sort((a, b) => new Date(a.date) - new Date(b.date));
            let running = 0;
            const rows = supplierPurchases.map((p) => {
              running += p.total - p.paid;
              return { ...p, running };
            });
            return (
              <>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-slate-500">Dette actuelle</p>
                    <p className="text-xl font-bold text-red-600">{fmtMoney(statementSupplier.debt || 0, data.settings.currency)}</p>
                  </div>
                </div>
                {rows.length === 0 ? (
                  <EmptyState text="Aucun achat enregistré pour ce fournisseur." />
                ) : (
                  <div className="border border-slate-100 rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100 bg-slate-50">
                          <th className="px-4 py-2.5 font-medium">Référence</th>
                          <th className="px-4 py-2.5 font-medium">Date</th>
                          <th className="px-4 py-2.5 font-medium">Total</th>
                          <th className="px-4 py-2.5 font-medium">Payé</th>
                          <th className="px-4 py-2.5 font-medium">Solde Cumulé</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rows.map((r) => (
                          <tr key={r.id} className="border-b border-slate-50">
                            <td className="px-4 py-2.5 font-medium">{r.ref}</td>
                            <td className="px-4 py-2.5 text-slate-500">{fmtDate(r.date)}</td>
                            <td className="px-4 py-2.5">{fmtMoney(r.total, data.settings.currency)}</td>
                            <td className="px-4 py-2.5 text-emerald-600">{fmtMoney(r.paid, data.settings.currency)}</td>
                            <td className="px-4 py-2.5 font-semibold text-red-600">{fmtMoney(r.running, data.settings.currency)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            );
          })()}
        </Modal>
      )}
    </div>
  );
}

// ---------- Products ----------
function Products({ data, persist, showToast }) {
  const lang = data.settings.language || "fr";
  const [tab, setTab] = useState("list");
  const [q, setQ] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const categories = data.categories || CATEGORIES_DEFAULT;
  const brands = data.brands || BRANDS_DEFAULT;
  const [form, setForm] = useState({ name: "", brand: brands[0] || "", category: categories[0] || "", barcode: "", buyPrice: 0, sellPrice: 0, stock: 0, location: "", expiryDate: "", alertThreshold: 5, image: null });
  const fileInputRef = useRef(null);
  const productImageInputRef = useRef(null);

  const [newCat, setNewCat] = useState("");
  const [newBrand, setNewBrand] = useState("");
  const [catFilter, setCatFilter] = useState("Toutes les Catégories");
  const [stockFilter, setStockFilter] = useState("Tous les Stocks");

  const list = data.products.filter((p) => {
    const matchesQ = String(p.name || "").toLowerCase().includes(q.toLowerCase()) || String(p.barcode || "").includes(q);
    const matchesCat = catFilter === "Toutes les Catégories" || p.category === catFilter;
    const matchesStock =
      stockFilter === "Tous les Stocks" ||
      (stockFilter === "Stock Faible" && p.stock <= (p.alertThreshold ?? 5) && p.stock > 0) ||
      (stockFilter === "Rupture" && p.stock <= 0) ||
      (stockFilter === "En Stock" && p.stock > 5);
    return matchesQ && matchesCat && matchesStock;
  });

  const openNew = () => {
    setEditing(null);
    setForm({ name: "", brand: brands[0] || "", category: categories[0] || "", barcode: "", buyPrice: 0, sellPrice: 0, stock: 0, location: "", expiryDate: "", alertThreshold: 5, image: null });
    setShowForm(true);
  };
  const openEdit = (p) => {
    setEditing(p);
    setForm(p);
    setShowForm(true);
  };

  const save = async () => {
    if (!form.name) return showToast("Le nom du produit est requis.", "error");
    const clean = { ...form, buyPrice: Number(form.buyPrice), sellPrice: Number(form.sellPrice), stock: Number(form.stock) };
    try {
      if (editing) {
        const produitReel = window.produitsBridge
          ? await window.produitsBridge.modifierProduitReel(editing.id, clean)
          : { ...editing, ...clean };
        await persist({ ...data, products: data.products.map((p) => (p.id === editing.id ? produitReel : p)) });
        showToast("Produit modifié.");
      } else {
        const produitReel = window.produitsBridge
          ? await window.produitsBridge.creerProduitReel(clean)
          : { id: uid("prod"), ...clean };
        await persist({ ...data, products: [...data.products, produitReel] });
        showToast("Produit ajouté.");
      }
      setShowForm(false);
    } catch (e) {
      showToast("Erreur lors de l'enregistrement du produit : " + e.message, "error");
    }
  };

  const del = async (id) => {
    try {
      if (window.produitsBridge) await window.produitsBridge.supprimerProduitReel(id);
      await persist({ ...data, products: data.products.filter((p) => p.id !== id) });
      showToast("Produit supprimé.");
    } catch (e) {
      showToast("Erreur lors de la suppression : " + e.message, "error");
    }
  };

  const addCategory = async () => {
    if (!newCat.trim()) return;
    if (categories.includes(newCat.trim())) return showToast("Cette catégorie existe déjà.", "error");
    await persist({ ...data, categories: [...categories, newCat.trim()] });
    setNewCat("");
    showToast("Catégorie ajoutée.");
  };
  const delCategory = async (c) => {
    await persist({ ...data, categories: categories.filter((x) => x !== c) });
  };
  const addBrand = async () => {
    if (!newBrand.trim()) return;
    if (brands.includes(newBrand.trim())) return showToast("Cette marque existe déjà.", "error");
    await persist({ ...data, brands: [...brands, newBrand.trim()] });
    setNewBrand("");
    showToast("Marque ajoutée.");
  };
  const delBrand = async (b) => {
    await persist({ ...data, brands: brands.filter((x) => x !== b) });
  };

  const exportExcelFile = async () => {
    const header = ["Nom", "Marque", "Categorie", "CodeBarres", "PrixAchat", "PrixVente", "Stock", "Rayon", "DateExpiration", "SeuilAlerte"];
    const rows = data.products.map((p) => [p.name, p.brand, p.category, p.barcode, p.buyPrice, p.sellPrice, p.stock, p.location || "", p.expiryDate || "", p.alertThreshold ?? 5]);
    const ok = await saveXlsxFile([header, ...rows], "Produits", `catalogue-produits-${todayISO()}.xlsx`);
    if (ok) showToast("Export Excel (.xlsx) généré.");
  };

  const triggerImport = () => fileInputRef.current?.click();

  const handleImportFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const isXlsx = /\.xlsx$/i.test(file.name);
      let rows;
      if (isXlsx) {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: "" });
      } else {
        const text = await file.text();
        const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
        const parseLine = (line) =>
          line
            .match(/(".*?"|[^,]+)(?=,|$)/g)
            ?.map((v) => v.replace(/^"|"$/g, "").replace(/""/g, '"').trim()) || [];
        rows = lines.map(parseLine);
      }
      if (rows.length < 2) return showToast("Fichier vide ou invalide.", "error");
      const aImporter = rows
        .slice(1)
        .filter((r) => r[0])
        .map((r) => ({
          name: String(r[0] || "Produit"),
          brand: r[1] || "",
          category: r[2] || categories[0] || "Autre",
          barcode: String(r[3] || ""),
          buyPrice: Number(r[4]) || 0,
          sellPrice: Number(r[5]) || 0,
          stock: Number(r[6]) || 0,
          location: r[7] || "",
          expiryDate: r[8] || "",
          alertThreshold: Number(r[9]) || 5,
        }));

      const imported = [];
      const echecs = [];
      for (const champs of aImporter) {
        try {
          const produitReel = window.produitsBridge
            ? await window.produitsBridge.creerProduitReel(champs)
            : { id: uid("prod"), ...champs };
          imported.push(produitReel);
        } catch (e) {
          echecs.push(champs.name);
        }
      }
      await persist({ ...data, products: [...data.products, ...imported] });
      showToast(
        `${imported.length} produit(s) importé(s).` +
          (echecs.length ? ` ${echecs.length} échec(s) : ${echecs.join(", ")}` : ""),
        echecs.length ? "error" : "success",
      );
    } catch (err) {
      console.error(err);
      showToast("Fichier invalide ou format non reconnu.", "error");
    }
    e.target.value = "";
  };

  return (
    <div>
      <PageHeader
        title={t(lang, "page_products_title")}
        subtitle={t(lang, "page_products_subtitle")}
        actions={
          <>
            <Btn icon={Plus} onClick={openNew}>Nouveau Produit</Btn>
            <Btn variant="outline" icon={Download} onClick={exportExcelFile}>Exporter Excel (.xlsx)</Btn>
            <Btn variant="outline" icon={PackagePlus} onClick={triggerImport}>Importer Excel (.xlsx/.csv)</Btn>
            <input ref={fileInputRef} type="file" accept=".xlsx,.csv" className="hidden" onChange={handleImportFile} />
          </>
        }
      />
      <div className="flex gap-1 mb-4 border-b border-slate-200">
        {[["list", `Liste des Produits (${data.products.length})`], ["catbrand", "Catégories & Marques"]].map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)} className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px ${tab === key ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500"}`}>
            {label}
          </button>
        ))}
      </div>

      {tab === "list" ? (
        <Card>
          <div className="p-4 border-b border-slate-100 flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 max-w-md flex-1">
              <Search size={16} className="text-slate-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher par nom, code-barres..." className="flex-1 outline-none text-sm bg-transparent" />
            </div>
            <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className={inputClsW("w-auto")}>
              <option>Toutes les Catégories</option>
              {categories.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={stockFilter} onChange={(e) => setStockFilter(e.target.value)} className={inputClsW("w-auto")}>
              <option>Tous les Stocks</option>
              <option>En Stock</option>
              <option>Stock Faible</option>
              <option>Rupture</option>
            </select>
          </div>
          {list.length === 0 ? (
            <EmptyState text="Aucun produit trouvé." />
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                  <th className="px-5 py-3 font-medium">Visuel / Code</th>
                  <th className="px-5 py-3 font-medium">Nom du Produit</th>
                  <th className="px-5 py-3 font-medium">Catégorie</th>
                  <th className="px-5 py-3 font-medium">Prix Achat</th>
                  <th className="px-5 py-3 font-medium">Prix Vente</th>
                  <th className="px-5 py-3 font-medium">Marge / TVA</th>
                  <th className="px-5 py-3 font-medium">Stock</th>
                  <th className="px-5 py-3 font-medium">Détails</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {list.map((p) => {
                  const marge = p.sellPrice - p.buyPrice;
                  const threshold = p.alertThreshold ?? 5;
                  const isLow = p.stock <= threshold;
                  const isExpiringSoon = p.expiryDate && new Date(p.expiryDate) - new Date() < 30 * 86400000;
                  const isExpired = p.expiryDate && new Date(p.expiryDate) < new Date();
                  return (
                    <tr key={p.id} className="border-b border-slate-50">
                      <td className="px-5 py-3">
                        <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-slate-300 mb-1 overflow-hidden">
                          {p.image ? <img src={p.image} alt={p.name} className="w-full h-full object-cover" /> : <Package size={18} />}
                        </div>
                        <p className="text-[10px] text-slate-400">QR: {p.barcode || "—"}</p>
                      </td>
                      <td className="px-5 py-3">
                        <p className="font-medium text-slate-800">{p.name}</p>
                        <p className="text-xs text-slate-400">Marque : {p.brand || "—"}</p>
                      </td>
                      <td className="px-5 py-3 text-slate-500">{p.category}</td>
                      <td className="px-5 py-3">{fmtMoney(p.buyPrice, data.settings.currency)}</td>
                      <td className="px-5 py-3 font-medium">{fmtMoney(p.sellPrice, data.settings.currency)}</td>
                      <td className="px-5 py-3">
                        <p className={`font-medium ${marge >= 0 ? "text-emerald-600" : "text-red-600"}`}>{marge >= 0 ? "+" : ""}{fmtMoney(marge, data.settings.currency)}</p>
                        <p className="text-[10px] text-slate-400">TVA: {data.settings.tvaRate}%</p>
                      </td>
                      <td className="px-5 py-3">
                        <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${isLow ? "bg-red-100 text-red-700" : "bg-emerald-100 text-emerald-700"}`}>
                          {p.stock} u.
                        </span>
                      </td>
                      <td className="px-5 py-3 space-y-0.5">
                        <p className="text-[11px] text-slate-500 flex items-center gap-1">
                          <MapPin size={11} className="text-slate-400" /> {p.location || "Non défini"}
                        </p>
                        {p.expiryDate ? (
                          <p className={`text-[11px] flex items-center gap-1 ${isExpired ? "text-red-600" : isExpiringSoon ? "text-amber-600" : "text-slate-500"}`}>
                            <CalendarClock size={11} /> Exp: {fmtDate(p.expiryDate)}
                          </p>
                        ) : (
                          <p className="text-[11px] text-slate-400 flex items-center gap-1"><CalendarClock size={11} /> Pas de DLC</p>
                        )}
                        <p className="text-[11px] text-slate-400 flex items-center gap-1">
                          <AlertTriangle size={11} /> Seuil: {threshold} u.
                        </p>
                      </td>
                      <td className="px-5 py-3">
                        <div className="flex justify-end gap-1">
                          <Btn size="sm" variant="outline" icon={Pencil} onClick={() => openEdit(p)}>Modifier</Btn>
                          <Btn size="sm" variant="danger" icon={Trash2} onClick={() => del(p.id)}>Suppr.</Btn>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <Card className="p-5">
            <p className="font-semibold text-slate-800 mb-3">Catégories</p>
            <div className="flex gap-2 mb-4">
              <input value={newCat} onChange={(e) => setNewCat(e.target.value)} placeholder="Nouvelle catégorie" className={inputCls} onKeyDown={(e) => e.key === "Enter" && addCategory()} />
              <Btn onClick={addCategory} icon={Plus}>Ajouter</Btn>
            </div>
            <div className="space-y-2">
              {categories.map((c) => (
                <div key={c} className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2">
                  <span className="text-sm">{c}</span>
                  <button onClick={() => delCategory(c)} className="text-red-500"><Trash2 size={14} /></button>
                </div>
              ))}
            </div>
          </Card>
          <Card className="p-5">
            <p className="font-semibold text-slate-800 mb-3">Marques</p>
            <div className="flex gap-2 mb-4">
              <input value={newBrand} onChange={(e) => setNewBrand(e.target.value)} placeholder="Nouvelle marque" className={inputCls} onKeyDown={(e) => e.key === "Enter" && addBrand()} />
              <Btn onClick={addBrand} icon={Plus}>Ajouter</Btn>
            </div>
            <div className="space-y-2">
              {brands.map((b) => (
                <div key={b} className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2">
                  <span className="text-sm">{b}</span>
                  <button onClick={() => delBrand(b)} className="text-red-500"><Trash2 size={14} /></button>
                </div>
              ))}
            </div>
          </Card>
        </div>
      )}

      {showForm && (
        <Modal title={editing ? "Modifier le Produit" : "Nouveau Produit"} onClose={() => setShowForm(false)} wide>
          <Field label="Image du Produit">
            <div className="flex items-center gap-3">
              <div className="w-16 h-16 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center overflow-hidden shrink-0">
                {form.image ? <img src={form.image} alt="produit" className="w-full h-full object-cover" /> : <Package size={24} className="text-slate-300" />}
              </div>
              <Btn variant="outline" onClick={() => productImageInputRef.current?.click()}>Télécharger</Btn>
              {form.image && <Btn variant="danger" onClick={() => setForm({ ...form, image: null })}>Supprimer</Btn>}
              <input
                ref={productImageInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  if (file.size > 1024 * 1024) return showToast("Image trop lourde (max 1 Mo).", "error");
                  const reader = new FileReader();
                  reader.onload = () => setForm((f) => ({ ...f, image: reader.result }));
                  reader.readAsDataURL(file);
                }}
              />
            </div>
          </Field>
          <div className="grid grid-cols-2 gap-x-4">
            <Field label="Nom du Produit *"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} /></Field>
            <Field label="Marque">
              <Dropdown value={form.brand} onChange={(v) => setForm({ ...form, brand: v })} options={brands} />
            </Field>
            <Field label="Catégorie">
              <Dropdown value={form.category} onChange={(v) => setForm({ ...form, category: v })} options={categories} />
            </Field>
            <Field label="Code-barres"><input value={form.barcode} onChange={(e) => setForm({ ...form, barcode: e.target.value })} className={inputCls} /></Field>
            <Field label="Prix d'Achat"><input type="number" value={form.buyPrice} onChange={(e) => setForm({ ...form, buyPrice: e.target.value })} className={inputCls} /></Field>
            <Field label="Prix de Vente"><input type="number" value={form.sellPrice} onChange={(e) => setForm({ ...form, sellPrice: e.target.value })} className={inputCls} /></Field>
            <Field label="Stock Actuel"><input type="number" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} className={inputCls} /></Field>
            <Field label="Rayon / Emplacement"><input value={form.location || ""} onChange={(e) => setForm({ ...form, location: e.target.value })} className={inputCls} placeholder="Ex: Allée 3, Étagère B" /></Field>
            <Field label="Date d'Expiration"><input type="date" value={form.expiryDate || ""} onChange={(e) => setForm({ ...form, expiryDate: e.target.value })} className={inputCls} /></Field>
            <Field label="Seuil d'Alerte Stock"><input type="number" value={form.alertThreshold ?? 5} onChange={(e) => setForm({ ...form, alertThreshold: e.target.value })} className={inputCls} /></Field>
          </div>
          <Btn onClick={save}>{editing ? "Enregistrer" : "Ajouter"}</Btn>
        </Modal>
      )}
    </div>
  );
}

// ---------- Services ----------
function Services({ data, persist, showToast }) {
  const [q, setQ] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const categories = data.serviceCategories || ["Autre"];
  const [form, setForm] = useState({ name: "", category: categories[0] || "Autre", price: 0 });
  const [newCat, setNewCat] = useState("");
  const [tab, setTab] = useState("list");

  const list = data.services.filter((s) => String(s.name || "").toLowerCase().includes(q.toLowerCase()));

  const openNew = () => {
    setEditing(null);
    setForm({ name: "", category: categories[0] || "Autre", price: 0 });
    setShowForm(true);
  };
  const openEdit = (s) => {
    setEditing(s);
    setForm(s);
    setShowForm(true);
  };

  const save = async () => {
    if (!form.name) return showToast("Le nom du service est requis.", "error");
    const clean = { ...form, price: Number(form.price) };
    try {
      if (editing) {
        const serviceReel = window.produitsBridge
          ? await window.produitsBridge.modifierServiceReel(editing.id, clean)
          : { ...editing, ...clean };
        await persist({ ...data, services: data.services.map((s) => (s.id === editing.id ? serviceReel : s)) });
        showToast("Service modifié.");
      } else {
        const serviceReel = window.produitsBridge
          ? await window.produitsBridge.creerServiceReel(clean)
          : { id: uid("srv"), ...clean };
        await persist({ ...data, services: [...data.services, serviceReel] });
        showToast("Service ajouté.");
      }
      setShowForm(false);
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  const del = async (id) => {
    try {
      if (window.produitsBridge) await window.produitsBridge.supprimerServiceReel(id);
      await persist({ ...data, services: data.services.filter((s) => s.id !== id) });
      showToast("Service supprimé.");
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  const addCategory = async () => {
    if (!newCat.trim()) return;
    if (categories.includes(newCat.trim())) return showToast("Cette catégorie existe déjà.", "error");
    await persist({ ...data, serviceCategories: [...categories, newCat.trim()] });
    setNewCat("");
    showToast("Catégorie ajoutée.");
  };
  const delCategory = async (c) => {
    await persist({ ...data, serviceCategories: categories.filter((x) => x !== c) });
  };

  return (
    <div>
      <PageHeader
        title="Services"
        subtitle="Gérez vos types de vente / services (photocopie, impression, reliure...) vendables directement en Caisse."
        actions={<Btn icon={Plus} onClick={openNew}>Nouveau Service</Btn>}
      />

      <div className="flex gap-1 mb-4 border-b border-slate-200">
        {[["list", `Liste des Services (${data.services.length})`], ["categories", "Catégories"]].map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)} className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px ${tab === key ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500"}`}>
            {label}
          </button>
        ))}
      </div>

      {tab === "list" ? (
        <Card>
          <div className="p-4 border-b border-slate-100">
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 max-w-md">
              <Search size={16} className="text-slate-400" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher un service..." className="flex-1 outline-none text-sm bg-transparent" />
            </div>
          </div>
          {list.length === 0 ? (
            <EmptyState text="Aucun service enregistré." />
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                  <th className="px-5 py-3 font-medium">Nom du Service</th>
                  <th className="px-5 py-3 font-medium">Catégorie</th>
                  <th className="px-5 py-3 font-medium">Prix</th>
                  <th className="px-5 py-3 font-medium text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
                {list.map((s) => (
                  <tr key={s.id} className="border-b border-slate-50">
                    <td className="px-5 py-3 font-medium flex items-center gap-2"><Wrench size={14} className="text-slate-400" /> {s.name}</td>
                    <td className="px-5 py-3 text-slate-500">{s.category}</td>
                    <td className="px-5 py-3 font-medium">{fmtMoney(s.price, data.settings.currency)}</td>
                    <td className="px-5 py-3">
                      <div className="flex justify-end gap-1">
                        <Btn size="sm" variant="outline" icon={Pencil} onClick={() => openEdit(s)}>Modifier</Btn>
                        <Btn size="sm" variant="danger" icon={Trash2} onClick={() => del(s.id)}>Suppr.</Btn>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </Card>
      ) : (
        <Card className="p-5 max-w-md">
          <p className="font-semibold text-slate-800 mb-3">Catégories de Services</p>
          <div className="flex gap-2 mb-4">
            <input value={newCat} onChange={(e) => setNewCat(e.target.value)} placeholder="Nouvelle catégorie" className={inputCls} onKeyDown={(e) => e.key === "Enter" && addCategory()} />
            <Btn onClick={addCategory} icon={Plus}>Ajouter</Btn>
          </div>
          <div className="space-y-2">
            {categories.map((c) => (
              <div key={c} className="flex items-center justify-between bg-slate-50 rounded-lg px-3 py-2">
                <span className="text-sm">{c}</span>
                <button onClick={() => delCategory(c)} className="text-red-500"><Trash2 size={14} /></button>
              </div>
            ))}
          </div>
        </Card>
      )}

      {showForm && (
        <Modal title={editing ? "Modifier le Service" : "Nouveau Service"} onClose={() => setShowForm(false)}>
          <Field label="Nom du Service *"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} placeholder="Ex: Photocopie N&B (A4)" /></Field>
          <Field label="Catégorie">
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className={inputCls}>
              {categories.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Prix"><input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className={inputCls} /></Field>
          <Btn onClick={save}>{editing ? "Enregistrer" : "Ajouter"}</Btn>
        </Modal>
      )}
    </div>
  );
}

// ---------- Clients ----------
function Clients({ data, persist, showToast }) {
  const lang = data.settings.language || "fr";
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", phone: "", email: "", address: "" });
  const [statementClient, setStatementClient] = useState(null);

  const openNew = () => {
    setEditing(null);
    setForm({ name: "", phone: "", email: "", address: "" });
    setShowForm(true);
  };
  const openEdit = (c) => {
    setEditing(c);
    setForm(c);
    setShowForm(true);
  };

  const save = async () => {
    if (!form.name) return showToast("Le nom est requis.", "error");
    try {
      if (editing) {
        const clientReel = window.clientsBridge
          ? await window.clientsBridge.modifierClientReel(editing.id, form)
          : { ...editing, ...form };
        await persist({ ...data, clients: data.clients.map((c) => (c.id === editing.id ? clientReel : c)) });
        showToast("Client modifié.");
      } else {
        const clientReel = window.clientsBridge
          ? await window.clientsBridge.creerClientReel(form)
          : { id: uid("cli"), loyaltyPoints: 0, credit: 0, ...form };
        await persist({ ...data, clients: [...data.clients, clientReel] });
        showToast("Client ajouté.");
      }
      setShowForm(false);
    } catch (e) {
      showToast("Erreur lors de l'enregistrement du client : " + e.message, "error");
    }
  };

  const del = async (id) => {
    try {
      if (window.clientsBridge) await window.clientsBridge.supprimerClientReel(id);
      await persist({ ...data, clients: data.clients.filter((c) => c.id !== id) });
      showToast("Client supprimé.");
    } catch (e) {
      showToast("Erreur lors de la suppression : " + e.message, "error");
    }
  };

  return (
    <div>
      <PageHeader title={t(lang, "page_clients_title")} subtitle={t(lang, "page_clients_subtitle")} actions={<Btn icon={Plus} onClick={openNew}>Nouveau Client</Btn>} />
      <Card>
        {data.clients.length === 0 ? (
          <EmptyState text="Aucun client enregistré." />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Nom</th>
                <th className="px-5 py-3 font-medium">Téléphone</th>
                <th className="px-5 py-3 font-medium">Points Fidélité</th>
                <th className="px-5 py-3 font-medium">Crédit</th>
                <th className="px-5 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {data.clients.map((c) => (
                <tr key={c.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 font-medium">{c.name}</td>
                  <td className="px-5 py-3 text-slate-500">{c.phone || "—"}</td>
                  <td className="px-5 py-3">
                    <span className="inline-flex items-center gap-1 text-emerald-600"><Gift size={13} /> {c.loyaltyPoints || 0} pts</span>
                  </td>
                  <td className="px-5 py-3 text-amber-600 font-medium">{fmtMoney(c.credit || 0, data.settings.currency)}</td>
                  <td className="px-5 py-3">
                    <div className="flex justify-end gap-1">
                      <Btn size="sm" variant="outline" icon={ReceiptText} onClick={() => setStatementClient(c)}>Relevé</Btn>
                      <Btn size="sm" variant="outline" icon={Pencil} onClick={() => openEdit(c)}>Modifier</Btn>
                      <Btn size="sm" variant="danger" icon={Trash2} onClick={() => del(c.id)}>Suppr.</Btn>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>

      {showForm && (
        <Modal title={editing ? "Modifier le Client" : "Ajouter un Nouveau Client"} onClose={() => setShowForm(false)}>
          <Field label="Nom Complet *"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} placeholder="Nom complet ou raison sociale" /></Field>
          <Field label="Téléphone"><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={inputCls} placeholder="Ex: 0661123456" /></Field>
          <Field label="E-mail"><input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputCls} placeholder="Ex: client@mail.com" /></Field>
          <Field label="Adresse Géographique"><input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className={inputCls} placeholder="Adresse, Ville, Maroc" /></Field>
          <Btn onClick={save}>{editing ? "Enregistrer" : "Ajouter"}</Btn>
        </Modal>
      )}

      {statementClient && (
        <Modal title={`Relevé de Compte — ${statementClient.name}`} onClose={() => setStatementClient(null)} wide>
          {(() => {
            const clientInvoices = data.invoices
              .filter((i) => i.clientId === statementClient.id)
              .sort((a, b) => new Date(a.date) - new Date(b.date));
            let running = 0;
            const rows = clientInvoices.map((i) => {
              running += i.total - i.paid;
              return { ...i, running };
            });
            const exportStatement = async () => {
              const sheetRows = [["Reference", "Date", "Total", "Paye", "Solde Cumule"], ...rows.map((r) => [r.ref, fmtDate(r.date), r.total, r.paid, r.running])];
              await saveXlsxFile(sheetRows, "Releve", `releve-${statementClient.name.replace(/\s+/g, "-")}-${todayISO()}.xlsx`);
            };
            return (
              <>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-slate-500">Solde actuel</p>
                    <p className={`text-xl font-bold ${statementClient.credit > 0 ? "text-amber-600" : "text-emerald-600"}`}>
                      {fmtMoney(statementClient.credit || 0, data.settings.currency)}
                    </p>
                  </div>
                  <Btn variant="outline" icon={Download} onClick={exportStatement}>Exporter (.xlsx)</Btn>
                </div>
                {rows.length === 0 ? (
                  <EmptyState text="Aucune transaction enregistrée pour ce client." />
                ) : (
                  <div className="border border-slate-100 rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100 bg-slate-50">
                          <th className="px-4 py-2.5 font-medium">Référence</th>
                          <th className="px-4 py-2.5 font-medium">Date</th>
                          <th className="px-4 py-2.5 font-medium">Total</th>
                          <th className="px-4 py-2.5 font-medium">Payé</th>
                          <th className="px-4 py-2.5 font-medium">Solde Cumulé</th>
                        </tr>
                      </thead>
                      <tbody>
                        {rows.map((r) => (
                          <tr key={r.id} className="border-b border-slate-50">
                            <td className="px-4 py-2.5 font-medium">{r.ref}</td>
                            <td className="px-4 py-2.5 text-slate-500">{fmtDate(r.date)}</td>
                            <td className="px-4 py-2.5">{fmtMoney(r.total, data.settings.currency)}</td>
                            <td className="px-4 py-2.5 text-emerald-600">{fmtMoney(r.paid, data.settings.currency)}</td>
                            <td className={`px-4 py-2.5 font-semibold ${r.running > 0 ? "text-amber-600" : "text-emerald-600"}`}>{fmtMoney(r.running, data.settings.currency)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </>
            );
          })()}
        </Modal>
      )}
    </div>
  );
}

// ---------- Stock ----------
function Stock({ data, persist, showToast }) {
  const lang = data.settings.language || "fr";
  const [tab, setTab] = useState("movements");
  const [q, setQ] = useState("");
  const [showAdj, setShowAdj] = useState(false);
  const [adjProduct, setAdjProduct] = useState(data.products[0]?.id || "");
  const [adjQty, setAdjQty] = useState(0);
  const [adjReason, setAdjReason] = useState("");

  const low = data.products.filter((p) => p.stock <= (p.alertThreshold ?? 5)).length;
  const value = data.products.reduce((s, p) => s + p.stock * p.buyPrice, 0);
  const movesThisMonth = data.stockMovements.filter((m) => m.date.slice(0, 7) === todayISO().slice(0, 7)).length;

  const filtered = data.stockMovements.filter((m) => String(m.product || "").toLowerCase().includes(q.toLowerCase()) || String(m.reason || "").toLowerCase().includes(q.toLowerCase()));

  // Marge & Rentabilité: for each product, how many units were purchased vs sold, and the resulting profit.
  const marginRows = data.products.map((p) => {
    let purchased = 0;
    data.purchases.forEach((pur) => pur.items.forEach((it) => { if (it.productId === p.id) purchased += Number(it.qty); }));
    let sold = 0;
    let revenue = 0;
    data.invoices.forEach((inv) => inv.items.forEach((it) => {
      if (it.productId === p.id) {
        sold += Number(it.qty);
        revenue += Number(it.price) * Number(it.qty);
      }
    }));
    const cost = sold * p.buyPrice;
    const profit = revenue - cost;
    const marginPct = revenue > 0 ? (profit / revenue) * 100 : 0;
    return { ...p, purchased, sold, revenue, cost, profit, marginPct };
  });
  const totalProfit = marginRows.reduce((s, r) => s + r.profit, 0);
  const totalRevenue = marginRows.reduce((s, r) => s + r.revenue, 0);

  const exportMarginReport = async () => {
    const rows = [
      ["Produit", "Acheté (u.)", "Vendu (u.)", "Revenu", "Coût", "Profit", "Marge %"],
      ...marginRows.map((r) => [r.name, r.purchased, r.sold, r.revenue.toFixed(2), r.cost.toFixed(2), r.profit.toFixed(2), r.marginPct.toFixed(1) + "%"]),
    ];
    const ok = await saveXlsxFile(rows, "Marge", `rapport-marge-${todayISO()}.xlsx`);
    if (ok) showToast("Rapport de marge exporté (.xlsx).");
  };

  const submitAdj = async () => {
    const p = data.products.find((pp) => pp.id === adjProduct);
    if (!p) return;
    const oldStock = p.stock;
    const newStock = oldStock + Number(adjQty);
    const products = data.products.map((pp) => (pp.id === p.id ? { ...pp, stock: newStock } : pp));
    const movement = {
      id: uid("mov"),
      date: new Date().toISOString(),
      product: p.name,
      type: Number(adjQty) >= 0 ? "Entrée" : "Sortie",
      delta: Number(adjQty),
      oldStock,
      newStock,
      reason: adjReason || "Ajustement manuel d'inventaire",
    };
    await persist({ ...data, products, stockMovements: [movement, ...data.stockMovements] });
    showToast("Stock ajusté.");
    setShowAdj(false);
    setAdjQty(0);
    setAdjReason("");
  };

  return (
    <div>
      <PageHeader
        title={t(lang, "page_stock_title")}
        subtitle={t(lang, "page_stock_subtitle")}
        actions={<Btn onClick={() => setShowAdj(true)}>Ajustement d'Inventaire</Btn>}
      />
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center"><AlertTriangle size={18} className="text-amber-600" /></div>
          <div>
            <p className="text-xs text-slate-500">Alertes Ruptures / Faibles</p>
            <p className="font-bold text-slate-900">{low} réf.</p>
          </div>
        </Card>
        <Card className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center"><Boxes size={18} className="text-blue-600" /></div>
          <div>
            <p className="text-xs text-slate-500">Valeur estimée du Stock</p>
            <p className="font-bold text-slate-900">{fmtMoney(value, data.settings.currency)}</p>
          </div>
        </Card>
        <Card className="p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center"><TrendingUp size={18} className="text-emerald-600" /></div>
          <div>
            <p className="text-xs text-slate-500">Rotation d'inventaire</p>
            <p className="font-bold text-slate-900">{movesThisMonth} logs</p>
          </div>
        </Card>
      </div>

      <div className="flex gap-1 mb-4 border-b border-slate-200">
        {[["movements", "Mouvements de Stock"], ["margin", "Marge & Rentabilité"]].map(([key, label]) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px ${tab === key ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500"}`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "movements" ? (
      <Card>
        <div className="p-4 border-b border-slate-100">
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 max-w-md">
            <Search size={16} className="text-slate-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher par libellé produit, raison..." className="flex-1 outline-none text-sm bg-transparent" />
          </div>
        </div>
        {filtered.length === 0 ? (
          <EmptyState text="Aucun mouvement de stock enregistré." />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Produit</th>
                <th className="px-5 py-3 font-medium">Type</th>
                <th className="px-5 py-3 font-medium">Quantité Delta</th>
                <th className="px-5 py-3 font-medium">Ancien Stock</th>
                <th className="px-5 py-3 font-medium">Nouveau Stock</th>
                <th className="px-5 py-3 font-medium">Raison / Origine</th>
              </tr>
            </thead>
            <tbody>
              {filtered.slice(0, 100).map((m) => (
                <tr key={m.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 text-slate-500">{fmtDate(m.date)}</td>
                  <td className="px-5 py-3 font-medium">{m.product}</td>
                  <td className="px-5 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${m.type === "Entrée" ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}>{m.type}</span>
                  </td>
                  <td className={`px-5 py-3 font-medium ${m.delta >= 0 ? "text-emerald-600" : "text-red-600"}`}>{m.delta >= 0 ? `+${m.delta}` : m.delta} u.</td>
                  <td className="px-5 py-3 text-slate-400">{m.oldStock}</td>
                  <td className="px-5 py-3">{m.newStock}</td>
                  <td className="px-5 py-3 text-slate-500">{m.reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
      ) : (
      <div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
          <Card className="p-4">
            <p className="text-xs text-slate-500">Revenu Total (produits vendus)</p>
            <p className="font-bold text-slate-900 text-lg">{fmtMoney(totalRevenue, data.settings.currency)}</p>
          </Card>
          <Card className="p-4">
            <p className="text-xs text-slate-500">Profit Total Réalisé</p>
            <p className={`font-bold text-lg ${totalProfit >= 0 ? "text-emerald-600" : "text-red-600"}`}>{fmtMoney(totalProfit, data.settings.currency)}</p>
          </Card>
        </div>
        <Card>
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <p className="text-sm text-slate-500">Combien de chaque produit a été acheté vs vendu, et la marge réalisée.</p>
            <Btn size="sm" variant="outline" icon={Download} onClick={exportMarginReport}>Exporter (.xlsx)</Btn>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Produit</th>
                <th className="px-5 py-3 font-medium">Acheté</th>
                <th className="px-5 py-3 font-medium">Vendu</th>
                <th className="px-5 py-3 font-medium">Revenu</th>
                <th className="px-5 py-3 font-medium">Coût</th>
                <th className="px-5 py-3 font-medium">Profit</th>
                <th className="px-5 py-3 font-medium">Marge</th>
              </tr>
            </thead>
            <tbody>
              {marginRows.map((r) => (
                <tr key={r.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 font-medium">{r.name}</td>
                  <td className="px-5 py-3 text-emerald-600">{r.purchased} u.</td>
                  <td className="px-5 py-3 text-blue-600">{r.sold} u.</td>
                  <td className="px-5 py-3">{fmtMoney(r.revenue, data.settings.currency)}</td>
                  <td className="px-5 py-3 text-slate-500">{fmtMoney(r.cost, data.settings.currency)}</td>
                  <td className={`px-5 py-3 font-semibold ${r.profit >= 0 ? "text-emerald-600" : "text-red-600"}`}>{fmtMoney(r.profit, data.settings.currency)}</td>
                  <td className="px-5 py-3 text-slate-500">{r.marginPct.toFixed(1)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      </div>
      )}

      {showAdj && (
        <Modal title="Ajustement d'Inventaire" onClose={() => setShowAdj(false)}>
          <Field label="Produit">
            <select value={adjProduct} onChange={(e) => setAdjProduct(e.target.value)} className={inputCls}>
              {data.products.map((p) => <option key={p.id} value={p.id}>{p.name} (stock: {p.stock})</option>)}
            </select>
          </Field>
          <Field label="Ajustement (+ entrée / - sortie)"><input type="number" value={adjQty} onChange={(e) => setAdjQty(e.target.value)} className={inputCls} /></Field>
          <Field label="Raison"><input value={adjReason} onChange={(e) => setAdjReason(e.target.value)} className={inputCls} placeholder="Ex: Casse, Inventaire physique..." /></Field>
          <Btn onClick={submitAdj}>Valider l'ajustement</Btn>
        </Modal>
      )}
    </div>
  );
}

// ---------- Expenses ----------
function Expenses({ data, persist, showToast }) {
  const lang = data.settings.language || "fr";
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", category: "Professionnelle", amount: 0, note: "" });
  const [filter, setFilter] = useState("Toutes les Dépenses");

  const pro = data.expenses.filter((e) => e.category === "Professionnelle").reduce((s, e) => s + Number(e.amount), 0);
  const perso = data.expenses.filter((e) => e.category === "Personnelle").reduce((s, e) => s + Number(e.amount), 0);

  const list = data.expenses.filter((e) => filter === "Toutes les Dépenses" || e.category === filter.replace("s", ""));

  const save = async () => {
    if (!form.title || !form.amount) return showToast("Titre et montant requis.", "error");
    try {
      const expense = window.depensesBridge
        ? await window.depensesBridge.creerDepenseReelle(form)
        : { id: uid("exp"), date: new Date().toISOString(), ...form, amount: Number(form.amount) };
      const cashRegister = { ...data.cashRegister, solde: data.cashRegister.solde - Number(form.amount) };
      await persist({ ...data, expenses: [expense, ...data.expenses], cashRegister });
      showToast("Dépense enregistrée.");
      setShowForm(false);
      setForm({ title: "", category: "Professionnelle", amount: 0, note: "" });
    } catch (e) {
      showToast("Erreur lors de l'enregistrement : " + e.message, "error");
    }
  };

  const del = async (id) => {
    try {
      if (window.depensesBridge) await window.depensesBridge.supprimerDepenseReelle(id);
      await persist({ ...data, expenses: data.expenses.filter((e) => e.id !== id) });
      showToast("Dépense supprimée.");
    } catch (e) {
      showToast("Erreur lors de la suppression : " + e.message, "error");
    }
  };

  return (
    <div>
      <PageHeader title={t(lang, "page_expenses_title")} subtitle={t(lang, "page_expenses_subtitle")} actions={<Btn icon={Plus} onClick={() => setShowForm(true)}>Enregistrer une Dépense</Btn>} />
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card className="p-4">
          <p className="text-xs text-slate-500">Dépenses Professionnelles :</p>
          <p className="font-bold text-slate-900 text-lg">{fmtMoney(pro, data.settings.currency)}</p>
        </Card>
        <Card className="p-4">
          <p className="text-xs text-slate-500">Frais Personnels :</p>
          <p className="font-bold text-slate-900 text-lg">{fmtMoney(perso, data.settings.currency)}</p>
        </Card>
        <Card className="p-4 border-red-100">
          <p className="text-xs text-red-500">Total Sorties Global :</p>
          <p className="font-bold text-red-600 text-lg">{fmtMoney(pro + perso, data.settings.currency)}</p>
        </Card>
      </div>
      <Card>
        {list.length === 0 ? (
          <EmptyState text="Aucune dépense enregistrée." />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Intitulé</th>
                <th className="px-5 py-3 font-medium">Catégorie</th>
                <th className="px-5 py-3 font-medium">Montant</th>
                <th className="px-5 py-3 font-medium">Notes</th>
                <th className="px-5 py-3 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {list.map((e) => (
                <tr key={e.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 text-slate-500">{fmtDate(e.date)}</td>
                  <td className="px-5 py-3 font-medium">{e.title}</td>
                  <td className="px-5 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${e.category === "Professionnelle" ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"}`}>{e.category}</span>
                  </td>
                  <td className="px-5 py-3 font-medium">{fmtMoney(e.amount, data.settings.currency)}</td>
                  <td className="px-5 py-3 text-slate-500">{e.note}</td>
                  <td className="px-5 py-3 text-right"><button onClick={() => del(e.id)} className="text-red-500 p-1.5"><Trash2 size={15} /></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>

      {showForm && (
        <Modal title="Enregistrer une Dépense" onClose={() => setShowForm(false)}>
          <Field label="Intitulé *"><input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className={inputCls} /></Field>
          <Field label="Catégorie">
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className={inputCls}>
              <option>Professionnelle</option>
              <option>Personnelle</option>
            </select>
          </Field>
          <Field label="Montant (DH) *"><input type="number" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} className={inputCls} /></Field>
          <Field label="Note"><input value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} className={inputCls} /></Field>
          <Btn onClick={save}>Enregistrer</Btn>
        </Modal>
      )}
    </div>
  );
}

// ---------- Analysis ----------
function Analysis({ data, showToast }) {
  const lang = data.settings.language || "fr";
  const [range, setRange] = useState("Ce mois");
  const [fromDate, setFromDate] = useState(todayISO());
  const [toDate, setToDate] = useState(todayISO());
  const now = new Date();
  const inRange = (iso) => {
    const d = new Date(iso);
    if (range === "Personnalisé") {
      const from = new Date(fromDate + "T00:00:00");
      const to = new Date(toDate + "T23:59:59");
      return d >= from && d <= to;
    }
    if (range === "Ce mois") return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    if (range === "Cette semaine") {
      const diff = (now - d) / 86400000;
      return diff >= 0 && diff <= 7;
    }
    if (range === "Aujourd'hui") return d.toDateString() === now.toDateString();
    return true;
  };

  const invs = data.invoices.filter((i) => inRange(i.date));
  const exps = data.expenses.filter((e) => inRange(e.date));
  const ca = invs.reduce((s, i) => s + i.total, 0);
  const coutAchat = invs.reduce((s, i) => s + i.items.reduce((ss, it) => {
    const p = data.products.find((pp) => pp.id === it.productId);
    return ss + (p ? p.buyPrice * it.qty : 0);
  }, 0), 0);
  const beneficeBrut = ca - coutAchat;
  const totalExp = exps.reduce((s, e) => s + Number(e.amount), 0);
  const beneficeNet = beneficeBrut - totalExp;
  const creditClients = data.clients.reduce((s, c) => s + (c.credit || 0), 0);
  const detteFournisseurs = data.suppliers.reduce((s, f) => s + (f.debt || 0), 0);
  const nbVentes = invs.length;
  const produitsVendus = invs.reduce((s, i) => s + i.items.reduce((ss, it) => ss + it.qty, 0), 0);

  const kpiRows = [
    ["Chiffre d'affaires", ca],
    ["Bénéfice brut", beneficeBrut],
    ["Bénéfice net", beneficeNet],
    ["Dépenses", totalExp],
    ["Crédit clients", creditClients],
    ["Crédit fournisseurs", detteFournisseurs],
    ["Nombre de ventes", nbVentes],
    ["Produits vendus", produitsVendus],
  ];

  const exportExcel = async () => {
    const rows = [["Indicateur", "Valeur"], ...kpiRows.map(([k, v]) => [k, v])];
    const ok = await saveXlsxFile(rows, "Analyse", `rapport-analyse-${range.replace(/\s+/g, "-")}-${todayISO()}.xlsx`);
    if (ok) showToast("Export Excel (.xlsx) généré.");
  };

  const exportPDF = () => {
    const formatted = [
      ["Chiffre d'affaires", fmtMoney(ca, data.settings.currency)],
      ["Bénéfice brut", fmtMoney(beneficeBrut, data.settings.currency)],
      ["Bénéfice net", fmtMoney(beneficeNet, data.settings.currency)],
      ["Dépenses", fmtMoney(totalExp, data.settings.currency)],
      ["Crédit clients", fmtMoney(creditClients, data.settings.currency)],
      ["Crédit fournisseurs", fmtMoney(detteFournisseurs, data.settings.currency)],
      ["Nombre de ventes", nbVentes],
      ["Produits vendus", produitsVendus],
    ];
    generateReportPDF(formatted, range, data.settings);
  };

  return (
    <div>
      <PageHeader
        title={t(lang, "page_analysis_title")}
        actions={
          <>
            <Btn variant="outline" icon={Printer} onClick={() => window.print()}>Imprimer</Btn>
            <Btn variant="outline" icon={FileText} onClick={exportPDF}>PDF</Btn>
            <Btn variant="outline" icon={Download} onClick={exportExcel}>Excel (.xlsx)</Btn>
          </>
        }
      />
      <div className="flex flex-wrap gap-2 items-center mb-6">
        <select value={range} onChange={(e) => setRange(e.target.value)} className={inputCls + " max-w-xs"}>
          <option>Aujourd'hui</option>
          <option>Cette semaine</option>
          <option>Ce mois</option>
          <option>Tout</option>
          <option>Personnalisé</option>
        </select>
        {range === "Personnalisé" && (
          <>
            <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className={inputClsW("w-auto")} />
            <span className="text-slate-400">→</span>
            <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className={inputClsW("w-auto")} />
          </>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={DollarSign} color="#2563eb" label="Chiffre d'affaires" value={fmtMoney(ca, data.settings.currency)} />
        <StatCard icon={TrendingUp} color="#16a34a" label="Bénéfice brut" value={fmtMoney(beneficeBrut, data.settings.currency)} />
        <StatCard icon={PiggyBank} color="#7c3aed" label="Bénéfice net" value={fmtMoney(beneficeNet, data.settings.currency)} />
        <StatCard icon={Wallet} color="#dc2626" label="Dépenses" value={fmtMoney(totalExp, data.settings.currency)} />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard icon={Users} color="#d97706" label="Crédit clients" value={fmtMoney(creditClients, data.settings.currency)} />
        <StatCard icon={Truck} color="#dc2626" label="Crédit fournisseurs" value={fmtMoney(detteFournisseurs, data.settings.currency)} />
        <StatCard icon={ShoppingCart} color="#7c3aed" label="Nombre de ventes" value={nbVentes} />
        <StatCard icon={Boxes} color="#0891b2" label="Produits vendus" value={produitsVendus} />
      </div>

      <Card className="p-5">
        <p className="font-semibold text-slate-800 mb-3">Vue d'ensemble</p>
        <p className="text-sm text-slate-500">
          Sur la période sélectionnée ({range.toLowerCase()}), l'activité a généré {fmtMoney(ca, data.settings.currency)} de chiffre d'affaires
          pour {nbVentes} vente(s), avec un bénéfice net de {fmtMoney(beneficeNet, data.settings.currency)} après déduction des dépenses.
        </p>
      </Card>
    </div>
  );
}

// ---------- Security & Roles ----------
function Security({ data, persist, showToast, session }) {
  const lang = data.settings.language || "fr";
  const actor = session?.name || "Administrateur";
  const [tab, setTab] = useState("employees");
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const emptyForm = { name: "", email: "", role: "Caissier", pin: "", active: true, permissions: ["DASHBOARD", "POS_OPEN", "POS_CREATE_SALE", "POS_PRINT_RECEIPT"] };
  const [form, setForm] = useState(emptyForm);

  const ROLES = ["Administrateur", "Responsable", "Caissier", "Comptable", "Magasinier"];

  const openNew = () => {
    setEditing(null);
    setForm(emptyForm);
    setShowForm(true);
  };
  const openEdit = (emp) => {
    setEditing(emp);
    setForm({ ...emptyForm, ...emp, permissions: emp.permissions || [] });
    setShowForm(true);
  };

  const togglePermission = (key) => {
    setForm((f) => ({
      ...f,
      permissions: f.permissions.includes(key) ? f.permissions.filter((k) => k !== key) : [...f.permissions, key],
    }));
  };

  const save = async () => {
    if (!form.name || !form.pin) return showToast("Nom et code PIN requis.", "error");
    try {
      if (editing) {
        const employeReel = window.employesBridge
          ? await window.employesBridge.modifierEmployeReel(editing.id, form)
          : { ...editing, ...form };
        const employees = data.employees.map((e) => (e.id === editing.id ? employeReel : e));
        const securityLog = logEvent(data, actor, "MODIFICATION COLLABORATEUR", `Collaborateur "${form.name}" modifié (rôle : ${form.role}).`);
        await persist({ ...data, employees, securityLog });
        showToast("Collaborateur modifié.");
      } else {
        const employeReel = window.employesBridge
          ? await window.employesBridge.creerEmployeReel(form)
          : { id: uid("emp"), ...form };
        const employees = [...data.employees, employeReel];
        const securityLog = logEvent(data, actor, "NOUVEAU COLLABORATEUR", `Collaborateur "${form.name}" créé avec le rôle ${form.role}.`);
        await persist({ ...data, employees, securityLog });
        showToast("Collaborateur ajouté.");
      }
      setShowForm(false);
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  const del = async (id) => {
    const emp = data.employees.find((e) => e.id === id);
    try {
      if (window.employesBridge) await window.employesBridge.supprimerEmployeReel(id);
      const securityLog = logEvent(data, actor, "SUPPRESSION COLLABORATEUR", `Collaborateur "${emp?.name}" supprimé.`);
      await persist({ ...data, employees: data.employees.filter((e) => e.id !== id), securityLog });
      showToast("Collaborateur supprimé.");
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  return (
    <div>
      <PageHeader
        title={t(lang, "page_security_title")}
        subtitle={t(lang, "page_security_subtitle")}
        actions={tab === "employees" && <Btn icon={Plus} onClick={openNew}>Nouveau Collaborateur</Btn>}
      />
      <div className="flex gap-1 mb-4 border-b border-slate-200">
        {[["employees", `Collaborateurs (${data.employees.length})`], ["roles", `Rôles & Autorisations (${ROLES.length})`]].map(([key, label]) => (
          <button key={key} onClick={() => setTab(key)} className={`px-4 py-2.5 text-sm font-medium border-b-2 -mb-px ${tab === key ? "border-blue-600 text-blue-600" : "border-transparent text-slate-500"}`}>
            {label}
          </button>
        ))}
      </div>

      {tab === "employees" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.employees.map((emp) => (
            <Card key={emp.id} className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-900 text-white flex items-center justify-center font-semibold text-sm">
                    {emp.name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{emp.name}</p>
                    <p className="text-xs text-slate-400">{emp.email}</p>
                  </div>
                </div>
                <span className={`text-[11px] px-2 py-0.5 rounded-full ${emp.active !== false ? "bg-emerald-100 text-emerald-700" : "bg-slate-200 text-slate-500"}`}>
                  {emp.active !== false ? "ACTIF" : "BLOQUÉ"}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 mb-3">
                <div className="bg-slate-50 rounded-lg p-2 text-center">
                  <p className="text-[10px] text-slate-400 uppercase">Rôle</p>
                  <p className="text-xs font-medium">{emp.role}</p>
                </div>
                <div className="bg-slate-50 rounded-lg p-2 text-center">
                  <p className="text-[10px] text-slate-400 uppercase">Code PIN</p>
                  <p className="text-xs font-medium">••••</p>
                </div>
              </div>
              <p className="text-[11px] text-slate-400 mb-3">{(emp.permissions || []).length} / {PERMISSIONS.length} habilitations activées</p>
              <div className="flex gap-2">
                <Btn size="sm" variant="outline" icon={Pencil} onClick={() => openEdit(emp)}>Modifier</Btn>
                <Btn size="sm" variant="danger" icon={Trash2} onClick={() => del(emp.id)}>Supprimer</Btn>
              </div>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="p-5">
          <div className="space-y-2">
            {ROLES.map((r) => (
              <div key={r} className="flex items-center justify-between px-4 py-3 bg-slate-50 rounded-lg">
                <span className="text-sm font-medium">{r}</span>
                <span className="text-xs text-slate-400">{data.employees.filter((e) => e.role === r).length} collaborateur(s)</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {showForm && (
        <Modal title={editing ? "Modifier le Collaborateur" : "Nouveau Collaborateur"} onClose={() => setShowForm(false)} wide>
          <div className="grid grid-cols-2 gap-x-4">
            <Field label="Nom Complet *"><input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className={inputCls} /></Field>
            <Field label="Email"><input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputCls} /></Field>
            <Field label="Rôle">
              <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })} className={inputCls}>
                {ROLES.map((r) => <option key={r} value={r}>{r}</option>)}
              </select>
            </Field>
            <Field label="Code PIN (4 chiffres) *"><input value={form.pin} maxLength={4} onChange={(e) => setForm({ ...form, pin: e.target.value.replace(/\D/g, "") })} className={inputCls} /></Field>
          </div>

          <label className="flex items-center justify-between bg-slate-50 rounded-lg px-4 py-3 mb-4">
            <div>
              <p className="text-sm font-medium">Autoriser la connexion</p>
              <p className="text-xs text-slate-400">Si désactivé, le compte sera bloqué sans être supprimé.</p>
            </div>
            <input type="checkbox" checked={form.active !== false} onChange={(e) => setForm({ ...form, active: e.target.checked })} className="w-5 h-5" />
          </label>

          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-semibold text-slate-500 uppercase">Habilitations Individuelles :</p>
            <button
              type="button"
              className="text-xs text-blue-600 font-medium"
              onClick={() => setForm((f) => ({ ...f, permissions: f.permissions.length === ALL_PERMISSION_KEYS.length ? [] : [...ALL_PERMISSION_KEYS] }))}
            >
              {form.permissions.length === ALL_PERMISSION_KEYS.length ? "Tout décocher" : "Tout cocher"}
            </button>
          </div>
          <div className="max-h-72 overflow-y-auto border border-slate-100 rounded-lg divide-y divide-slate-100 mb-4">
            {PERMISSIONS.map((perm) => (
              <label key={perm.key} className="flex items-center justify-between px-4 py-2.5 text-sm cursor-pointer hover:bg-slate-50">
                <span className="font-medium text-blue-700">{perm.label}</span>
                <input type="checkbox" checked={form.permissions.includes(perm.key)} onChange={() => togglePermission(perm.key)} className="w-4 h-4" />
              </label>
            ))}
          </div>

          <Btn onClick={save}>{editing ? "Enregistrer" : "Ajouter"}</Btn>
        </Modal>
      )}
    </div>
  );
}

// ---------- Rapports & Chiffres ----------
function Reports({ data, showToast }) {
  const lang = data.settings.language || "fr";
  const [type, setType] = useState("ventes");
  const [range, setRange] = useState("Ce mois");
  const [fromDate, setFromDate] = useState(todayISO());
  const [toDate, setToDate] = useState(todayISO());

  const now = new Date();
  const inRange = (iso) => {
    const d = new Date(iso);
    if (range === "Personnalisé") {
      const from = new Date(fromDate + "T00:00:00");
      const to = new Date(toDate + "T23:59:59");
      return d >= from && d <= to;
    }
    if (range === "Aujourd'hui") return d.toDateString() === now.toDateString();
    if (range === "Cette semaine") { const diff = (now - d) / 86400000; return diff >= 0 && diff <= 7; }
    if (range === "Ce mois") return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    return true;
  };

  const REPORT_TYPES = [
    { key: "ventes", label: "Rapport des Ventes", icon: ShoppingCart },
    { key: "caissiers", label: "Ventes par Caissier", icon: Users },
    { key: "achats", label: "Rapport des Achats", icon: PackagePlus },
    { key: "stock", label: "Rapport de Stock", icon: Boxes },
    { key: "depenses", label: "Rapport des Dépenses", icon: DollarSign },
  ];

  const ventes = data.invoices.filter((i) => inRange(i.date));
  const achats = data.purchases.filter((p) => inRange(p.date));
  const depenses = data.expenses.filter((e) => inRange(e.date));

  // Aggregate sales by the cashier who processed each one — helps answer
  // "how much has this cashier sold" directly.
  const caissiersMap = {};
  ventes.forEach((v) => {
    const name = v.cashierName || "Non identifié";
    if (!caissiersMap[name]) caissiersMap[name] = { name, count: 0, total: 0 };
    caissiersMap[name].count += 1;
    caissiersMap[name].total += v.total;
  });
  const caissiersReport = Object.values(caissiersMap).sort((a, b) => b.total - a.total);

  const exportReport = async () => {
    let rows;
    let filename;
    if (type === "ventes") {
      rows = [["Référence", "Date", "Client", "Total", "Statut"], ...ventes.map((v) => [v.ref, fmtDate(v.date), v.clientName, v.total, v.status])];
      filename = `rapport-ventes-${todayISO()}.xlsx`;
    } else if (type === "caissiers") {
      rows = [["Caissier", "Nombre de Ventes", "Montant Total"], ...caissiersReport.map((c) => [c.name, c.count, c.total])];
      filename = `rapport-caissiers-${todayISO()}.xlsx`;
    } else if (type === "achats") {
      rows = [["Référence", "Date", "Fournisseur", "Total", "Payé"], ...achats.map((a) => [a.ref, fmtDate(a.date), a.supplierName, a.total, a.paid])];
      filename = `rapport-achats-${todayISO()}.xlsx`;
    } else if (type === "stock") {
      rows = [["Produit", "Catégorie", "Stock Actuel", "Valeur (Prix Achat)"], ...data.products.map((p) => [p.name, p.category, p.stock, (p.stock * p.buyPrice).toFixed(2)])];
      filename = `rapport-stock-${todayISO()}.xlsx`;
    } else {
      rows = [["Date", "Intitulé", "Catégorie", "Montant"], ...depenses.map((e) => [fmtDate(e.date), e.title, e.category, e.amount])];
      filename = `rapport-depenses-${todayISO()}.xlsx`;
    }
    const ok = await saveXlsxFile(rows, "Rapport", filename);
    if (ok) showToast("Rapport exporté (.xlsx).");
  };

  const exportReportPDF = async () => {
    const titles = { ventes: "Rapport des Ventes", caissiers: "Ventes par Caissier", achats: "Rapport des Achats", stock: "Rapport de Stock", depenses: "Rapport des Dépenses" };
    let columns, rows;
    if (type === "ventes") {
      columns = ["Référence", "Date", "Client", "Total", "Statut"];
      rows = ventes.map((v) => [v.ref, fmtDate(v.date), v.clientName, fmtMoney(v.total, data.settings.currency), v.status]);
    } else if (type === "caissiers") {
      columns = ["Caissier", "Nombre de Ventes", "Montant Total"];
      rows = caissiersReport.map((c) => [c.name, String(c.count), fmtMoney(c.total, data.settings.currency)]);
    } else if (type === "achats") {
      columns = ["Référence", "Date", "Fournisseur", "Total", "Payé"];
      rows = achats.map((a) => [a.ref, fmtDate(a.date), a.supplierName, fmtMoney(a.total, data.settings.currency), fmtMoney(a.paid, data.settings.currency)]);
    } else if (type === "stock") {
      columns = ["Produit", "Catégorie", "Stock", "Valeur"];
      rows = data.products.map((p) => [p.name, p.category, `${p.stock} u.`, fmtMoney(p.stock * p.buyPrice, data.settings.currency)]);
    } else {
      columns = ["Date", "Intitulé", "Catégorie", "Montant"];
      rows = depenses.map((e) => [fmtDate(e.date), e.title, e.category, fmtMoney(e.amount, data.settings.currency)]);
    }
    const ok = await generateTablePDF(titles[type], columns, rows, data.settings);
    if (ok) showToast("Rapport exporté (.pdf).");
  };

  return (
    <div>
      <PageHeader
        title={t(lang, "page_reports_title")}
        subtitle={t(lang, "page_reports_subtitle")}
        actions={
          <>
            <select value={range} onChange={(e) => setRange(e.target.value)} className={inputClsW("w-auto")}>
              <option>Aujourd'hui</option>
              <option>Cette semaine</option>
              <option>Ce mois</option>
              <option>Tout</option>
              <option>Personnalisé</option>
            </select>
            {range === "Personnalisé" && (
              <>
                <input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className={inputClsW("w-auto")} />
                <span className="text-slate-400 self-center">→</span>
                <input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className={inputClsW("w-auto")} />
              </>
            )}
            <Btn variant="outline" icon={Download} onClick={exportReport}>Exporter (.xlsx)</Btn>
            <Btn variant="outline" icon={FileText} onClick={exportReportPDF}>Exporter (.pdf)</Btn>
            <Btn variant="outline" icon={Printer} onClick={() => window.print()}>Imprimer</Btn>
          </>
        }
      />

      <div className="flex flex-wrap gap-2 mb-6">
        {REPORT_TYPES.map((r) => {
          const Icon = r.icon;
          return (
            <button
              key={r.key}
              onClick={() => setType(r.key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium border ${
                type === r.key ? "bg-slate-900 text-white border-slate-900" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}
            >
              <Icon size={15} /> {r.label}
            </button>
          );
        })}
      </div>

      <Card>
        {type === "ventes" && (
          ventes.length === 0 ? <EmptyState text="Aucune vente sur cette période." /> : (
            <table className="w-full text-sm">
              <thead><tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Référence</th><th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Client</th><th className="px-5 py-3 font-medium">Total</th><th className="px-5 py-3 font-medium">Statut</th>
              </tr></thead>
              <tbody>{ventes.map((v) => (
                <tr key={v.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 font-semibold">{v.ref}</td><td className="px-5 py-3 text-slate-500">{fmtDate(v.date)}</td>
                  <td className="px-5 py-3">{v.clientName}</td><td className="px-5 py-3 font-medium">{fmtMoney(v.total, data.settings.currency)}</td>
                  <td className="px-5 py-3 text-slate-500">{v.status}</td>
                </tr>
              ))}</tbody>
            </table>
          )
        )}
        {type === "achats" && (
          achats.length === 0 ? <EmptyState text="Aucun achat sur cette période." /> : (
            <table className="w-full text-sm">
              <thead><tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Référence</th><th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Fournisseur</th><th className="px-5 py-3 font-medium">Total</th><th className="px-5 py-3 font-medium">Payé</th>
              </tr></thead>
              <tbody>{achats.map((a) => (
                <tr key={a.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 font-semibold">{a.ref}</td><td className="px-5 py-3 text-slate-500">{fmtDate(a.date)}</td>
                  <td className="px-5 py-3">{a.supplierName}</td><td className="px-5 py-3 font-medium">{fmtMoney(a.total, data.settings.currency)}</td>
                  <td className="px-5 py-3 text-emerald-600">{fmtMoney(a.paid, data.settings.currency)}</td>
                </tr>
              ))}</tbody>
            </table>
          )
        )}
        {type === "stock" && (
          <table className="w-full text-sm">
            <thead><tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
              <th className="px-5 py-3 font-medium">Produit</th><th className="px-5 py-3 font-medium">Catégorie</th>
              <th className="px-5 py-3 font-medium">Stock Actuel</th><th className="px-5 py-3 font-medium">Valeur (Prix Achat)</th>
            </tr></thead>
            <tbody>{data.products.map((p) => (
              <tr key={p.id} className="border-b border-slate-50">
                <td className="px-5 py-3 font-medium">{p.name}</td><td className="px-5 py-3 text-slate-500">{p.category}</td>
                <td className="px-5 py-3">{p.stock} u.</td><td className="px-5 py-3 font-medium">{fmtMoney(p.stock * p.buyPrice, data.settings.currency)}</td>
              </tr>
            ))}</tbody>
          </table>
        )}
        {type === "depenses" && (
          depenses.length === 0 ? <EmptyState text="Aucune dépense sur cette période." /> : (
            <table className="w-full text-sm">
              <thead><tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Date</th><th className="px-5 py-3 font-medium">Intitulé</th>
                <th className="px-5 py-3 font-medium">Catégorie</th><th className="px-5 py-3 font-medium">Montant</th>
              </tr></thead>
              <tbody>{depenses.map((e) => (
                <tr key={e.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 text-slate-500">{fmtDate(e.date)}</td><td className="px-5 py-3 font-medium">{e.title}</td>
                  <td className="px-5 py-3">{e.category}</td><td className="px-5 py-3 font-medium">{fmtMoney(e.amount, data.settings.currency)}</td>
                </tr>
              ))}</tbody>
            </table>
          )
        )}
      </Card>
    </div>
  );
}

// ---------- Journal de Sécurité ----------
function SecurityLog({ data }) {
  const lang = data.settings.language || "fr";
  const [q, setQ] = useState("");
  const log = data.securityLog || [];
  const list = log.filter(
    (l) =>
      String(l.action || "").toLowerCase().includes(q.toLowerCase()) ||
      String(l.actor || "").toLowerCase().includes(q.toLowerCase()) ||
      String(l.details || "").toLowerCase().includes(q.toLowerCase())
  );

  const actionColor = (action) => {
    if (action.includes("ÉCHEC") || action.includes("SUPPRESSION") || action.includes("RÉINITIALISATION")) return "bg-red-100 text-red-700";
    if (action.includes("MODIFICATION") || action.includes("MODIFIÉ") || action.includes("MODIFIÉS")) return "bg-amber-100 text-amber-700";
    if (action.includes("CONNEXION") || action.includes("NOUVEAU") || action.includes("EXPORTÉE")) return "bg-emerald-100 text-emerald-700";
    return "bg-slate-100 text-slate-600";
  };

  return (
    <div>
      <PageHeader
        title={t(lang, "page_securitylog_title")}
        subtitle={t(lang, "page_securitylog_subtitle")}
      />
      <Card>
        <div className="p-4 border-b border-slate-100">
          <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 max-w-md">
            <Search size={16} className="text-slate-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Rechercher par action, utilisateur, détail..." className="flex-1 outline-none text-sm bg-transparent" />
          </div>
        </div>
        {list.length === 0 ? (
          <EmptyState text="Aucun événement enregistré pour le moment." />
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-slate-400 text-xs uppercase border-b border-slate-100">
                <th className="px-5 py-3 font-medium">Date</th>
                <th className="px-5 py-3 font-medium">Utilisateur</th>
                <th className="px-5 py-3 font-medium">Action</th>
                <th className="px-5 py-3 font-medium">Détails</th>
              </tr>
            </thead>
            <tbody>
              {list.map((l) => (
                <tr key={l.id} className="border-b border-slate-50">
                  <td className="px-5 py-3 text-slate-500 whitespace-nowrap">{fmtDate(l.date)} {new Date(l.date).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</td>
                  <td className="px-5 py-3 font-medium">{l.actor}</td>
                  <td className="px-5 py-3">
                    <span className={`text-[11px] px-2 py-0.5 rounded-full font-medium ${actionColor(l.action)}`}>{l.action}</span>
                  </td>
                  <td className="px-5 py-3 text-slate-500">{l.details}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}

// ---------- Calendrier Fiscal ----------
function TaxCalendar({ data, persist, showToast }) {
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ label: "", date: todayISO(), notes: "" });

  const openNew = () => {
    setForm({ label: "", date: todayISO(), notes: "" });
    setShowForm(true);
  };

  const save = async () => {
    if (!form.label.trim() || !form.date) return showToast("Le libellé et la date sont obligatoires.", "error");
    try {
      const reminder = window.fiscalBridge
        ? await window.fiscalBridge.creerRappelReel(form)
        : { id: uid("tax"), label: form.label.trim(), date: form.date, notes: form.notes, done: false };
      await persist({ ...data, taxReminders: [...data.taxReminders, reminder] });
      showToast("Rappel ajouté au calendrier fiscal.");
      setShowForm(false);
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  const toggleDone = async (id) => {
    const cible = data.taxReminders.find((r) => r.id === id);
    try {
      if (window.fiscalBridge) await window.fiscalBridge.basculerRappelReel(id, !cible.done);
      const taxReminders = data.taxReminders.map((r) => (r.id === id ? { ...r, done: !r.done } : r));
      await persist({ ...data, taxReminders });
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  const del = async (id) => {
    try {
      if (window.fiscalBridge) await window.fiscalBridge.supprimerRappelReel(id);
      await persist({ ...data, taxReminders: data.taxReminders.filter((r) => r.id !== id) });
      showToast("Rappel supprimé.");
    } catch (e) {
      showToast("Erreur : " + e.message, "error");
    }
  };

  const todayMs = new Date(todayISO()).getTime();
  const sorted = [...data.taxReminders].sort((a, b) => new Date(a.date) - new Date(b.date));
  const upcoming = sorted.filter((r) => !r.done && new Date(r.date).getTime() >= todayMs - 86400000);
  const overdue = sorted.filter((r) => !r.done && new Date(r.date).getTime() < todayMs - 86400000);
  const done = sorted.filter((r) => r.done);

  const daysUntil = (dateStr) => Math.round((new Date(dateStr).getTime() - todayMs) / 86400000);

  const ReminderRow = ({ r }) => {
    const d = daysUntil(r.date);
    return (
      <div className={`flex items-center justify-between px-4 py-3 border-b border-slate-50 ${r.done ? "opacity-50" : ""}`}>
        <div className="flex items-center gap-3">
          <button onClick={() => toggleDone(r.id)} className={`w-5 h-5 rounded-full border flex items-center justify-center ${r.done ? "bg-emerald-500 border-emerald-500" : "border-slate-300"}`}>
            {r.done && <Check size={12} className="text-white" />}
          </button>
          <div>
            <p className={`text-sm font-medium ${r.done ? "line-through text-slate-400" : "text-slate-800"}`}>{r.label}</p>
            <p className="text-xs text-slate-400">{fmtDate(r.date)}{r.notes ? ` — ${r.notes}` : ""}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {!r.done && (
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${d < 0 ? "bg-red-100 text-red-700" : d <= 7 ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-500"}`}>
              {d < 0 ? `En retard de ${Math.abs(d)}j` : d === 0 ? "Aujourd'hui" : `Dans ${d}j`}
            </span>
          )}
          <button onClick={() => del(r.id)} className="text-red-500 p-1"><Trash2 size={15} /></button>
        </div>
      </div>
    );
  };

  return (
    <div>
      <PageHeader
        title="Calendrier Fiscal"
        subtitle="Notez vos propres dates de déclaration de la TVA ou d'autres échéances fiscales, et recevez un rappel visuel avant l'échéance."
        actions={<Btn icon={Plus} onClick={openNew}>Nouveau Rappel</Btn>}
      />

      {overdue.length > 0 && (
        <Card className="mb-5 border-red-200 bg-red-50">
          <div className="p-4 border-b border-red-100">
            <p className="font-semibold text-red-700 flex items-center gap-2"><AlertTriangle size={16} /> En retard ({overdue.length})</p>
          </div>
          {overdue.map((r) => <ReminderRow key={r.id} r={r} />)}
        </Card>
      )}

      <Card className="mb-5">
        <div className="p-4 border-b border-slate-100">
          <p className="font-semibold text-slate-800">À venir</p>
        </div>
        {upcoming.length === 0 ? (
          <EmptyState text="Aucune échéance à venir. Cliquez sur 'Nouveau Rappel' pour en ajouter une." />
        ) : (
          upcoming.map((r) => <ReminderRow key={r.id} r={r} />)
        )}
      </Card>

      {done.length > 0 && (
        <Card>
          <div className="p-4 border-b border-slate-100">
            <p className="font-semibold text-slate-500">Terminés</p>
          </div>
          {done.map((r) => <ReminderRow key={r.id} r={r} />)}
        </Card>
      )}

      {showForm && (
        <Modal title="Nouveau Rappel Fiscal" onClose={() => setShowForm(false)}>
          <Field label="Libellé *">
            <input value={form.label} onChange={(e) => setForm({ ...form, label: e.target.value })} className={inputCls} placeholder="Ex: Déclaration TVA T1" />
          </Field>
          <Field label="Date d'échéance *">
            <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} className={inputCls} />
          </Field>
          <Field label="Note (optionnel)">
            <input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className={inputCls} placeholder="Ex: Ne pas oublier les justificatifs" />
          </Field>
          <Btn onClick={save}>Ajouter le Rappel</Btn>
        </Modal>
      )}
    </div>
  );
}

// ---------- Settings ----------
function SettingsPage({ data, persist, showToast, session }) {
  const lang = data.settings.language || "fr";
  const actor = session?.name || "Administrateur";
  const [form, setForm] = useState(data.settings);
  const logoInputRef = useRef(null);
  const adminEmp = data.employees.find((e) => e.role === "Administrateur") || data.employees[0];
  const [adminForm, setAdminForm] = useState({ name: adminEmp?.name || "", email: adminEmp?.email || "", pin: adminEmp?.pin || "" });
  const [syncConfig, setSyncConfig] = useState({ syncEnabled: false, syncFolderPath: null });
  const [syncLoading, setSyncLoading] = useState(false);
  const [printersList, setPrintersList] = useState([]);
  const [loadingPrinters, setLoadingPrinters] = useState(false);

  const refreshPrinters = async () => {
    setLoadingPrinters(true);
    try {
      const printers = await window.erpApi.getPrinters();
      setPrintersList(printers || []);
      if (!printers || printers.length === 0) {
        showToast("Aucune imprimante détectée. Vérifiez qu'une imprimante est installée sur ce PC.", "error");
      }
    } catch (e) {
      showToast("Impossible de récupérer la liste des imprimantes.", "error");
    }
    setLoadingPrinters(false);
  };

  const testPrint = async () => {
    const testInvoice = {
      ref: "TEST-0000",
      date: new Date().toISOString(),
      clientName: "Test d'impression",
      items: [{ name: "Article de test", qty: 1, price: 0 }],
      subtotal: 0,
      discount: 0,
      total: 0,
      payMethod: "Cash",
    };
    await printReceiptDirect(testInvoice, form, showToast);
  };

  const [newSoldeInput, setNewSoldeInput] = useState(data.cashRegister.solde);
  const correctSolde = async () => {
    const newSolde = Number(newSoldeInput) || 0;
    const oldSolde = data.cashRegister.solde || 0;
    const securityLog = logEvent(
      data,
      session?.name || "Administrateur",
      "SOLDE DE CAISSE CORRIGÉ",
      `Solde changé de ${fmtMoney(oldSolde, data.settings.currency)} à ${fmtMoney(newSolde, data.settings.currency)}.`
    );
    await persist({ ...data, cashRegister: { ...data.cashRegister, solde: newSolde }, securityLog });
    showToast("Solde de caisse corrigé.");
  };

  useEffect(() => {
    window.erpApi.getSyncConfig().then((cfg) => cfg && setSyncConfig(cfg));
  }, []);

  const enableCloudSync = async () => {
    const folder = await window.erpApi.chooseSyncFolder();
    if (!folder) return;
    setSyncLoading(true);
    const ok = await window.erpApi.setSyncConfig(folder, true);
    setSyncLoading(false);
    if (ok) {
      showToast("Synchronisation Cloud activée. Redémarrage des données...");
      setTimeout(() => window.location.reload(), 900);
    } else {
      showToast("Impossible d'activer la synchronisation.", "error");
    }
  };

  const disableCloudSync = async () => {
    if (!window.confirm("Désactiver la synchronisation Cloud ? L'application repassera en stockage local uniquement.")) return;
    setSyncLoading(true);
    const ok = await window.erpApi.setSyncConfig(syncConfig.syncFolderPath, false);
    setSyncLoading(false);
    if (ok) {
      showToast("Synchronisation Cloud désactivée.");
      setTimeout(() => window.location.reload(), 900);
    }
  };


  const saveAdmin = async () => {
    if (!adminForm.name || !/^\d{4}$/.test(adminForm.pin)) {
      return showToast("Nom requis et code PIN à 4 chiffres.", "error");
    }
    const employees = data.employees.map((e) =>
      e.id === adminEmp.id ? { ...e, name: adminForm.name, email: adminForm.email, pin: adminForm.pin } : e
    );
    const securityLog = logEvent(data, actor, "COMPTE ADMINISTRATEUR MODIFIÉ", "Les informations du compte administrateur principal ont été mises à jour.");
    await persist({ ...data, employees, securityLog });
    showToast("Compte administrateur mis à jour.");
  };

  const save = async () => {
    const securityLog = logEvent(data, actor, "PARAMÈTRES MODIFIÉS", "Les paramètres de l'établissement ont été mis à jour.");
    await persist({ ...data, settings: form, securityLog });
    showToast("Paramètres enregistrés.");
  };

  const handleLogoUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1024 * 1024) return showToast("Image trop lourde (max 1 Mo).", "error");
    const reader = new FileReader();
    reader.onload = () => setForm((f) => ({ ...f, logo: reader.result }));
    reader.readAsDataURL(file);
  };
  const removeLogo = () => setForm((f) => ({ ...f, logo: null }));

  const resetDemo = async () => {
    if (!window.confirm("Réinitialiser toutes les données vers la démo initiale ? Cette action est irréversible.")) return;
    const fresh = demoData();
    fresh.securityLog = logEvent(fresh, actor, "RÉINITIALISATION BASE DE DONNÉES", "La base de données a été réinitialisée vers le catalogue de démonstration.");
    await persist(fresh);
    showToast("Catalogue de démonstration restauré.");
  };

  const backupNow = async () => {
    try {
      const ok = await window.erpApi.exportBackup(JSON.stringify(data, null, 2));
      if (ok) {
        await persist({ ...data, securityLog: logEvent(data, actor, "SAUVEGARDE EXPORTÉE", "Une sauvegarde des données a été exportée vers un fichier.") });
        showToast("Sauvegarde exportée avec succès.");
      }
    } catch (e) {
      showToast("Échec de la sauvegarde.", "error");
    }
  };

  const restoreBackup = async () => {
    try {
      const raw = await window.erpApi.importBackup();
      if (!raw) return;
      const parsed = normalizeData(JSON.parse(raw));
      if (!window.confirm("Remplacer toutes les données actuelles par cette sauvegarde ?")) return;
      await persist(parsed);
      showToast("Sauvegarde restaurée avec succès.");
    } catch (e) {
      showToast("Fichier de sauvegarde invalide.", "error");
    }
  };

  return (
    <div>
      <PageHeader title={t(lang, "page_settings_title")} subtitle={t(lang, "page_settings_subtitle")} />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Card className="p-5 lg:col-span-2">
          <p className="font-semibold mb-4 flex items-center gap-2"><Building2 size={18} /> {t(lang, "settings_profile_header")}</p>
          <Field label="Logo de l'entreprise">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-lg bg-slate-100 border border-slate-200 flex items-center justify-center overflow-hidden shrink-0">
                {form.logo ? <img src={form.logo} alt="logo" className="w-full h-full object-cover" /> : <Building2 size={22} className="text-slate-300" />}
              </div>
              <Btn variant="outline" onClick={() => logoInputRef.current?.click()}>Télécharger</Btn>
              {form.logo && <Btn variant="danger" onClick={removeLogo}>Supprimer</Btn>}
              <input ref={logoInputRef} type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
            </div>
          </Field>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
            <Field label="Dénomination Sociale *"><input value={form.companyName} onChange={(e) => setForm({ ...form, companyName: e.target.value })} className={inputCls} /></Field>
            <Field label="Couleur principale"><input type="color" value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} className={inputCls + " h-10"} /></Field>
            <Field label="Téléphone Établissement"><input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className={inputCls} /></Field>
            <Field label="Couleur secondaire"><input type="color" value={form.secondaryColor || "#64748b"} onChange={(e) => setForm({ ...form, secondaryColor: e.target.value })} className={inputCls + " h-10"} /></Field>
            <Field label="Adresse E-mail de contact"><input value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} className={inputCls} /></Field>
            <Field label="Adresse Siège / Point de vente"><input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className={inputCls} /></Field>
            <Field label="ICE (Identifiant Commun) *"><input value={form.ice} onChange={(e) => setForm({ ...form, ice: e.target.value })} className={inputCls} /></Field>
            <Field label="N° Identifiant Fiscal (IF) *"><input value={form.ifisc} onChange={(e) => setForm({ ...form, ifisc: e.target.value })} className={inputCls} /></Field>
            <Field label="N° Patente *"><input value={form.patente} onChange={(e) => setForm({ ...form, patente: e.target.value })} className={inputCls} /></Field>
            <Field label="RC (Registre de Commerce)"><input value={form.rc || ""} onChange={(e) => setForm({ ...form, rc: e.target.value })} className={inputCls} placeholder="Ex: 123456" /></Field>
            <Field label="N° CNSS"><input value={form.cnss || ""} onChange={(e) => setForm({ ...form, cnss: e.target.value })} className={inputCls} placeholder="Ex: 1234567" /></Field>
            <Field label="RIB (Compte Bancaire)"><input value={form.rib || ""} onChange={(e) => setForm({ ...form, rib: e.target.value })} className={inputCls} placeholder="Ex: 001 810 0001234567890123 45" /></Field>
            <Field label="Devise monétaire (ex: DH, EUR)"><input value={form.currency} onChange={(e) => setForm({ ...form, currency: e.target.value })} className={inputCls} /></Field>
            <Field label="Taux de TVA par défaut (%)"><input type="number" value={form.tvaRate} onChange={(e) => setForm({ ...form, tvaRate: e.target.value })} className={inputCls} /></Field>
            <Field label="Prix de Livraison par défaut (DH)"><input type="number" value={form.defaultDeliveryFee || 0} onChange={(e) => setForm({ ...form, defaultDeliveryFee: e.target.value })} className={inputCls} /></Field>
          </div>

          <p className="text-xs font-medium text-slate-600 mb-2">Thèmes Rapides</p>
          <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 mb-4">
            {THEME_PRESETS.map((theme) => (
              <button
                key={theme.name}
                type="button"
                title={theme.name}
                onClick={() => setForm({ ...form, color: theme.primary, secondaryColor: theme.secondary })}
                className={`h-10 rounded-lg border-2 transition-all ${
                  form.color === theme.primary && form.secondaryColor === theme.secondary ? "border-slate-900 scale-105" : "border-transparent hover:scale-105"
                }`}
                style={{ background: `linear-gradient(135deg, ${theme.primary} 50%, ${theme.secondary} 50%)` }}
              />
            ))}
          </div>
          <Btn icon={Check} onClick={save}>Enregistrer les Paramètres</Btn>
        </Card>

        <div className="space-y-5">
          <Card className="p-5">
            <p className="font-semibold mb-4 flex items-center gap-2"><Globe size={18} /> {t(lang, "settings_language_header")}</p>
            <p className="text-xs text-slate-500 mb-3">{t(lang, "settings_language_label")}</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={async () => { await persist({ ...data, settings: { ...data.settings, language: "fr" } }); }}
                className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium border transition-colors ${
                  lang === "fr" ? "bg-slate-900 text-white border-slate-900" : "border-slate-200 text-slate-600 hover:bg-slate-50"
                }`}
              >
                🇫🇷 {t(lang, "lang_fr")}
              </button>
              <button
                onClick={async () => { await persist({ ...data, settings: { ...data.settings, language: "ar" } }); }}
                className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-medium border transition-colors ${
                  lang === "ar" ? "bg-slate-900 text-white border-slate-900" : "border-slate-200 text-slate-600 hover:bg-slate-50"
                }`}
              >
                🇲🇦 {t(lang, "lang_ar")}
              </button>
            </div>
          </Card>

          <Card className="p-5">
            <p className="font-semibold mb-4 flex items-center gap-2"><Download size={18} /> {t(lang, "settings_storage_header")}</p>
            <div className="flex items-center justify-between mb-3">
              <span className="text-sm text-slate-600">Mode Local (Hors ligne)</span>
              <span className="w-10 h-5 rounded-full bg-blue-600 relative"><span className="absolute right-0.5 top-0.5 w-4 h-4 bg-white rounded-full" /></span>
            </div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-slate-600">Synchronisation (Réseau Local ou Cloud)</span>
              <button
                onClick={() => (syncConfig.syncEnabled ? disableCloudSync() : enableCloudSync())}
                disabled={syncLoading}
                className={`w-10 h-5 rounded-full relative transition-colors ${syncConfig.syncEnabled ? "bg-blue-600" : "bg-slate-300"}`}
              >
                <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full transition-all ${syncConfig.syncEnabled ? "right-0.5" : "left-0.5"}`} />
              </button>
            </div>
            {syncConfig.syncEnabled && syncConfig.syncFolderPath && (
              <p className="text-[11px] text-emerald-600 mb-3 break-all">📁 Synchronisé via : {syncConfig.syncFolderPath} — les autres PC verront vos ventes automatiquement (quelques secondes de délai).</p>
            )}
            {!syncConfig.syncEnabled && (
              <p className="text-[11px] text-slate-400 mb-3">
                Active la synchronisation en choisissant un <strong>dossier partagé sur votre réseau local</strong> (même WiFi/Box) pour utiliser plusieurs PC ensemble, ou un dossier Google Drive/Dropbox/OneDrive pour synchroniser via internet — les autres postes pointant vers le même dossier partageront automatiquement les mêmes données.
              </p>
            )}
            <p className="text-xs text-slate-400 mb-4">Vos données sont enregistrées automatiquement sur cet ordinateur (aucune connexion internet requise).</p>
            <div className="space-y-2">
              <Btn onClick={backupNow} icon={Download} variant="success">Sauvegarder maintenant</Btn>
              <Btn onClick={restoreBackup} icon={Package} variant="outline">Restaurer une sauvegarde</Btn>
            </div>
          </Card>
          <Card className="p-5 border-red-100">
            <p className="font-semibold mb-2 flex items-center gap-2 text-red-600"><AlertTriangle size={18} /> {t(lang, "settings_danger_header")}</p>
            <p className="text-xs text-slate-500 mb-3">Utilitaires d'administration pour réinitialiser la base de données vers le catalogue de démonstration initial.</p>
            <Btn variant="danger" onClick={resetDemo}>Réinitialiser le catalogue démo</Btn>
          </Card>
        </div>
      </div>

      <Card className="p-5 mt-5">
        <p className="font-semibold mb-4 flex items-center gap-2"><Users size={18} /> {t(lang, "settings_admin_header")}</p>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-x-4">
          <Field label="Nom Complet Administrateur *">
            <input value={adminForm.name} onChange={(e) => setAdminForm({ ...adminForm, name: e.target.value })} className={inputCls} />
          </Field>
          <Field label="Adresse E-mail de Connexion *">
            <input value={adminForm.email} onChange={(e) => setAdminForm({ ...adminForm, email: e.target.value })} className={inputCls} />
          </Field>
          <Field label="Code Secret de Caisse / Code PIN (4 chiffres) *">
            <input value={adminForm.pin} maxLength={4} onChange={(e) => setAdminForm({ ...adminForm, pin: e.target.value.replace(/\D/g, "") })} className={inputCls} />
          </Field>
        </div>
        <p className="text-xs text-slate-400 mb-3">Ce code PIN à 4 chiffres sert à s'authentifier à la caisse POS et à déverrouiller les modules sensibles.</p>
        <Btn icon={Check} onClick={saveAdmin}>Mettre à jour le Compte Administrateur</Btn>
      </Card>

      <Card className="p-5 mt-5">
        <p className="font-semibold mb-1 flex items-center gap-2"><FileText size={18} /> Format de Papier (Factures, Devis, BL)</p>
        <p className="text-xs text-slate-500 mb-4">
          Choisissez le format utilisé pour générer les Factures, Devis et Bons de Livraison en PDF — A4 (feuille
          standard) ou A5 (demi-feuille, plus économique en papier).
        </p>
        <div className="grid grid-cols-2 gap-2 max-w-sm">
          {[["a4", "A4 (210 × 297 mm)"], ["a5", "A5 (148 × 210 mm)"]].map(([val, label]) => (
            <button
              key={val}
              type="button"
              onClick={() => setForm({ ...form, paperFormat: val })}
              className={`py-2 rounded-lg text-sm font-medium border ${
                (form.paperFormat || "a4") === val ? "bg-slate-900 text-white border-slate-900" : "border-slate-200 text-slate-600"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        <div className="mt-3">
          <Btn icon={Check} onClick={save}>Enregistrer</Btn>
        </div>
      </Card>

      <Card className="p-5 mt-5">
        <p className="font-semibold mb-1 flex items-center gap-2"><Printer size={18} /> Impression du Ticket de Caisse</p>
        <p className="text-xs text-slate-500 mb-4">Choisissez combien d'exemplaires du ticket sont générés à chaque impression (ex: 1 pour le client, 2 pour garder une copie interne).</p>
        <div className="grid grid-cols-3 gap-2 max-w-sm">
          {[1, 2, 3].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setForm({ ...form, receiptCopies: n })}
              className={`py-2.5 rounded-lg text-sm font-medium border ${
                (form.receiptCopies || 1) === n ? "bg-slate-900 text-white border-slate-900" : "border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}
            >
              {n} exemplaire{n > 1 ? "s" : ""}
            </button>
          ))}
        </div>
        <div className="mt-4">
          <Btn icon={Check} onClick={save}>Enregistrer</Btn>
        </div>
      </Card>

      <Card className="p-5 mt-5">
        <p className="font-semibold mb-1 flex items-center gap-2"><Printer size={18} /> Imprimante Thermique</p>
        <p className="text-xs text-slate-500 mb-4">
          Choisissez l'imprimante de tickets à utiliser par défaut. Une fois configurée, vous pouvez imprimer directement dessus
          sans repasser par la fenêtre de sélection à chaque vente.
        </p>

        <div className="flex gap-2 mb-3">
          <Btn variant="outline" icon={RefreshCw} onClick={refreshPrinters} disabled={loadingPrinters}>
            {loadingPrinters ? "Recherche..." : "Détecter les Imprimantes"}
          </Btn>
        </div>

        {printersList.length > 0 && (
          <Field label="Imprimante par défaut">
            <select
              value={form.defaultPrinterName || ""}
              onChange={(e) => setForm({ ...form, defaultPrinterName: e.target.value })}
              className={inputCls}
            >
              <option value="">— Toujours demander (afficher la fenêtre de choix) —</option>
              {printersList.map((p) => (
                <option key={p.name} value={p.name}>{p.name}{p.isDefault ? " (par défaut Windows)" : ""}</option>
              ))}
            </select>
          </Field>
        )}

        {form.defaultPrinterName && (
          <label className="flex items-center gap-2 mb-3 text-sm text-slate-600 cursor-pointer">
            <input
              type="checkbox"
              checked={!!form.silentPrint}
              onChange={(e) => setForm({ ...form, silentPrint: e.target.checked })}
              className="w-4 h-4"
            />
            Imprimer directement sans afficher de fenêtre (impression silencieuse)
          </label>
        )}

        <div className="flex gap-2 mt-2">
          <Btn icon={Check} onClick={save}>Enregistrer</Btn>
          <Btn variant="outline" icon={Printer} onClick={testPrint}>Tester l'Impression</Btn>
        </div>

        <p className="text-[11px] text-slate-400 mt-3 italic">
          Astuce : l'imprimante thermique doit d'abord être installée normalement dans Windows (avec son pilote) avant
          d'apparaître ici. Cliquez sur "Détecter les Imprimantes" une fois que c'est fait.
        </p>
      </Card>

      <Card className="p-5 mt-5">
        <p className="font-semibold mb-1 flex items-center gap-2"><Wallet size={18} /> Solde de la Caisse</p>
        <p className="text-xs text-slate-500 mb-4">
          Le solde se met à jour automatiquement à chaque vente encaissée (+) et chaque dépense (−). Si le solde affiché ne
          correspond pas à l'argent réel dans votre caisse, vous pouvez le corriger manuellement ici.
        </p>
        <div className="flex items-end gap-3">
          <Field label="Solde Actuel">
            <p className={`text-lg font-mono font-bold ${data.cashRegister.solde < 0 ? "text-red-600" : "text-emerald-600"}`}>
              {fmtMoney(data.cashRegister.solde, data.settings.currency)}
            </p>
          </Field>
          <Field label="Nouveau Solde">
            <input type="number" value={newSoldeInput} onChange={(e) => setNewSoldeInput(e.target.value)} className={inputClsW("w-40")} />
          </Field>
          <Btn icon={Check} onClick={correctSolde}>Corriger le Solde</Btn>
        </div>
        <p className="text-[11px] text-slate-400 mt-3 italic">
          Cette correction est enregistrée dans le Journal de Sécurité pour garder une trace.
        </p>
      </Card>

      <Card className="p-5 mt-5">
        <p className="font-semibold mb-1 flex items-center gap-2"><ShoppingCart size={18} /> Module Caisse Enregistreuse (POS)</p>
        <p className="text-xs text-slate-500 mb-4">
          Désactivez ce module si votre activité ne fait pas de vente directe au comptoir — le menu "Caisse
          Enregistreuse" disparaîtra.
        </p>
        <label className="flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
          <input
            type="checkbox"
            checked={form.posEnabled !== false}
            onChange={(e) => setForm({ ...form, posEnabled: e.target.checked })}
            className="w-4 h-4"
          />
          Activer la Caisse Enregistreuse
        </label>
        <div className="mt-3">
          <Btn icon={Check} onClick={save}>Enregistrer</Btn>
        </div>
      </Card>

      <Card className="p-5 mt-5">
        <p className="font-semibold mb-1 flex items-center gap-2"><ShoppingCart size={18} /> Options de la Caisse</p>
        <p className="text-xs text-slate-500 mb-4">Décochez les options que vous n'utilisez pas — elles disparaîtront de l'écran de la Caisse pour la simplifier.</p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          <div>
            <p className="text-xs font-semibold text-slate-500 mb-2 uppercase">Remises & Promotions</p>
            <div className="space-y-1.5">
              {["Aucune", "% Pourcentage", "Valeur Fixe"].map((opt) => (
                <label key={opt} className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.enabledDiscountTypes?.[opt] !== false}
                    onChange={(e) => setForm({ ...form, enabledDiscountTypes: { ...form.enabledDiscountTypes, [opt]: e.target.checked } })}
                    className="w-4 h-4"
                  />
                  {opt}
                </label>
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold text-slate-500 mb-2 uppercase">Logistique & Livraison</p>
            <div className="space-y-1.5">
              {["Emporté", "Gratuite", "Payante"].map((opt) => (
                <label key={opt} className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.enabledDeliveryOptions?.[opt] !== false}
                    onChange={(e) => setForm({ ...form, enabledDeliveryOptions: { ...form.enabledDeliveryOptions, [opt]: e.target.checked } })}
                    className="w-4 h-4"
                  />
                  {opt}
                </label>
              ))}
            </div>
          </div>

          <div>
            <p className="text-xs font-semibold text-slate-500 mb-2 uppercase">Modes de Paiement</p>
            <div className="space-y-1.5">
              {["Cash", "Carte", "Vir.", "Credit", "Mixte"].map((opt) => (
                <label key={opt} className="flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.enabledPaymentMethods?.[opt] !== false}
                    onChange={(e) => setForm({ ...form, enabledPaymentMethods: { ...form.enabledPaymentMethods, [opt]: e.target.checked } })}
                    className="w-4 h-4"
                  />
                  {opt === "Vir." ? "Virement" : opt === "Cash" ? "Cash (Espèces)" : opt}
                </label>
              ))}
            </div>
          </div>
        </div>

        <p className="text-[11px] text-slate-400 mt-4 italic">Astuce : si vous décochez tout dans une catégorie, une option de secours reste automatiquement disponible pour ne jamais bloquer la Caisse.</p>

        <div className="mt-4">
          <Btn icon={Check} onClick={save}>Enregistrer</Btn>
        </div>
      </Card>

      <Card className="p-5 mt-5">
        <p className="font-semibold mb-1 flex items-center gap-2"><FileText size={18} /> Numérotation des Documents</p>
        <p className="text-xs text-slate-500 mb-4">Personnalisez le préfixe et le numéro de départ de chaque type de document, indépendamment.</p>
        <div className="space-y-3 mb-4">
          {[
            ["invoice", "Factures"],
            ["quote", "Devis"],
            ["delivery", "Bons de Livraison"],
            ["return", "Retours"],
            ["purchase", "Achats"],
          ].map(([key, label]) => (
            <div key={key} className="grid grid-cols-1 sm:grid-cols-4 gap-3 items-end bg-slate-50 rounded-lg p-3">
              <p className="text-sm font-medium text-slate-700 sm:col-span-1">{label}</p>
              <Field label="Préfixe">
                <input
                  value={(form.refPrefixes && form.refPrefixes[key]) || ""}
                  onChange={(e) => setForm({ ...form, refPrefixes: { ...form.refPrefixes, [key]: e.target.value.toUpperCase() } })}
                  className={inputCls}
                  maxLength={8}
                  placeholder="Préfixe"
                />
              </Field>
              <Field label="Numéro de départ">
                <input
                  type="number"
                  min={1}
                  value={(form.refStartNumbers && form.refStartNumbers[key]) || 1}
                  onChange={(e) => setForm({ ...form, refStartNumbers: { ...form.refStartNumbers, [key]: e.target.value } })}
                  className={inputCls}
                />
              </Field>
              <div>
                <p className="text-[10px] text-slate-400 mb-1">Aperçu</p>
                <p className="text-sm font-mono font-semibold text-slate-800">{makeRef(form, key, 0)}</p>
              </div>
            </div>
          ))}
        </div>
        <label className="flex items-center gap-2 mb-4 text-sm text-slate-600 cursor-pointer">
          <input
            type="checkbox"
            checked={form.refIncludeYear !== false}
            onChange={(e) => setForm({ ...form, refIncludeYear: e.target.checked })}
            className="w-4 h-4"
          />
          Inclure l'année dans le numéro (ex: FAC-2026-00001)
        </label>
        <Btn icon={Check} onClick={save}>Enregistrer la Numérotation</Btn>
      </Card>
    </div>
  );
}
