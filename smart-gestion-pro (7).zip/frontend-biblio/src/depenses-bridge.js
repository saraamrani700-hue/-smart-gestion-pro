/**
 * DEPENSES-BRIDGE — relie les depenses de l'appli Bibliotheque a la vraie
 * table Depenses de Smart Gestion Pro (module cree pour cette migration,
 * aucun equivalent n'existait auparavant cote serveur).
 */
(function () {
  function api(path, options = {}) {
    const token = localStorage.getItem('sgp_token') || sessionStorage.getItem('sgp_token');
    const base = window.SGP_API_BASE || (window.location.origin + '/api');
    return fetch(base + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: 'Bearer ' + token } : {}),
        ...(options.headers || {}),
      },
    }).then(async (res) => {
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error((body && body.message) || `Erreur HTTP ${res.status}`);
      return body;
    });
  }

  function versFormeBibliotheque(d) {
    return {
      id: d.id,
      date: d.dateDepense,
      title: d.titre,
      category: d.categorie,
      amount: Number(d.montant) || 0,
      note: d.note || "",
    };
  }

  async function chargerDepensesReelles() {
    const depenses = await api('/depenses');
    return depenses.map(versFormeBibliotheque);
  }

  async function creerDepenseReelle(champs) {
    const cree = await api('/depenses', {
      method: 'POST',
      body: JSON.stringify({
        titre: champs.title,
        categorie: champs.category,
        montant: Number(champs.amount) || 0,
        note: champs.note || undefined,
      }),
    });
    return versFormeBibliotheque(cree);
  }

  async function supprimerDepenseReelle(id) {
    await api(`/depenses/${id}`, { method: 'DELETE' });
  }

  window.depensesBridge = { chargerDepensesReelles, creerDepenseReelle, supprimerDepenseReelle };
})();
