/**
 * ============================================================================
 * PRODUITS-BRIDGE — relie le catalogue produits de l'appli Bibliotheque a la
 * vraie base de donnees relationnelle Smart Gestion Pro (au lieu du bloc
 * JSON). Point d'entree UNIQUE pour toute lecture/ecriture de produits ;
 * le reste de App.jsx continue de lire `data.products` comme un tableau
 * normal (aucun des 43 emplacements de lecture existants n'a besoin de changer).
 * ============================================================================
 */
(function () {
  function api(path, options = {}) {
    const token = localStorage.getItem('sgp_token') || sessionStorage.getItem('sgp_token');
    const base = window.SGP_API_BASE || (window.location.origin + '/api');
    return fetch(base + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: 'Bearer ' + token } : {}),
        ...(options.headers || {}),
      },
    }).then(async (res) => {
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error((body && body.message) || `Erreur HTTP ${res.status}`);
      return body;
    });
  }

  let succursaleParDefautId = null;
  async function obtenirSuccursaleParDefaut() {
    if (succursaleParDefautId) return succursaleParDefautId;
    const succursales = await api('/entreprises/succursales');
    succursaleParDefautId = succursales[0]?.id || null;
    return succursaleParDefautId;
  }

  // ---- Traduction produit reel (Smart Gestion Pro) -> forme attendue par l'appli Bibliotheque ----
  function versFormeBibliotheque(produit, quantiteStock) {
    return {
      id: produit.id,
      name: produit.nom,
      brand: produit.marque || "",
      category: produit.categorie?.nom || "",
      barcode: produit.codeBarre || "",
      buyPrice: Number(produit.prixAchatHt) || 0,
      sellPrice: Number(produit.prixVenteHt) || 0,
      stock: quantiteStock,
      alertThreshold: Number(produit.seuilAlerte) || 5,
      location: produit.rayon || "",
      expiryDate: produit.dateExpiration || "",
      image: null, // Les images ne sont pas encore synchronisees (voir DEPLOIEMENT.md)
    };
  }

  async function chargerProduitsReels() {
    const [produits] = await Promise.all([api('/produits')]);
    const avecStock = await Promise.all(
      produits.map(async (p) => {
        try {
          const stocks = await api(`/produits/${p.id}/stock`);
          const total = stocks.reduce((s, x) => s + Number(x.quantite), 0);
          return versFormeBibliotheque(p, total);
        } catch (e) {
          return versFormeBibliotheque(p, 0);
        }
      }),
    );
    return avecStock;
  }

  async function creerProduitReel(champsBibliotheque) {
    const succursaleId = await obtenirSuccursaleParDefaut();
    const cree = await api('/produits', {
      method: 'POST',
      body: JSON.stringify({
        nom: champsBibliotheque.name,
        marque: champsBibliotheque.brand || undefined,
        codeBarre: champsBibliotheque.barcode || undefined,
        prixAchatHt: Number(champsBibliotheque.buyPrice) || 0,
        prixVenteHt: Number(champsBibliotheque.sellPrice) || 0,
        seuilAlerte: Number(champsBibliotheque.alertThreshold) || 5,
        rayon: champsBibliotheque.location || undefined,
        dateExpiration: champsBibliotheque.expiryDate || undefined,
      }),
    });
    const stockInitial = Number(champsBibliotheque.stock) || 0;
    if (stockInitial > 0 && succursaleId) {
      await api('/produits/stock/ajuster', {
        method: 'POST',
        body: JSON.stringify({ produitId: cree.id, succursaleId, type: 'entree', quantite: stockInitial, motif: 'Creation produit (import/saisie)' }),
      });
    }
    return versFormeBibliotheque(cree, stockInitial);
  }

  async function modifierProduitReel(id, champsBibliotheque) {
    const modifie = await api(`/produits/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({
        nom: champsBibliotheque.name,
        marque: champsBibliotheque.brand || undefined,
        codeBarre: champsBibliotheque.barcode || undefined,
        prixAchatHt: Number(champsBibliotheque.buyPrice) || 0,
        prixVenteHt: Number(champsBibliotheque.sellPrice) || 0,
        seuilAlerte: Number(champsBibliotheque.alertThreshold) || 5,
        rayon: champsBibliotheque.location || undefined,
        dateExpiration: champsBibliotheque.expiryDate || undefined,
      }),
    });
    return versFormeBibliotheque(modifie, Number(champsBibliotheque.stock) || 0);
  }

  async function supprimerProduitReel(id) {
    await api(`/produits/${id}`, { method: 'DELETE' });
  }

  // ---- Synchronisation du STOCK : point d'entree centralise -------------
  // Appele depuis un seul endroit (persist(), voir App.jsx) plutot que
  // depuis les 9 endroits ou l'appli modifie p.stock — beaucoup plus sur.
  async function synchroniserStock(produitsAvant, produitsApres) {
    const succursaleId = await obtenirSuccursaleParDefaut();
    if (!succursaleId) return;

    const avantParId = new Map(produitsAvant.map((p) => [p.id, p.stock]));
    for (const produit of produitsApres) {
      const stockAvant = avantParId.get(produit.id);
      const stockApres = Number(produit.stock) || 0;
      if (stockAvant === undefined || Number(stockAvant) === stockApres) continue;
      try {
        await api('/produits/stock/ajuster', {
          method: 'POST',
          body: JSON.stringify({
            produitId: produit.id,
            succursaleId,
            type: 'inventaire',
            quantite: stockApres,
            motif: 'Synchronisation automatique (operation caisse/achat/retour)',
          }),
        });
      } catch (e) {
        console.error('Synchronisation stock echouee pour', produit.name, e.message);
      }
    }
  }

  // ---- Enregistrement REEL des ventes (en plus du bloc JSON, pas a la ----
  // ---- place, pour ne rien casser dans l'affichage/impression existants) --
  async function creerVenteReelle(cart, clientId) {
    const succursaleId = await obtenirSuccursaleParDefaut();
    if (!succursaleId) return null;

    const lignes = cart
      .filter((it) => it.productId) // ignore les lignes "service" sans produit reel
      .map((it) => ({
        produitId: it.productId,
        quantite: Number(it.qty) || 1,
        prixUnitaireHt: Number(it.price) || 0,
        tauxTva: 20,
      }));
    if (lignes.length === 0) return null; // vente uniquement de services : rien a enregistrer cote Produits/Ventes

    try {
      return await api('/ventes', {
        method: 'POST',
        body: JSON.stringify({ succursaleId, clientId: clientId || undefined, lignes }),
      });
    } catch (e) {
      // Ne bloque jamais la vente en caisse : le ticket reste enregistre
      // dans le bloc JSON (source de verite actuelle de l'appli) meme si
      // l'enregistrement miroir cote base de donnees echoue.
      console.error('Enregistrement de la vente (base de donnees) echoue:', e.message);
      return null;
    }
  }

  // ---- FOURNISSEURS : meme principe que les produits ---------------------
  function versFormeBibliothequeFournisseur(f) {
    return {
      id: f.id,
      name: f.nom,
      phone: f.telephone || "",
      email: f.email || "",
      address: f.adresse || "",
      debt: Number(f.solde) || 0,
    };
  }

  async function chargerFournisseursReels() {
    const fournisseurs = await api('/fournisseurs');
    return fournisseurs.map(versFormeBibliothequeFournisseur);
  }

  async function creerFournisseurReel(champs) {
    const cree = await api('/fournisseurs', {
      method: 'POST',
      body: JSON.stringify({
        nom: champs.name,
        telephone: champs.phone || undefined,
        email: champs.email || undefined,
        adresse: champs.address || undefined,
      }),
    });
    return versFormeBibliothequeFournisseur(cree);
  }

  async function modifierFournisseurReel(id, champs) {
    const modifie = await api(`/fournisseurs/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({
        nom: champs.name,
        telephone: champs.phone || undefined,
        email: champs.email || undefined,
        adresse: champs.address || undefined,
      }),
    });
    return versFormeBibliothequeFournisseur(modifie);
  }

  async function supprimerFournisseurReel(id) {
    await api(`/fournisseurs/${id}`, { method: 'DELETE' });
  }

  // ---- Enregistrement REEL des achats (meme principe que les ventes) ----
  async function creerAchatReel(items, fournisseurId) {
    const succursaleId = await obtenirSuccursaleParDefaut();
    if (!succursaleId) return null;

    const lignes = items
      .filter((it) => it.productId)
      .map((it) => ({
        produitId: it.productId,
        quantite: Number(it.qty) || 1,
        prixUnitaireHt: Number(it.price) || 0,
        tauxTva: 20,
      }));
    if (lignes.length === 0) return null;

    try {
      return await api('/achats', {
        method: 'POST',
        body: JSON.stringify({ succursaleId, fournisseurId: fournisseurId || undefined, lignes }),
      });
    } catch (e) {
      console.error("Enregistrement de l'achat (base de donnees) echoue:", e.message);
      return null;
    }
  }

  // ---- BONS DE COMMANDE FOURNISSEUR ----------------------------------
  function bonCommandeVersBibliotheque(b) {
    return {
      id: b.id,
      ref: b.numero,
      date: b.createdAt,
      supplierId: b.fournisseurId,
      total: Number(b.totalTtc) || 0,
      status: b.statut === 'recu' ? 'Reçu' : 'En attente',
      items: (b.lignes || []).map((l) => ({
        productId: l.produitId,
        name: l.produit?.nom || l.designation,
        qty: Number(l.quantite) || 0,
        price: Number(l.prixUnitaireHt) || 0,
      })),
    };
  }

  async function chargerBonsCommandeReels() {
    const bons = await api('/bons-commande');
    return bons.map(bonCommandeVersBibliotheque);
  }

  async function creerBonCommandeReel(items, fournisseurId) {
    const lignes = items.filter((it) => it.productId).map((it) => ({
      produitId: it.productId, quantite: Number(it.qty) || 1, prixUnitaireHt: Number(it.price) || 0,
    }));
    if (lignes.length === 0) return null;
    const cree = await api('/bons-commande', {
      method: 'POST',
      body: JSON.stringify({ fournisseurId: fournisseurId || undefined, lignes }),
    });
    return bonCommandeVersBibliotheque(cree);
  }

  async function marquerBonCommandeRecuReel(id) {
    try {
      await api(`/bons-commande/${id}/recu`, { method: 'PATCH' });
    } catch (e) {
      console.error('Marquage "recu" du bon de commande echoue:', e.message);
    }
  }

  async function supprimerBonCommandeReel(id) {
    await api(`/bons-commande/${id}`, { method: 'DELETE' });
  }

  // ---- Documents commerciaux reels (Devis, BL, Avoir) --------------------
  // Le module Facturation de Smart Gestion Pro ne touche jamais au stock
  // (contrairement a Ventes/Achats) : aucun risque de double effet a gerer
  // ici, ces appels sont independants de la synchronisation de stock.
  async function creerDocumentReel(type, clientId, items) {
    const lignes = items
      .filter((it) => it.productId)
      .map((it) => ({
        produitId: it.productId,
        designation: it.name,
        quantite: Number(it.qty) || 1,
        prixUnitaireHt: Number(it.price) || 0,
        tauxTva: 20,
      }));
    if (lignes.length === 0) return null;
    try {
      return await api('/facturation/documents', {
        method: 'POST',
        body: JSON.stringify({ type, clientId: clientId || undefined, lignes }),
      });
    } catch (e) {
      console.error(`Enregistrement du document (${type}) [base de donnees] echoue:`, e.message);
      return null;
    }
  }

  // ---- SERVICES (photocopie, reliure...) : reutilise Produits avec -------
  // ---- type=service et gereStock=false, deja supporte par le backend -----
  function serviceVersBibliotheque(p) {
    return { id: p.id, name: p.nom, category: p.categorie?.nom || "Autre", price: Number(p.prixVenteHt) || 0 };
  }

  async function chargerServicesReels() {
    const services = await api('/produits?type=service');
    return services.map(serviceVersBibliotheque);
  }

  async function creerServiceReel(champs) {
    const cree = await api('/produits', {
      method: 'POST',
      body: JSON.stringify({ nom: champs.name, prixVenteHt: Number(champs.price) || 0, type: 'service', gereStock: false }),
    });
    return serviceVersBibliotheque(cree);
  }

  async function modifierServiceReel(id, champs) {
    const modifie = await api(`/produits/${id}`, {
      method: 'PATCH',
      body: JSON.stringify({ nom: champs.name, prixVenteHt: Number(champs.price) || 0 }),
    });
    return serviceVersBibliotheque(modifie);
  }

  async function supprimerServiceReel(id) {
    await api(`/produits/${id}`, { method: 'DELETE' });
  }

  window.produitsBridge = {
    chargerProduitsReels,
    creerProduitReel,
    modifierProduitReel,
    supprimerProduitReel,
    synchroniserStock,
    creerVenteReelle,
    creerAchatReel,
    chargerFournisseursReels,
    creerFournisseurReel,
    modifierFournisseurReel,
    supprimerFournisseurReel,
    chargerBonsCommandeReels,
    creerBonCommandeReel,
    marquerBonCommandeRecuReel,
    supprimerBonCommandeReel,
    creerDocumentReel,
    chargerServicesReels,
    creerServiceReel,
    modifierServiceReel,
    supprimerServiceReel,
  };
})();
