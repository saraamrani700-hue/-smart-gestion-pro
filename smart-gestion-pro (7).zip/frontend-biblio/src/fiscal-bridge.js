/**
 * FISCAL-BRIDGE — Calendrier Fiscal + Zakat, deux nouveaux modules backend.
 */
(function () {
  function api(path, options = {}) {
    const token = localStorage.getItem('sgp_token') || sessionStorage.getItem('sgp_token');
    const base = window.SGP_API_BASE || (window.location.origin + '/api');
    return fetch(base + path, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: 'Bearer ' + token } : {}),
        ...(options.headers || {}),
      },
    }).then(async (res) => {
      const body = await res.json().catch(() => null);
      if (!res.ok) throw new Error((body && body.message) || `Erreur HTTP ${res.status}`);
      return body;
    });
  }

  // ---- Calendrier Fiscal ----
  function rappelVersBibliotheque(r) {
    return { id: r.id, label: r.libelle, date: r.dateEcheance, notes: r.notes || "", done: r.termine };
  }
  async function chargerRappelsReels() {
    const rappels = await api('/calendrier-fiscal');
    return rappels.map(rappelVersBibliotheque);
  }
  async function creerRappelReel(champs) {
    const cree = await api('/calendrier-fiscal', {
      method: 'POST',
      body: JSON.stringify({ libelle: champs.label, dateEcheance: champs.date, notes: champs.notes || undefined }),
    });
    return rappelVersBibliotheque(cree);
  }
  async function basculerRappelReel(id, termine) {
    const modifie = await api(`/calendrier-fiscal/${id}`, { method: 'PATCH', body: JSON.stringify({ termine }) });
    return rappelVersBibliotheque(modifie);
  }
  async function supprimerRappelReel(id) {
    await api(`/calendrier-fiscal/${id}`, { method: 'DELETE' });
  }

  // ---- Zakat ----
  function zakatVersBibliotheque(z) {
    return {
      id: z.id,
      date: z.createdAt,
      stockValue: Number(z.valeurStock) || 0,
      cashValue: Number(z.valeurCaisse) || 0,
      clientReceivables: Number(z.creancesClients) || 0,
      supplierDebts: Number(z.dettesFournisseurs) || 0,
      zakatableBase: Number(z.baseZakatable) || 0,
      nisab: Number(z.nisab) || 0,
      rate: Number(z.taux) || 0,
      zakatDue: Number(z.zakatDue) || 0,
    };
  }
  async function chargerZakatReel() {
    const calculs = await api('/zakat');
    return calculs.map(zakatVersBibliotheque);
  }
  async function creerZakatReel(entry) {
    const cree = await api('/zakat', {
      method: 'POST',
      body: JSON.stringify({
        valeurStock: entry.stockValue, valeurCaisse: entry.cashValue,
        creancesClients: entry.clientReceivables, dettesFournisseurs: entry.supplierDebts,
        baseZakatable: entry.zakatableBase, nisab: entry.nisab, taux: entry.rate, zakatDue: entry.zakatDue,
      }),
    });
    return zakatVersBibliotheque(cree);
  }
  async function supprimerZakatReel(id) {
    await api(`/zakat/${id}`, { method: 'DELETE' });
  }

  window.fiscalBridge = {
    chargerRappelsReels, creerRappelReel, basculerRappelReel, supprimerRappelReel,
    chargerZakatReel, creerZakatReel, supprimerZakatReel,
  };
})();
