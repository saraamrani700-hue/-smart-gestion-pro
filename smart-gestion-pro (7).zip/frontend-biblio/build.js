const esbuild = require("esbuild");
const { execSync } = require("child_process");
const path = require("path");

async function main() {
  console.log("→ Compilation du code JavaScript (React)...");
  await esbuild.build({
    entryPoints: [path.join(__dirname, "src", "main.jsx")],
    bundle: true,
    outfile: path.join(__dirname, "dist", "bundle.js"),
    minify: true,
    sourcemap: false,
    platform: "browser",
    target: ["chrome120"],
    loader: { ".js": "jsx" },
    jsx: "automatic",
  });
  console.log("✓ bundle.js généré.");

  console.log("→ Compilation des styles (Tailwind CSS)...");
  execSync(
    `npx tailwindcss -i ./src/styles.css -o ./dist/style.css --minify`,
    { cwd: __dirname, stdio: "inherit" }
  );
  console.log("✓ style.css généré.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
