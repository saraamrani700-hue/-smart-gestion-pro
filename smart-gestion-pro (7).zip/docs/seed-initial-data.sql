-- ============================================================================
-- DONNEES INITIALES (SEED) — a executer une fois les tables creees
-- ============================================================================

-- 1. Catalogue des permissions (module Produits/Stock/Users — les modules
--    implementes a ce stade). A completer au fur et a mesure des prochains
--    modules (ventes.*, achats.*, factures.*, comptabilite.*, etc.)
INSERT INTO permissions (code, module, description) VALUES
    ('users.read',        'users',    'Consulter les utilisateurs'),
    ('users.create',      'users',    'Creer un utilisateur'),
    ('produits.read',     'produits', 'Consulter les produits'),
    ('produits.create',   'produits', 'Creer un produit'),
    ('produits.update',   'produits', 'Modifier un produit'),
    ('produits.delete',   'produits', 'Desactiver un produit'),
    ('stock.read',        'stock',    'Consulter le stock'),
    ('stock.ajuster',     'stock',    'Ajuster le stock (entree/sortie/inventaire)'),
    ('clients.read',      'clients',      'Consulter les clients'),
    ('clients.create',    'clients',      'Creer un client'),
    ('clients.update',    'clients',      'Modifier un client'),
    ('clients.delete',    'clients',      'Desactiver un client'),
    ('fournisseurs.read',   'fournisseurs', 'Consulter les fournisseurs'),
    ('fournisseurs.create', 'fournisseurs', 'Creer un fournisseur'),
    ('fournisseurs.update', 'fournisseurs', 'Modifier un fournisseur'),
    ('fournisseurs.delete', 'fournisseurs', 'Desactiver un fournisseur'),
    ('ventes.read',        'ventes',   'Consulter les ventes'),
    ('ventes.create',      'ventes',   'Creer une vente'),
    ('ventes.annuler',     'ventes',   'Annuler une vente'),
    ('achats.read',        'achats',   'Consulter les achats'),
    ('achats.create',      'achats',   'Creer un achat'),
    ('paiements.read',       'paiements', 'Consulter les paiements'),
    ('paiements.create',     'paiements', 'Enregistrer un paiement'),
    ('paiements.rembourser', 'paiements', 'Effectuer un remboursement'),
    ('banques.read',         'banques',   'Consulter les comptes bancaires'),
    ('banques.create',       'banques',   'Creer un compte bancaire'),
    ('cheques.read',         'cheques',   'Consulter les cheques'),
    ('cheques.create',       'cheques',   'Enregistrer un cheque'),
    ('cheques.encaisser',    'cheques',   'Encaisser ou rejeter un cheque'),
    ('facturation.read',     'facturation', 'Consulter les documents commerciaux'),
    ('facturation.create',   'facturation', 'Creer/convertir un document commercial'),
    ('comptabilite.lire',    'comptabilite', 'Consulter la comptabilite'),
    ('comptabilite.gerer',   'comptabilite', 'Gerer le plan comptable, generer des ecritures, calculer la TVA'),
    ('notifications.lire',   'notifications', 'Consulter les notifications'),
    ('notifications.creer',  'notifications', 'Creer des notifications / generer les alertes'),
    ('audit.lire',           'audit',     'Consulter le journal d''audit'),
    ('administration.lire',  'administration', 'Consulter les parametres de l''entreprise'),
    ('administration.gerer', 'administration', 'Modifier les parametres de l''entreprise'),
    ('rh.lire',              'rh',        'Consulter les employes, conges, fiches de paie'),
    ('rh.gerer',             'rh',        'Gerer les employes, conges, fiches de paie'),
    ('sav.lire',             'sav',       'Consulter les tickets SAV'),
    ('sav.gerer',            'sav',       'Gerer les tickets SAV (creer, assigner, commenter)'),
    ('plugins.lire',         'plugins',   'Consulter le catalogue et les plugins installes'),
    ('plugins.gerer',        'plugins',   'Installer/configurer/desinstaller des plugins'),
    ('ia.utiliser',          'ia',        'Utiliser les fonctionnalites IA (previsions, OCR)'),
    ('dgi.lire',             'dgi',       'Consulter les structures DGI generees'),
    ('dgi.gerer',            'dgi',       'Generer la structure DGI (UUID/QR code) d''une facture'),
    ('sauvegardes.lire',     'sauvegardes', 'Consulter l''historique des sauvegardes'),
    ('sauvegardes.gerer',    'sauvegardes', 'Declencher une sauvegarde')
ON CONFLICT (code) DO NOTHING;

-- 2. Creer une premiere entreprise de test
INSERT INTO entreprises (id, nom, devise) VALUES
    ('b378c64b-3ca0-4ae4-8799-8ce9e808cb4b', 'Entreprise Demo', 'MAD');

-- 3. Une succursale par defaut
INSERT INTO succursales (id, entreprise_id, nom) VALUES
    ('ed6fd13f-2907-4391-990a-ffc389eb0ade',
     'b378c64b-3ca0-4ae4-8799-8ce9e808cb4b',
     'Siege Social');

-- 4. Un role "Administrateur" avec toutes les permissions ci-dessus
INSERT INTO roles (id, entreprise_id, nom, description) VALUES
    ('c3a78cf5-71fa-4d2b-934e-34c7c3fe1e58',
     'b378c64b-3ca0-4ae4-8799-8ce9e808cb4b',
     'Administrateur', 'Acces complet');

INSERT INTO role_permissions (role_id, permission_id)
SELECT 'c3a78cf5-71fa-4d2b-934e-34c7c3fe1e58', id FROM permissions;

-- 5. Un premier utilisateur admin
-- Generer d'abord le hash du mot de passe avec :
--     node backend/scripts/generate-password-hash.js VotreMotDePasse
-- puis remplacer <HASH_GENERE> ci-dessous avant d'executer ce script.
INSERT INTO users (entreprise_id, succursale_id, role_id, nom_complet, email, mot_de_passe) VALUES
    ('b378c64b-3ca0-4ae4-8799-8ce9e808cb4b',
     'ed6fd13f-2907-4391-990a-ffc389eb0ade',
     'c3a78cf5-71fa-4d2b-934e-34c7c3fe1e58',
     'Administrateur Demo',
     'admin@demo.ma',
     '<HASH_GENERE>');
