-- ============================================================================
-- SMART GESTION PRO ENTERPRISE — SCHEMA MAITRE (CHECKLIST COMPLETE)
-- ============================================================================
-- Ce fichier liste TOUTES les tables necessaires pour couvrir les 23 modules
-- definis dans l'Article 1 (Vision du Projet). C'est la checklist de reference
-- pour ne rien oublier au fur et a mesure qu'on code chaque module.
--
-- Statut :
--   [OK]   = implemente dans le code (backend/src) a ce stade
--   [TODO] = a implementer dans les prochaines etapes
--
-- Toutes les tables "metier" portent une colonne entreprise_id (multi-tenant).
-- Les donnees sont isolees par entreprise (voir TenantGuard dans le backend).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. ENTREPRISES & SUCCURSALES  [OK]
-- ----------------------------------------------------------------------------
CREATE TABLE entreprises (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    nom             VARCHAR(255) NOT NULL,
    ice             VARCHAR(50),
    if_fiscal       VARCHAR(50),
    rc              VARCHAR(50),
    patente         VARCHAR(50),
    cnss            VARCHAR(50),
    adresse         TEXT,
    telephone       VARCHAR(30),
    email           VARCHAR(255),
    logo_url        VARCHAR(500),
    devise          VARCHAR(10) DEFAULT 'MAD',
    plan_abonnement VARCHAR(50) DEFAULT 'standard',
    actif           BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT now(),
    updated_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE succursales (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id) ON DELETE CASCADE,
    nom             VARCHAR(255) NOT NULL,
    adresse         TEXT,
    telephone       VARCHAR(30),
    responsable_id  UUID,
    actif           BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 2. UTILISATEURS, ROLES & PERMISSIONS  [OK]
-- ----------------------------------------------------------------------------
CREATE TABLE roles (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID REFERENCES entreprises(id) ON DELETE CASCADE, -- NULL = role systeme
    nom             VARCHAR(100) NOT NULL,
    description     TEXT,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE permissions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            VARCHAR(100) UNIQUE NOT NULL,   -- ex: produits.create
    module          VARCHAR(100) NOT NULL,
    description     TEXT
);

CREATE TABLE role_permissions (
    role_id         UUID REFERENCES roles(id) ON DELETE CASCADE,
    permission_id   UUID REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID REFERENCES entreprises(id) ON DELETE CASCADE,
    succursale_id   UUID REFERENCES succursales(id),
    role_id         UUID REFERENCES roles(id),
    nom_complet     VARCHAR(255) NOT NULL,
    email           VARCHAR(255) UNIQUE NOT NULL,
    mot_de_passe    VARCHAR(255) NOT NULL,
    telephone       VARCHAR(30),
    avatar_url      VARCHAR(500),
    actif           BOOLEAN DEFAULT true,
    deux_fa_active  BOOLEAN DEFAULT false,
    derniere_connexion TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE refresh_tokens (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
    token_hash      VARCHAR(255) NOT NULL,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 3. CLIENTS & FOURNISSEURS (CRM)  [OK]
-- ----------------------------------------------------------------------------
CREATE TABLE clients (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    type            VARCHAR(20) DEFAULT 'particulier', -- particulier / entreprise
    nom             VARCHAR(255) NOT NULL,
    ice             VARCHAR(50),
    telephone       VARCHAR(30),
    email           VARCHAR(255),
    adresse         TEXT,
    solde           NUMERIC(14,2) DEFAULT 0,
    plafond_credit  NUMERIC(14,2) DEFAULT 0,
    actif           BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE fournisseurs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    nom             VARCHAR(255) NOT NULL,
    ice             VARCHAR(50),
    telephone       VARCHAR(30),
    email           VARCHAR(255),
    adresse         TEXT,
    solde           NUMERIC(14,2) DEFAULT 0,
    actif           BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 4. PRODUITS & SERVICES  [OK]
-- ----------------------------------------------------------------------------
CREATE TABLE categories_produits (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    nom             VARCHAR(150) NOT NULL,
    parent_id       UUID REFERENCES categories_produits(id)
);

CREATE TABLE unites_mesure (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    nom             VARCHAR(50) NOT NULL,
    symbole         VARCHAR(10) NOT NULL
);

CREATE TABLE produits (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    categorie_id    UUID REFERENCES categories_produits(id),
    unite_id        UUID REFERENCES unites_mesure(id),
    type            VARCHAR(20) DEFAULT 'produit', -- produit / service
    reference       VARCHAR(100),
    code_barre      VARCHAR(100),
    nom             VARCHAR(255) NOT NULL,
    description     TEXT,
    prix_achat_ht   NUMERIC(14,2) DEFAULT 0,
    prix_vente_ht   NUMERIC(14,2) DEFAULT 0,
    taux_tva        NUMERIC(5,2) DEFAULT 20,
    seuil_alerte    NUMERIC(14,3) DEFAULT 0,
    gere_stock      BOOLEAN DEFAULT true,
    image_url       VARCHAR(500),
    actif           BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ DEFAULT now(),
    updated_at      TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 5. GESTION DU STOCK  [OK]
-- ----------------------------------------------------------------------------
CREATE TABLE stocks (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    succursale_id   UUID NOT NULL REFERENCES succursales(id),
    produit_id      UUID NOT NULL REFERENCES produits(id),
    quantite        NUMERIC(14,3) DEFAULT 0,
    UNIQUE (succursale_id, produit_id)
);

CREATE TABLE mouvements_stock (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    succursale_id   UUID NOT NULL REFERENCES succursales(id),
    produit_id      UUID NOT NULL REFERENCES produits(id),
    type            VARCHAR(20) NOT NULL, -- entree / sortie / transfert / ajustement / inventaire
    quantite        NUMERIC(14,3) NOT NULL,
    quantite_avant  NUMERIC(14,3),
    quantite_apres  NUMERIC(14,3),
    reference_doc   VARCHAR(100), -- ex: facture, BL, ajustement manuel
    motif           TEXT,
    user_id         UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 6. MODULE VENTES  [OK]
-- ----------------------------------------------------------------------------
CREATE TABLE ventes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    succursale_id   UUID NOT NULL REFERENCES succursales(id),
    client_id       UUID REFERENCES clients(id),
    user_id         UUID REFERENCES users(id),
    numero          VARCHAR(50) NOT NULL,
    statut          VARCHAR(30) DEFAULT 'brouillon',
    total_ht        NUMERIC(14,2) DEFAULT 0,
    total_tva       NUMERIC(14,2) DEFAULT 0,
    total_ttc       NUMERIC(14,2) DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE lignes_vente (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vente_id        UUID NOT NULL REFERENCES ventes(id) ON DELETE CASCADE,
    produit_id      UUID NOT NULL REFERENCES produits(id),
    quantite        NUMERIC(14,3) NOT NULL,
    prix_unitaire_ht NUMERIC(14,2) NOT NULL,
    taux_tva        NUMERIC(5,2) NOT NULL,
    remise_pct      NUMERIC(5,2) DEFAULT 0
);

-- ----------------------------------------------------------------------------
-- 7. MODULE ACHATS  [OK]
-- ----------------------------------------------------------------------------
CREATE TABLE achats (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    succursale_id   UUID NOT NULL REFERENCES succursales(id),
    fournisseur_id  UUID REFERENCES fournisseurs(id),
    user_id         UUID REFERENCES users(id),
    numero          VARCHAR(50) NOT NULL,
    statut          VARCHAR(30) DEFAULT 'brouillon',
    total_ht        NUMERIC(14,2) DEFAULT 0,
    total_tva       NUMERIC(14,2) DEFAULT 0,
    total_ttc       NUMERIC(14,2) DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE lignes_achat (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    achat_id        UUID NOT NULL REFERENCES achats(id) ON DELETE CASCADE,
    produit_id      UUID NOT NULL REFERENCES produits(id),
    quantite        NUMERIC(14,3) NOT NULL,
    prix_unitaire_ht NUMERIC(14,2) NOT NULL,
    taux_tva        NUMERIC(5,2) NOT NULL
);

-- ----------------------------------------------------------------------------
-- 8. FACTURATION (Devis, Proforma, BL, Facture, Avoir)  [OK - table lignes_document ajoutee]
-- ----------------------------------------------------------------------------
CREATE TABLE documents_commerciaux (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    client_id       UUID REFERENCES clients(id),
    type            VARCHAR(30) NOT NULL, -- devis / proforma / bon_livraison / facture / avoir
    numero          VARCHAR(50) NOT NULL,
    document_origine_id UUID REFERENCES documents_commerciaux(id),
    statut          VARCHAR(30) DEFAULT 'brouillon',
    total_ht        NUMERIC(14,2) DEFAULT 0,
    total_tva       NUMERIC(14,2) DEFAULT 0,
    total_ttc       NUMERIC(14,2) DEFAULT 0,
    date_document   DATE DEFAULT CURRENT_DATE,
    date_echeance   DATE,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 9. FACTURATION ELECTRONIQUE (DGI)  [OK - structure locale (UUID + QR code reels generes) ; soumission reelle a la DGI non connectee, specs officielles manquantes]
-- ----------------------------------------------------------------------------
CREATE TABLE factures_electroniques (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id       UUID NOT NULL REFERENCES entreprises(id),
    document_id         UUID REFERENCES documents_commerciaux(id),
    uuid_dgi             VARCHAR(100),
    qr_code             TEXT,
    xml_signe           TEXT,
    statut_dgi          VARCHAR(30) DEFAULT 'en_attente', -- en_attente / valide / rejete / reemis
    date_envoi          TIMESTAMPTZ,
    date_validation     TIMESTAMPTZ,
    message_erreur      TEXT
);

-- ----------------------------------------------------------------------------
-- 10. PAIEMENTS, CAISSE & BANQUES  [OK - simplifie: moyen_paiement en enum plutot que table separee]
-- ----------------------------------------------------------------------------
CREATE TABLE moyens_paiement (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            VARCHAR(30) UNIQUE NOT NULL -- cash, tpe, virement, cheque, mobile_wallet, qr_code
);

CREATE TABLE paiements (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id       UUID NOT NULL REFERENCES entreprises(id),
    document_id         UUID REFERENCES documents_commerciaux(id),
    moyen_paiement_id   UUID REFERENCES moyens_paiement(id),
    montant             NUMERIC(14,2) NOT NULL,
    reference_transaction VARCHAR(100), -- transaction TPE, num cheque, ref virement...
    banque              VARCHAR(100),
    statut              VARCHAR(30) DEFAULT 'accepte', -- accepte / refuse / annule / remboursement
    user_id             UUID REFERENCES users(id),
    created_at          TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE comptes_bancaires (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    banque          VARCHAR(100),
    rib             VARCHAR(50),
    solde           NUMERIC(14,2) DEFAULT 0
);

CREATE TABLE cheques (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    type            VARCHAR(20) NOT NULL, -- recu / emis
    numero_cheque   VARCHAR(50),
    banque          VARCHAR(100),
    montant         NUMERIC(14,2) NOT NULL,
    date_emission   DATE,
    date_encaissement DATE,
    statut          VARCHAR(30) DEFAULT 'en_attente' -- en_attente / encaisse / rejete
);

-- ----------------------------------------------------------------------------
-- 11. COMPTABILITE & TVA  [OK]
-- ----------------------------------------------------------------------------
CREATE TABLE plan_comptable (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    numero_compte   VARCHAR(20) NOT NULL,
    libelle         VARCHAR(255) NOT NULL,
    type_compte     VARCHAR(30)
);

CREATE TABLE ecritures_comptables (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    compte_id       UUID REFERENCES plan_comptable(id),
    document_id     UUID REFERENCES documents_commerciaux(id),
    debit           NUMERIC(14,2) DEFAULT 0,
    credit          NUMERIC(14,2) DEFAULT 0,
    date_ecriture   DATE DEFAULT CURRENT_DATE,
    libelle         TEXT
);

CREATE TABLE declarations_tva (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    periode         VARCHAR(20) NOT NULL, -- ex: 2026-T3
    tva_collectee   NUMERIC(14,2) DEFAULT 0,
    tva_deductible  NUMERIC(14,2) DEFAULT 0,
    tva_a_payer     NUMERIC(14,2) DEFAULT 0,
    statut          VARCHAR(30) DEFAULT 'brouillon'
);

-- ----------------------------------------------------------------------------
-- 12. INTELLIGENCE ARTIFICIELLE (OCR, previsions, assistant)  [OK - previsions par regression lineaire reelle, OCR reel via Tesseract.js]
-- ----------------------------------------------------------------------------
CREATE TABLE ia_documents_analyses (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    type_document   VARCHAR(50), -- facture_fournisseur, releve_bancaire, etc.
    fichier_url     VARCHAR(500),
    donnees_extraites JSONB,
    statut          VARCHAR(30) DEFAULT 'traite',
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE ia_previsions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    type            VARCHAR(30), -- ventes, tresorerie
    periode         VARCHAR(20),
    valeur_prevue   NUMERIC(14,2),
    donnees_json    JSONB,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 13. NOTIFICATIONS  [OK]
-- ----------------------------------------------------------------------------
CREATE TABLE notifications (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    user_id         UUID REFERENCES users(id),
    titre           VARCHAR(255),
    message         TEXT,
    type            VARCHAR(30), -- info / alerte / erreur / stock_bas / paiement...
    lue             BOOLEAN DEFAULT false,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 14. SECURITE & AUDIT  [OK - journal_audit code, 2FA colonne existante mais logique non implementee]
-- ----------------------------------------------------------------------------
CREATE TABLE journal_audit (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID REFERENCES entreprises(id),
    user_id         UUID REFERENCES users(id),
    action          VARCHAR(100) NOT NULL, -- create / update / delete / login / export...
    table_cible     VARCHAR(100),
    enregistrement_id UUID,
    donnees_avant   JSONB,
    donnees_apres   JSONB,
    ip_adresse      VARCHAR(50),
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 15. SAUVEGARDES & SYNCHRONISATION  [OK - sauvegardes: vrai pg_dump code et teste ; synchronisation multi-appareils: TODO, necessite les apps client]
-- ----------------------------------------------------------------------------
CREATE TABLE sauvegardes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    fichier_url     VARCHAR(500), -- lien Google Drive
    taille_octets   BIGINT,
    statut          VARCHAR(30) DEFAULT 'reussie',
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE synchronisations (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    appareil        VARCHAR(100),
    derniere_sync   TIMESTAMPTZ,
    statut          VARCHAR(30)
);

-- ----------------------------------------------------------------------------
-- 16. PLUGINS / INTEGRATIONS EXTERNES (TPE, DGI, banques, scanner...)  [OK - registre dactivation/configuration ; chargement dynamique reel reste a faire]
-- ----------------------------------------------------------------------------
CREATE TABLE plugins_installes (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    entreprise_id   UUID NOT NULL REFERENCES entreprises(id),
    code_plugin     VARCHAR(100) NOT NULL, -- tpe_bank_x, dgi_connector, barcode_scanner...
    version         VARCHAR(20),
    configuration   JSONB,
    actif           BOOLEAN DEFAULT true,
    installe_le     TIMESTAMPTZ DEFAULT now()
);

-- ----------------------------------------------------------------------------
-- 17. PARAMETRAGE GENERAL / ADMINISTRATION  [OK - basique]
-- ----------------------------------------------------------------------------
CREATE TABLE parametres_entreprise (
    entreprise_id   UUID PRIMARY KEY REFERENCES entreprises(id),
    parametres      JSONB DEFAULT '{}'::jsonb
);

-- ============================================================================
-- MODULES ENCORE NON DETAILLES EN TABLES (a affiner avec vous article par
-- article) : RH, SAV, Dashboard/Rapports (vues agregees), UI/UX (pas de BDD),
-- API & Integrations (config par plugin), Deploiement (infra, pas BDD).
-- ============================================================================
